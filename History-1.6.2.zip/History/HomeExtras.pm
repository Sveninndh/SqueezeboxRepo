package Plugins::History::HomeExtras;

use strict;
use Plugins::History::Plugin;

Plugins::History::HomeExtraLastPlayed->initPlugin();

1;


package Plugins::History::HomeExtraBase;

use base qw(Plugins::MaterialSkin::HomeExtraBase);

sub initPlugin {
	my ($class, $tag, $extra) = @_;

	$extra->{needsPlayer} = 1;

	$class->SUPER::initPlugin(
		feed => sub { handleFeed($tag, @_) },
		tag  => "HistoryExtras${tag}",
		extra => $extra,
	);
}

sub handleFeed {
	my ($tag, $client, $cb, $args) = @_;

	$args->{params}->{menu} = "home_heroes_${tag}";

	Plugins::History::Plugin::handleFeed($client, $cb, $args);
}

1;


package Plugins::History::HomeExtraLastPlayed;

use base qw(Plugins::History::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	$class->SUPER::initPlugin('lastplayed', {
		title => 'PLUGIN_HISTORY',
		tag   => 'lastplayed',
		icon  => 'html/images/playlists.png',
		count => 20,
	});
}

1;


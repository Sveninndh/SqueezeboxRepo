package Plugins::History::ProtocolHandler;
# History copyright (c) 2024 by SvenInNdh

use strict;
#use base qw(Slim::Player::Protocols::File);

use Slim::Utils::Log;
use Slim::Utils::Strings qw(string cstring);
use Slim::Utils::Prefs;

my $log = logger('plugin.history');
my $prefs = preferences('plugin.history');

use constant PAGE_URL_REGEXP => qr{(^file:\/\/.+(\.m3u)$)|(^db:album\.)}i; # qr{^file:\/\/.+(\.m3u)$}i;   # qr{(^file:\/\/.+(\.m3u)$)|(^db:album\.id=)}i;
Slim::Player::ProtocolHandlers->registerURLHandler(PAGE_URL_REGEXP, __PACKAGE__) if Slim::Player::ProtocolHandlers->can('registerURLHandler');

sub explodePlaylist {
	my ( $class, $client, $url, $cb ) = @_;
	$log->error(Data::Dump::dump($url));
	my $uris; #{ offset => 0, menuComplete => 1 }; #type => 'opml', title => '', items => [], 
	if ( $url =~ /^file:\/\/(.+)(\.m3u)$/i ) {
		my $path   = Slim::Utils::Misc::pathFromFileURL($url);
		my @tracks = Slim::Formats::Playlists::M3U->read($path, undef, undef);
		$uris = {
			items => [ map { Plugins::History::Plugin::getTrackItem($client, (blessed $_) ? { url => $_->url } : $_, 1) } @tracks ]
		};
	}
	else {
		my $albumid = getAlbum($url)->{id};
		if ($albumid) {
			my $playdirect = $prefs->client($client)->get('trackmode');
			$playdirect = ($playdirect) ? ($playdirect eq '0') : 1;
			my $request = Slim::Control::Request::executeRequest($client, ['titles', 0, 100, 'album_id:' . $albumid, 'tags:aulcd', 'sort:tracknum']);
			my $titles = $request->getResult('titles_loop');
#			$log->error(Data::Dump::dump($titles));
			$uris = {
				items => [ map { Plugins::History::Plugin::getTrackItem($client, $_, $playdirect); } @$titles ]
			};
		}
		else { $uris = { items => [] }; }
	}
#	$log->error(Data::Dump::dump($uris));
	$cb->( $uris );
}

sub getIcon {
	my ( $class, $url ) = @_;
	my $album = getAlbum($url, 1)->{album};
	#$log->error(Data::Dump::dump($album));
	if ($album && $album->artwork) {
		return 'music/' . $album->artwork . '/cover.png';
	}
	if ($url =~ /^file:.+(\.m3u)$/) {
		return 'html/images/playlists.png'
	}
	return 'html/images/albums.png'
}

sub getAlbum {
	my ($url, $forceAlbumObject) = @_;
	my $album;
	my $id;
	if ($url =~ /^db:album\.title=/) {
		$album = getAlbumFromTitle($url); 
		$id = $album->id if $album;
	}
	elsif ($url =~ /^db:album\.id=/) {
		$id    = substr($url,12,5);
		$album = Slim::Schema->find('Album', $id) if $forceAlbumObject;
	}
	return { id => $id, album => $album };
}

sub getAlbumFromTitle {
	my $url = shift;
	my $query = {};
	my $joins = [];
	$url =~ s/^db://;
	foreach my $condition (split /&(?:amp;)?/, $url) {
		if ($condition =~ /^(\w+)\.(\w+)=(.+)/) {
			my ($dbClass2, $key, $value) = ($1, $2, $3);
			
			if (utf8::is_utf8($value)) {
				utf8::decode($value);
				utf8::encode($value);
			}
			
			$key   = URI::Escape::uri_unescape($key);
			$value = URI::Escape::uri_unescape($value);
			
			if ($dbClass2 ne 'album') {
				$key = "$dbClass2.$key";
				push @$joins, $dbClass2;
			}
			
			$query->{$key} = $value;
		}
	}
	#$log->error(Data::Dump::dump({ query => $query, joins => $joins }));
	return Slim::Schema->search( 'Album', $query, { join => $joins } )->single();
}

1;
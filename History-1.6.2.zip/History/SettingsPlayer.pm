package Plugins::History::SettingsPlayer;
# History copyright (c) 2024 by SvenInNdh
use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Strings qw(string);
use Slim::Utils::Prefs;
use Slim::Utils::Log;

my $prefs = preferences('plugin.history');

sub name {
	return Slim::Web::HTTP::CSRF->protectName('PLUGIN_HISTORY');
}

sub page {
	return Slim::Web::HTTP::CSRF->protectURI('plugins/History/settings/player.html');
}

sub needsClient {
    return 1;
}

sub prefs {
    my ($class, $client) = @_;
    return ($prefs->client($client), qw(mode trackmode));
}

sub handler {
    my ($class, $client, $params) = @_;

    if ($params->{'saveSettings'}) {
		$prefs->client($client)->set('mode', $params->{'mode'});
		$prefs->client($client)->set('trackmode', $params->{'trackmode'});
    }
	else {
		$prefs->client($client)->set('mode', '0')	   unless ($prefs->client($client)->get('mode'));
		$prefs->client($client)->set('trackmode', '0') unless ($prefs->client($client)->get('trackmode'));
		
		$params->{'mode'} = $prefs->client($client)->get('mode');
		$params->{'trackmode'} = $prefs->client($client)->get('trackmode');
	}

    return $class->SUPER::handler($client, $params);
}

1;

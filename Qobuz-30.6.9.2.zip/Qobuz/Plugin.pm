=head Infos
Sven 2026-05-16 enhancements based on version 1.400 up to 3.6.9

This program is free software; you can redistribute it and/or label
modify it under the terms of the GNU General Public License, version 2.

 1. included a new album information menu befor playing the album
	It shows: Samplesize, Samplerate, Genre, Duration, Description if present, Goodies (Booklet) if present,
	trackcount, Credits including performers, Conductor if present, Artist, Composer, ReleaseDate, Label (with label albums),
	Copyright, add Album or Artist to your Qobuz favorites
 Enhanced Artist menu with biography, album list, title list, playlists, similar artists 
 2. added samplerate of currently streamed file in the 'More Info' menu
 3. added samplesize of currently streamed file in the 'More Info' menu
 4. shows conductor including artist information for classic albums
 5. added seeking inside flac files while playing
 6. added new preference 'FLAC 24 bits / 96 kHz (Hi-Res)'
 7. my prefered menu order in main menu
 8. added a menu for a playlist item with the playlist, duration, title count, description,
          owner (if present), genres, release date, update date, similar playlists (if present)
 9. added subscribe/unsubscribe of playlist subscribtion
10. added delete my own playlists
11. added much more compatibility and useability with LMS favorites
12. added a TrackMenu, you get it if you click on a track item and select the more... menu item, 2025-03-22
13. added genre filter for user favorites, albums and playlists 2025-09-17, the previous genre menu is removed
14. added albums of the week 2025-10-15 
15. added Radio feature based on an album, artist or a track 2025-10-23 
16. added Album suggestions based on an album 2025-10-25
17. removed QobuzMyWeeklyQ(), No longer supported by Qobuz 25-11-02 (30.6.4)
18. Completing the translations for Spanish.
19. added new artist page, labels, awards.
20. added new album list 'Release Radar' and 'Albums of the week'.
21. added list of labels to explore
22. added a list of all awards.
23. added new awards page and labels page, awards and labels page are used now in the album page
24. added new setting album view
25. added new enhanced search - a complete redesign using the new design element 'header' supported in material. 2025-12-28
26. Consideration of has_more in releases on the artist page 2025-12-28
27. added new search to global search 2025-12-29
28. Support for User_Id sent by the controller. Currently, this feature is only supported by my own extended version of Material.
29. New artist page - a complete redesign using the new design element 'header' supported in material.
30. New label  page - a complete redesign using the new design element 'header' supported in material.
31. New award  page - a complete redesign using the new design element 'header' supported in material.
32. New playlists DailyQ and WeeklyQ 
33. Enhanced support for Lyrion users in combination woth History plugin and Material Plugin
34. New discover page
35. Support for paging to reduce data traffic between the client and the streaming service - Currently only with my own Material 'DEVELOPMENT' version.
36. New redesigned home menü.
37. The genre selection is now saved separately for each Qobuz user.
38. Round artist images and playback of the top tracks for each artist.

all changes are marked with "#Sven" in source code
changed files: Common.pm, API.pm, Plugin.pm, ProtocolHandler.pm, Settings.pm, strings.txt and basic.html from .../Qobuz/HTML/EN/plugins/Qobuz/settings/basic.html

With the value type => 'link' a list with symbols gets the option "Toggle View"
With the value type => 'playlist' a list with symbols gets the option "Toggle View" and the "ADD" and "PLAY" buttons are displayed.
It should therefore only be used for track lists (album, tracks and playlists).
Since version 3.0.7 my hack of "My weekly Q" is included in original Qobuz plugin of Pierre Beck / Michael Herger
=cut

package Plugins::Qobuz::Plugin;

use utf8;
use strict;
use base qw(Slim::Plugin::OPMLBased);

use JSON::XS::VersionOneAndTwo;
use Tie::RegexpHash;
use POSIX qw(strftime); #??? geht scheinbar auch ohne

use Slim::Formats::RemoteMetadata;
use Slim::Player::ProtocolHandlers;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(string cstring);
use Scalar::Util qw(looks_like_number);

use Plugins::Qobuz::API;
use Plugins::Qobuz::API::Common;
use Plugins::Qobuz::ProtocolHandler;

use constant CAN_IMPORTER => (Slim::Utils::Versions->compareVersions($::VERSION, '8.0.0') >= 0);
use constant CLICOMMAND => 'qobuzquery';
use constant MAX_RECENT => 30;

use constant ALBUM => '1';
use constant EP => '2';
use constant SINGLE => '3';

# Keep in sync with Music & Artist Information plugin
my $WEBLINK_SUPPORTED_UA_RE = qr/\b(?:iPeng|SqueezePad|OrangeSqueeze|OpenSqueeze|Squeezer|Squeeze-Control)\b/i;
my $WEBBROWSER_UA_RE = qr/\b(?:FireFox|Chrome|Safari)\b/i;

my $GOODIE_URL_PARSER_RE = qr/\.(?:pdf|png|gif|jpg)$/i;

my $prefs = preferences('plugin.qobuz');

tie my %localizationTable, 'Tie::RegexpHash';

%localizationTable = (
	qr/^Livret Num.rique/i => 'PLUGIN_QOBUZ_BOOKLET'
);

$prefs->init({
	accounts => {},
	preferredFormat => 6,
	filterSearchResults => 0,
	playSamples => 1,
	dontImportPurchases => 1,
	classicalGenres => '',
	useClassicalEnhancements => 1,
	parentalWarning => 0,
	showDiscs => 0,
	groupReleases => 1,
	importWorks => 1,
	sortPlaylists => 1,
	showUserPurchases => 1,
	sortArtistsAlpha => 1,
	albumViewType => 0,
	showReplayGain => 1,
});

$prefs->migrate(1,
	sub {
		my $token = $prefs->get('token');
		my $userdata = $prefs->get('userdata');

		# migrate existing account to new list of accounts
		if ($token && $userdata && (my $id = $userdata->{id})) {
			my $accounts = $prefs->get('accounts') || {};
			$accounts->{$id} = {
				token => $token,
				userdata => $userdata,
			};
		}

		$prefs->remove('token', 'userdata', 'userinfo', 'username');
		
		1;
	}
);
$prefs->remove('genreFilter', 'genreFavsFilter') if $prefs->get('genreFilter');

# registers a callback function which is called when a player changes user
$prefs->setChange( sub {
	my ($pref, $userId, $client) = @_;
	$client->pluginData(api => 0);
}, 'userId');

my $log = Slim::Utils::Log->addLogCategory( {
	category     => 'plugin.qobuz',
	defaultLevel => 'ERROR',
	description  => 'PLUGIN_QOBUZ',
	logGroups    => 'SCANNER',
} );

use constant PLUGIN_TAG => 'qobuz';
use constant CAN_IMAGEPROXY => (Slim::Utils::Versions->compareVersions($::VERSION, '7.8.0') >= 0);

my $isHistory;
my $cache = Plugins::Qobuz::API::Common->getCache();
my $tmpData = {}; # cache für State-Tracker und andere temporäre Daten pro User

#Sven 2022-05-10
sub initPlugin {
	my $class = shift;

	if (main::WEBUI) {
		require Plugins::Qobuz::Settings;
		Plugins::Qobuz::Settings->new();
	}

	Plugins::Qobuz::API->init(
		$class->_pluginDataFor('aid')
	);

	Slim::Player::ProtocolHandlers->registerHandler(
		qobuz => 'Plugins::Qobuz::ProtocolHandler'
	);

	Slim::Formats::Playlists->registerParser('qbz', 'Plugins::Qobuz::PlaylistParser');

	Slim::Player::ProtocolHandlers->registerIconHandler(
		qr|\.qobuz\.com/|,
		sub { $class->_pluginDataFor('icon') }
	);

	# Track Info item
	Slim::Menu::TrackInfo->registerInfoProvider( qobuzTrackInfo => (
		func  => \&trackInfoMenu
	) );

	Slim::Menu::ArtistInfo->registerInfoProvider( qobuzArtistInfo => (
		func  => \&artistInfoMenu
	) );

	Slim::Menu::AlbumInfo->registerInfoProvider( qobuzAlbumInfo => (
		func  => \&albumInfoMenu
	) );

	Slim::Menu::GlobalSearch->registerInfoProvider( qobuzSearch => (
		#after => 'top',
		func  => \&searchMenu
	) );

	#Sven 2022-05-10 
	Slim::Menu::PlaylistInfo->registerInfoProvider( qobuzPlaylistInfo => (
		#after => 'playitem',
		func => \&albumInfoMenu
	) );

	#                                                          |requires Client
	#                                                          |  |is a Query
	#                                                          |  |  |has Tags
	#                                                          |  |  |  |Function to call
	#                                                          C  Q  T  F
	Slim::Control::Request::addDispatch(['qobuz', 'goodies'], [1, 1, 1, \&_getGoodiesCLI]);

	Slim::Control::Request::addDispatch(['qobuz', 'playalbum'], [1, 0, 0, \&cliQobuzPlayAlbum]);
	Slim::Control::Request::addDispatch(['qobuz', 'addalbum'], [1, 0, 0, \&cliQobuzPlayAlbum]);
	Slim::Control::Request::addDispatch(['qobuz', 'recentsearches'], [1, 0, 1, \&_recentSearchesCLI]);
	Slim::Control::Request::addDispatch(['qobuz', 'command', '_aParams'], [1, 0, 1, \&cliQobuzCommand]);

	# "Local Artwork" requires LMS 7.8+, as it's using its imageproxy.
	if (CAN_IMAGEPROXY) {
		require Slim::Web::ImageProxy;
		Slim::Web::ImageProxy->registerHandler(
			match => qr/static\.qobuz\.com/,
			func  => \&_imgProxy,
		);
	}

	if (CAN_IMPORTER) {
		# tell LMS that we need to run the external scanner
		Slim::Music::Import->addImporter('Plugins::Qobuz::Importer', { use => 1 });
	}

	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => PLUGIN_TAG,
		menu   => 'radios',
		is_app => 1,
		weight => 1,
	);
}

#Sven
sub postinitPlugin {
	my $class = shift;

	if ( Slim::Utils::PluginManager->isEnabled('Plugins::LastMix::Plugin') ) {
		eval {
			require Plugins::LastMix::Services;
		};

		if (!$@) {
			main::INFOLOG && $log->info("LastMix plugin is available - let's use it!");
			require Plugins::Qobuz::LastMix;
			Plugins::LastMix::Services->registerHandler('Plugins::Qobuz::LastMix', 'lossless');
		}
	}

	if ( Slim::Utils::PluginManager->isEnabled('Slim::Plugin::OnlineLibrary::Plugin') ) {
		Slim::Plugin::OnlineLibrary::Plugin->addLibraryIconProvider('qobuz', '/plugins/Qobuz/html/images/icon.png');

		Slim::Plugin::OnlineLibrary::BrowseArtist->registerBrowseArtistItem( qobuz => sub {
			my ( $client ) = @_;

			return {
				name => cstring($client, 'BROWSE_ON_SERVICE', 'Qobuz'),
				type => 'link',
				icon => $class->_pluginDataFor('icon'),
				url  => \&browseArtistMenu,
			};
		} );

		main::INFOLOG && $log->is_info && $log->info("Successfully registered BrowseArtist handler for Qobuz");
	}
	
	if ( Slim::Utils::PluginManager->isEnabled('Plugins::History::Plugin') ) {
		eval {
			require Plugins::History::Plugin;
		};
		$isHistory = ($@) ? 0 : 1;
	}
}

sub onlineLibraryNeedsUpdate {
	if (CAN_IMPORTER) {
		my $class = shift;
		require Plugins::Qobuz::Importer;
		return Plugins::Qobuz::Importer->needsUpdate(@_);
	}
	else {
		$log->warn('The library importer feature requires at least Logitech Media Server 8');
	}
}

sub getLibraryStats { if (CAN_IMPORTER) {
	require Plugins::Qobuz::Importer;
	my $totals = Plugins::Qobuz::Importer->getLibraryStats();
	return wantarray ? ('PLUGIN_QOBUZ', $totals) : $totals;
} }

sub getDisplayName { 'PLUGIN_QOBUZ' }

# don't add this plugin to the Extras menu
sub playerMenu {}

#Sven 2026-04-22, 2026-05-21 - Der Block enthält Hilfsfunktionen für das Paging bzw. Infinite Scroll
BEGIN {
	my $_params = {}; # Statische Variable - Enhält den Parameter Hash eines Client Requests 
					 # In $params heißen die Werte nicht 'index' und 'quantity' sondern '_index' und '_quantity'.
	sub saveParams {
		$_params = shift;
	}

	sub getParams {
		my $field = shift;
		return $_params->{$field} || '' if $field;
		return $_params;
	}

	#Sven 2026-04-22 - Aktiviert Paging falls der Client das unterstützt und setzt die Parameter für die API-Aufrufe.
	sub setPaging {
		my ($params, $args) = @_;

		# $args - Enthält die Argumente für den API-Aufruf und $args->{args} die Argumente für Plugins::Qobuz::API:_get().
		my $args_get = $args->{args} ||= {}; 

		# Der Client Request erhält am Anfang von handleFeed() eine Referenz auf die Parameter des Requests.
		# Mit der Abfrage von 'features' enhält 'i' wird erfragt, ob der Client 'Infinite Scroll' unterstützt.
		# Ab Material 6.4 wird der Parameter 'features' mit jedem Request mitgeschickt.
		if ($_params->{features} =~ /i/ && ! $args->{noPaging}) { 
			# Hier werden die Parameter für Plugins::Qobuz::API:_get() gesetzt um einen Chunk anzufordern.
			# Es kann gecacht werden, da der Cache-Key 'offset' beinhaltet, es also für jeden Chunk einen Eintrag im Cache gibt.
			my $chunkSize = 50; # Eine Vorgabe von Qobuz
			$args_get->{_paging} = 1;
			$args_get->{limit}   = $chunkSize;
			if ($params->{quantity} == 1) {
				$args_get->{offset} = int($params->{index} / $chunkSize) * $chunkSize; #damit die richtige Seite geladen wird.
			}
			else {
				$args_get->{offset} = $_params->{_index};
			}	
		}
		else {
			# Kein Paging, Verhalten wie bisher.
			$args_get->{_paging} = 0;
			$args_get->{limit}   = QOBUZ_USERDATA_LIMIT;
		}
		# $log->error(_dump($_params, $params, $args));
	}
}

#Sven 2026-04-17, 2026-05-21 - Bereitet die Daten für die Übergabe an die Callback Funktion auf, je nach dem ob _paging aktiv ist oder nicht.
sub cbParams { 
	my ($client, $items, $params, $result) = @_;

	my $count = scalar @$items;

	return { items => [{ name => cstring($client, $params->{noItems} ? $params->{noItems} : 'PLUGIN_QOBUZ_NOITEMS'), type => 'textarea' }] } unless $count;

	my $args = $params->{args};

	if ($args->{_paging}) {
		# Neuere API-Funktionen von Qobuz liefern nicht mehr den Wert von 'total' zurück, sondern 'has_more', die Länge der zu ladenden Liste ist daher nicht von Beginn an bekannt.
		my $total = $args->{offset} + $count;
		if (exists $result->{has_more}) { 
			# An dem Wert total erkennt Material, dass total noch nicht bekannt ist und zeigt in der Kopfzeile daher nur die Anzahl der bisher geladenen Einträge an.
			# Damit Material gegebenenfalls noch weitere Chunks anfordert muss $total > $args->{offset} + $count, ich setze der Einfachheit halber den Wert dann auf 25000.
			$total += 1 if $result->{has_more}; 
		}	
		else {
			# Der Gesamtlänge ist bereits beim ersten Chunk bekannt und wird mit jedem Chunk neu zurückgeliefert.
			$total += 1 if $total < $result->{total};
		}
		# $log->error(_dump({ len => scalar @$items, offset => $args->{offset}, total => $total, has_more => $result->{has_more} }, $args));
		return { items => $items, offset => $args->{offset}, total => $total, forceRefresh => 1 }; # forceRefresh => 1  Zwingt XMLBrowser, bei jedem Paginierungs-Schritt das Plugin aufzurufen und nicht aus dem unvollständigen Cache zu lesen.
	}

	# $log->error(_dump({ len => scalar @$items }, $args));
	return { items => $items };
}

#Sven 2026-04-17, 2026-05-21
sub setGenre {
	my ($args, $client, $filter) = @_;

	unless ( exists $args->{args} && exists $args->{args}->{genre_ids} ) {
		my $genreIds = exists $args->{genreId} ? $args->{genreId} : _getGenres($client, $filter); #Sven 2025-09-16 v30.6.2
		$args->{args}->{genre_ids} = $genreIds if $genreIds;
	}
}

#Sven 2026-04-25
sub addHeader {
	my ($header, $items, $headerItems) = @_; 

	$header->{type} = 'header';
	$header->{itemActions} = { allAvailableActionsDefined => 1 } unless exists $header->{items} || exists $header->{url};
	return $header unless $items;

	push @{$items}, $header;
	if (defined $headerItems) {
		push @{$items}, ref $headerItems eq 'ARRAY' ? @{$headerItems} : $headerItems;
	}
}

#Sven 2024-01-24 
sub handleFeed {
	my ($client, $cb, $args) = @_;

	my $accountStatus = Plugins::Qobuz::API::Common::getAccountStatus($client, saveParams($args->{params})); #Sven 2026-01-13

	unless ( $accountStatus->{count} ) {
		return $cb->({
			items => [{
				name => cstring($client, 'PLUGIN_QOBUZ_REQUIRES_CREDENTIALS'),
				type => 'textarea',
			}]
		});
	}

	my $timestamp = time();

	my $items = [{
		name  => cstring($client, 'SEARCH'),
		image => 'html/images/search.png',
		type => 'link',
		url  => sub {
			my ($client, $cb, $params) = @_;
			my $items = [];

			my $i = 0;
			for my $recent ( @{ $prefs->get('qobuz_recent_search') || [] } ) {
				unshift @$items, {
					name  => $recent,
					type  => 'link',
					url => sub {
						my ($client, $cb, $params) = @_;
						QobuzSearch($client, $cb, undef, { q => $recent });
					},
					itemActions => {
						info => {
							command     => ['qobuz', 'recentsearches'],
							fixedParams => { deleteMenu => $i++ },
						},
					},
					#passthrough => [ { type => 'search' } ],
				};
			}

			unshift @$items, {
				name => cstring($client, 'PLUGIN_QOBUZ_NEW_SEARCH'),
				type => 'search',
				#timeout => 35,
				url  => sub {
					my ($client, $cb, $params) = @_;
					addRecentSearch($params->{search});
					QobuzSearch($client, $cb, undef, { q => $params->{search} });
				},
				#passthrough => [ { type => 'search' } ],
			};

			$cb->({ items => $items });
		},
	},addHeader({ name => cstring($client, 'PLUGIN_QOBUZ_SELECTION') }), { 
		name  => cstring($client, 'PLUGIN_QOBUZ_GENRE_SELECT') . _genreCount($client, _genreFilter($client)),
		image => 'html/images/genres.png',
		type  => 'menu', #Sven - view type
		url  => \&QobuzGenreSelection,
	},{		
		name => cstring($client, 'PLUGIN_QOBUZ_DISCOVER'),
		image => 'plugins/Qobuz/html/images/explore_svg.png',
		type  => 'albums', #Sven - view type
		url  => \&QobuzDiscover,
	},{
		name => cstring($client, 'PLUGIN_QOBUZ_ALBUM_PICKS'),
		image => 'html/images/albums.png',
		type  => 'menu', #Sven - view type
		url  => \&QobuzAlbums,
	}, {
		name => cstring($client, 'PLUGIN_QOBUZ_PUBLICPLAYLISTS'),
		url  => \&QobuzPlaylistTags,
		type  => 'menu', #Sven - view type
		image => 'html/images/playlists.png',
	},{
		name => cstring($client, 'PLUGIN_QOBUZ_LABELS_EXPLORE'),
		image => 'plugins/Qobuz/html/images/label_svg.png',
		type  => 'albums', #Sven - view type
		url  => \&QobuzLabels,
	},{
		name => cstring($client, 'PLUGIN_QOBUZ_AWARDS'),
		image => 'plugins/Qobuz/html/images/awards_svg.png',
		type  => 'albums', #Sven - view type
		url  => \&QobuzAwardsExplore,
	},addHeader({ name => cstring($client, 'PLUGIN_QOBUZ_MY_SELECTION') }), {
		name  => cstring($client, 'PLUGIN_QOBUZ_USER_FAVORITES'),
		image => 'html/images/favorites.png',
		type  => 'link', #'menu', #Sven - view type
		items => [{
			name  => cstring($client, 'PLUGIN_QOBUZ_ARTISTS'),
			image => QOBUZ_ARTISTS_IMAGE,
			type  => 'artists', #Sven - view type
			url   => \&QobuzUserFavorites,
			passthrough => [{ type => 'artists' }]
		}, {
			name  => cstring($client, 'ALBUMS'),
			image => 'html/images/albums.png',
			url   => \&QobuzUserFavorites,
			type  => 'albums', #Sven - view type
			passthrough => [{ type => 'albums' }]
		}, {
			name  => cstring($client, 'SONGS'),
			image => 'html/images/playlists.png',
			type  => 'playlist',
			url   => \&QobuzUserFavorites,
			passthrough => [{ type => 'tracks' }]
		}, {
			name  => cstring($client, 'PLUGIN_QOBUZ_LABELS'),
			image => 'plugins/Qobuz/html/images/label_svg.png',
			url   => \&QobuzUserFavorites,
			type  => 'artists', #Sven - view type
			passthrough => [{ type => 'labels' }]
		}, {
			name  => cstring($client, 'PLUGIN_QOBUZ_AWARDS'),
			image => 'plugins/Qobuz/html/images/awards_svg.png',
			type  => 'artists', #Sven - view type
			url   => \&QobuzUserFavorites,
			passthrough => [{ type => 'awards' }]
		}],
	},{
		name => cstring($client, 'PLUGIN_QOBUZ_RELEASE_RADAR'),
		image => 'html/images/albums.png',
		type  => 'albums', #Sven - view type
		url  => \&QobuzGetAlbums,
		passthrough => [{ cmd => 'favorite/getNewReleases', args => { type => 'artists', showDate => 1 }, genreId => '', noItems => 'PLUGIN_QOBUZ_NOITEMS_RELEASERADAR' }]
	},{
		name => cstring($client, 'PLUGIN_QOBUZ_USERPLAYLISTS'),
		image => 'html/images/playlists.png',
		type  => 'playlists', #Sven - view type
		url  => \&QobuzUserPlaylists,
	},{
		name  => cstring($client, 'PLUGIN_QOBUZ_DAILYQ'), 
		image => 'html/images/playlists.png',
		type  => 'playlist', #Sven - view type
		url   => \&QobuzDynPlaylist,
		passthrough => [{ type => 'DailyQ' }]
	},{
		name  => cstring($client, 'PLUGIN_QOBUZ_WEEKLYQ'), 
		image => 'html/images/playlists.png',
		type  => 'playlist', #Sven - view type
		url   => \&QobuzDynPlaylist,
		passthrough => [{ type => 'WeeklyQ' }]
	}];

#	if ($isHistory) {
#		push @$items, {
#			name  => cstring($client, 'PLUGIN_QOBUZ_DAILYQ'), 
#			image => 'html/images/playlists.png',
#			type  => 'playlist', #Sven - view type
#			url   => \&QobuzDynPlaylist,
#			passthrough => [{ type => 'DailyQ' }]
#		};
#		push @$items, {
#			name  => cstring($client, 'PLUGIN_QOBUZ_WEEKLYQ'), 
#			image => 'html/images/playlists.png',
#			type  => 'playlist', #Sven - view type
#			url   => \&QobuzDynPlaylist,
#			passthrough => [{ type => 'WeeklyQ' }]
#		};
#	}

	if ($prefs->get('showUserPurchases')) {
		addHeader({
			name  => cstring($client, 'PLUGIN_QOBUZ_USERPURCHASES'),
			#image => 'html/images/favorites.png',
		}, $items);
		push @$items, {
			name  => cstring($client, 'PLUGIN_QOBUZ_PURCHASED_ALBUMS'),
			image => 'html/images/albums.png',
			type  => 'menu',
			url   => \&QobuzUserPurchases,
			passthrough => [{ type => 'albums' }]
		};
		push @$items, {
			name => cstring($client, 'PLUGIN_QOBUZ_PURCHASED_TRACKS'),
			image => 'html/images/playlists.png',
			type  => 'menu',
			url  => \&QobuzUserPurchases,
			passthrough => [{ type => 'tracks' }]
		};
	}	
	
	if ( $accountStatus->{accountSelect} ) {
		push @$items, {
			name => cstring($client, 'PLUGIN_QOBUZ_SELECT_ACCOUNT'),
			image => __PACKAGE__->_pluginDataFor('icon'),
			url => \&QobuzSelectAccount,
		};
	}
	
	$cb->({
		items => $items
	});
}

sub searchMenu { #Sven 2025-12-29 
	my ( $client, $tags ) = @_;
	my $menuItems;

	QobuzSearch($client, sub{ my $result = shift; $menuItems = $result->{items}; }, undef, { q => $tags->{search} });

	return {
		name  => 'Qobuz', # name => cstring($client, getDisplayName()), funktioniert nicht, da der Wert von 'name' in Material Skin offenbar hard coded ist, wenn er nicht 'Qobuz' ist taucht der Menüpunkt nicht auf.
		image => 'html/images/search.png',
		type => 'menu',
		items => $menuItems,
#		url   => \&QobuzSearch, # Funktioniert an dieser Stelle nicht, deshalb wird QobuzSearch() bereits vorher aufgerufen.
#		passthrough => [{ q => $tags->{search} }],
	};
}

sub QobuzSelectAccount {
	my $cb = $_[1];

	my $account = Plugins::Qobuz::API::Common->getAccountData($_[0]);
	my $name    = $account->{userdata}->{display_name};

	my $items = [ map {
		{
			name => ($_->[0] eq $name) ? '(' . $name . ')' : $_->[0],
			url => sub {
				my ($client, $cb2, $params, $args) = @_;

				$prefs->client($client)->set('userId', $args->{id}); 

				$cb2->({ items => [{
					nextWindow => 'grandparent',
				}] });
			},
			passthrough => [{
				id => $_->[1]
			}],
			nextWindow => 'parent'
		}
	} @{ Plugins::Qobuz::API::Common->getAccountList() } ];

	$cb->({ items => $items });
}

#Sven 2025-11-06
sub QobuzValidateWebToken {
	my ($client, $cb, $params) = @_;

	return 0 unless (Plugins::Qobuz::API::Common->getToken($client) && ! Plugins::Qobuz::API::Common->getWebToken($client));
	
	my $username = Plugins::Qobuz::API::Common->username($client);

	$cb->({ items => [
		{
			type => 'textarea',
			name => cstring($client, 'PLUGIN_QOBUZ_REAUTH_DESC'),
		},{
			name  => sprintf('%s (%s)', cstring($client, 'PLUGIN_QOBUZ_PREFS_PASSWORD'), $username),
			type  => 'search',
			url  => sub {
				my ($client, $cb, $params) = @_;

				getAPIHandler($client)->login($username, $params->{search}, sub {
					my $success = shift;

					$cb->({ items => [ $success
						? {
							name => cstring($client, 'SETUP_CHANGES_SAVED'),
							nextWindow => 'home',
						}
						: {
							name => cstring($client, 'PLUGIN_QOBUZ_AUTH_FAILED'),
							nextWindow => 'parent',
						}
					] });
				},{
					cid => 1,
					token => 'success',
				});
			},
			passthrough => [ { type => 'search' } ],
		}
	] });

	return 1;
}

#Sven 2025-11-05 - get artists or playlists
# $args - contains a hash with the parameters for control
# cmd   - the command that is sent to the Qobuz server contains
# args  - Contains, if necessary, the parameters that must be sent with the command.
# type  - contains the name of the result hash, 'artists' or 'playlists'
sub QobuzGetList {
	my ($client, $cb, $params, $args) = @_;

	return if QobuzValidateWebToken(@_);

	setPaging($params, $args);

	my $type = $args->{type};

	getAPIHandler($client)->getData(sub {
		my $data = shift;
		
		my @items = ();

		if ($type eq 'artists') { @items = map { _artistItem($client, $_, 1) } @{$data->{artists}->{items}}; $data = $data->{artists}; }
		elsif ($type eq 'playlists') { @items = map { _playlistItem($_, 1) } @{$data->{playlists}->{items}}; $data = $data->{playlists}; } 

		$cb->(cbParams($client, \@items, $args, $data));
		
	}, $args);

}

#Sven 2025-10-24 - get albums from new API commands, the get command must to be in $args->{cmd}
# $args - contains a hash with the parameters for control
# cmd   - the command that is sent to the Qobuz server contains
# args  - Contains, if necessary, the parameters that must be sent with the command.
sub QobuzGetAlbums {
	my ($client, $cb, $params, $args) = @_;
	
	return if QobuzValidateWebToken(@_);

	setPaging($params, $args);
	setGenre($args, $client);
	
	$args->{type} = 'albums';

	getAPIHandler($client)->getData(sub {
		my $albums = shift;

		$albums = $albums->{albums} if exists $albums->{albums};

		my @items = map { 
			my $album = _albumItem($client, $_);
			$album->{line1} = Slim::Utils::DateTime::shortDateF($_->{released_at}) . ' - ' . $album->{line1} if ($args->{showDate});
			$album;
		} @{$albums->{items}};

		$cb->(cbParams($client, \@items, $args, $albums));
	}, $args);
}

#Sven 2025-10-23 - a radio tracklist compiled by Qobuz based on an album, an artist, or a track
sub QobuzRadio {
	my ($client, $cb, $params, $args) = @_;

	return if QobuzValidateWebToken(@_);
	
	getAPIHandler($client)->getRadio(sub {
		my $radio = shift;

		unless ($radio) {
			$log->error("Get Radio failed");
			$cb->();
			return;
		}

		my @tracks = map { _trackItem($client, $_, 1) } @{$radio->{tracks}->{items} || []};

		$cb->({ items => [
			{
				name  => cstring($client, 'PLUGIN_QOBUZ_RADIO_' . uc substr($radio->{type}, 6)) . ' - ' . $radio->{title},
				image => $radio->{images}->{large},
				type  => 'playlist',
				items => \@tracks,
			}, {
				name => _countDuration($client, $radio->{track_count}, $radio->{duration}),
				type => 'text',
			}
		]});
	}, $args);
}

#Sven 2026-02-04 Ermittelt den Wochentag aus der Unix-Zeit, 1=Mo, 2=Di, 3=Mi, 
sub _dow {
	my $dow = (shift)[6];
	return 7 if $dow == 0;
	return $dow;
}

#Sven 2026-05-08 - DailyQ und Weekly
sub QobuzDynPlaylist {
	my ($client, $cb, $params, $args) = @_;

	my $type = $args->{type};

	unless ($isHistory) {
		$cb->(cbParams($client, [], { noItems => 'PLUGIN_QOBUZ_DYNPLAYLIST_REQUIRE' }));
		return;
	}	

	return if QobuzValidateWebToken(@_);

	my $api = getAPIHandler($client);
	my $lmsUser = Plugins::Qobuz::API::Common->getLmsUser($api); #Sven 2026-02-01

	my $key = $type . '_' . $lmsUser;

	my $dynPlaylist = $cache->get($key);

	$dynPlaylist = { type => $type, lmsuser => $lmsUser, time => localtime, playlist => [] } unless ref $dynPlaylist; 

	my $cbFunc = sub {
		my $tracks = [ map { _trackItem($client, $_, 1); } @{shift->{playlist}} ];
		$cb->({ items => $tracks });
	};

	if ( scalar @{ $dynPlaylist->{playlist} } eq 0 ) {
		# Holt maximal 45 gehörte Tracks von Qobuz des Benutzers 'lmsuser' in zufälliger Reihenfolge, dazu muss das Plugin History installiert sein.
		# Das Ergebnis ist ein anonymes Array mit den Track Url's. Ob z.B. die Android Qbuz App das exakt genauso macht ist schwer zu ermitteln.
		# Meine bisherigen Versuche deuten aber in diese Richtung und diese Methode würde durchaus einen gewissen Sinn ergeben.
		# Die Qobuz API bringt zusätzlich noch eine zufällige Komponenete mit rein, denn zwei post 'dynamic/suggest' mit den gleichen Tracks liefern unterschiedliche Playlisten zurück. 
		# DailyQ und WeeklyQ verwendet den selben Algorithmus, nur die Gültigkeit der generierten Playlist unterscheidet sich.
		# Die generierte Playlist wird pro PlayerID und Lyrion-Benutzer gespeichert.
		my $request = Slim::Control::Request::executeRequest($client, ['history', 'query', ['qobuz', $lmsUser, 45, qr{^qobuz:\/\/([0-9]+)\.(flac|mp3)}]]);
		my $trackUrls;
		eval { $trackUrls = $request->getResult('_aValue'); };

		if (scalar @$trackUrls > 4) {
			# Da to_json() die Reihenfolge von Hash-Werten nicht garantiert, sondern auch verschiebt, kann diese Funktion hier nicht verwendet werden.
			# Die Function 'dynamic/suggest' scheint hier etwas empfindlich zu sein, geänderte Reihenfolgen führen zu langen Wartezeiten mit gar keinem Ergebnis oder es kommen nur wenige Tracks.
			# 1.) Die Reihenfolge der Werte 'limit', 'listened_tracks_ids' und 'track_to_analysed' muss genau so wie hier aufgezählt sein.
			# 2.) Auch die Reihenfolge der TrackIds in track_to_analysed muss mit der in listened_tracks_ids übereinstimmen.
			# Deshalb baue ich die Json Daten, die per POST gesendet werden, hier selber zusammen.

			my $toPost = '{"limit":41,"listened_tracks_ids":['; #Anzahl der Tracks die geliefert werden sollen
			
			my $listened = [];
			foreach (@$trackUrls) { 
				my ($trackId) = Plugins::Qobuz::ProtocolHandler->crackUrl($_);
				$toPost .= $trackId .','; 
				push @$listened, $trackId;
			};

			chop($toPost) if scalar @$listened;

			$toPost .= '],"track_to_analysed":[';

			my $index = 0;
			my $count = 0;
			my $analyseFunc;

			$analyseFunc = sub {
				if ($index < scalar @$listened && $count < 10) {
					my $trackId = $listened->[$index++];
					$api->getTrackInfo(sub {
						my $meta = shift;
						if ($meta) {
							$count++;
							$toPost .= '{"track_id":' . $trackId . ',"artist_id":' . $meta->{artistId} . ',"genre_id":' . $meta->{genreId} . ',"label_id":' . $meta->{labelId} . '},';
						}

						$analyseFunc->();

					}, $trackId);
				}
			}; 

			$analyseFunc->();

			chop($toPost) if $count;

			$toPost .= ']}'; # Die fertigen Daten zum posten.

			getAPIHandler($client)->getDynPlaylist(sub {
				my $playlist = shift;

				unless ($playlist) {
					$log->error("$type failed");
					$cb->();
					return;
				}

				$dynPlaylist->{playlist} = $playlist->{tracks}->{items} || [];
				if (scalar @{ $dynPlaylist->{playlist} } ) {
					my $time = localtime;
					my ($s, $m, $h) = localtime($time); 
					my $seconds = $s - $m * 60 - $h * 3600;
					my $expiry;
					if ($type eq 'DailyQ') {
						$expiry = 24 * 3600 - $seconds + 1;
					}
					else {
						my $days_until_friday = (5 - _dow($time) + 7) % 7;
						$days_until_friday = 7 if $days_until_friday == 0; # Auf 7 setzen, wenn heute Freitag
						$expiry = $time + ($days_until_friday * 86400) - $seconds  + 1;
					}	
					$cache->set($key, $dynPlaylist, $expiry); # DailyQ expires next day 00:01 and WeeklyQ expires next friday 00:01   
				}

				$cbFunc->($dynPlaylist);

			}, $toPost);
		}	
		else { 
			$cb->(cbParams($client, [], { noItems => 'PLUGIN_QOBUZ_DYNPLAYLIST_EMPTY' }));
		}
	}  
	else {
		$cbFunc->($dynPlaylist);
	}
}

#Sven 2026-02-10 - Discover
sub QobuzDiscover {
	my ($client, $cb, $params, $args) = @_;

	return if QobuzValidateWebToken(@_);

	getAPIHandler($client)->getDiscover(sub {
		my $result = shift;

		my $items = [];

		foreach (qw(new_releases ideal_discography most_streamed qobuzissims album_of_the_week press_awards playlists)) {
			my $value = $result->{$_};
			if ( $_ eq 'playlists' ) {
				my @playlists = map { _playlistItem($_, 1) } @{$value->{data}->{items}};
				my $header = {
					name  => cstring($client, 'PLUGIN_QOBUZ_DISCOVER_'. uc($value->{id})),
					image => 'html/images/playlists.png',
				};
				if ($value->{data}->{has_more}) {
					$header->{url} = \&QobuzGetList;
					$header->{passthrough} = [{ type => 'playlists', cmd => 'discover/' . $value->{id}, args => { sort => 'release_date', order => 'desc' } }];
				}
				addHeader($header, $items, \@playlists);
			}
			else {
				my @albums = map { _albumItem($client, $_) } @{$value->{data}->{items}};
				my $header = {
					name  => cstring($client, 'PLUGIN_QOBUZ_DISCOVER_'. uc($value->{id})),
					image => 'html/images/albums.png',
				};
				if ($value->{data}->{has_more}) {
					my $id = $value->{id};
					$id = 'pressAward' if $id eq 'pressAwards';
					$header->{url} = \&QobuzGetAlbums;
					$header->{passthrough} = [{ cmd => 'discover/' . $id, args => { sort => 'release_date', order => 'desc' } }];
				}
				addHeader($header, $items, \@albums);
			}
		}
		$cb->({ items => $items }) if $cb;
	}, _getGenres($client));
}

#Sven 2025-11-05 - a selection of labels suggested by qobuz
sub QobuzLabels {
	my ($client, $cb, $params, $args) = @_;

	return if QobuzValidateWebToken(@_);

	setPaging($params, $args);

	$args->{cmd}  = 'label/explore'; 

	getAPIHandler($client)->getData(sub {
		my $labels = shift;

		my $items = [ map { _labelItem($client, $_) } @{$labels->{items} || []} ];
		
		$cb->(cbParams($client, $items, $args, $labels));
	}, $args);
}

#Sven 2026-05-17
sub _labelItem {
	my ($client, $label) = @_;

	my $item = {
		name  => $label->{name},
		image => $label->{image} || 'plugins/Qobuz/html/images/label_svg.png', 
		type  => 'link',
		url   => \&QobuzLabelPage,
		passthrough => [ $label->{id} ],
	};
	$item->{line2} = $label->{description} if $label->{description};
	return $item;
}

#Sven 2025-11-05 - the label info page
sub QobuzLabelPage {
	my ($client, $cb, $params, $labelId) = @_;

	return if QobuzValidateWebToken(@_);

	my $args = { cmd => 'label/page', args => { label_id => $labelId } };

	setGenre($args, $client);

	my $api = getAPIHandler($client);

	$api->getData(sub {
		my $label = shift;

		my $items = [];

		if ($label->{description}) {
			addHeader({
				name  => cstring($client, 'DESCRIPTION'),
				image => 'plugins/Qobuz/html/images/description_svg.png',
				items => [{ name => _stripHTML($label->{description}), type => 'textarea' }],
			}, $items);
		}

		if ($label->{top_artists}) {
			my $artists = [ map { _artistItem($client, $_, 1); } @{$label->{top_artists}->{items}} ];
			if (scalar @$artists) {
				my $header = {
					name  => cstring($client, 'PLUGIN_QOBUZ_TOP_ARTISTS'),
					image => QOBUZ_ARTISTS_IMAGE,
				};
				if ($label->{top_artists}->{has_more}) {
					$header->{url} = \&QobuzGetList;
					$header->{passthrough} = [{ type => 'artists', cmd => 'label/getTopArtists', args => $args->{args} }];
				}
				addHeader($header, $items, $artists);
			}	
		}

		if ($label->{releases}) {
			for my $releases (@{$label->{releases}}) {		
				my $albums = [ map { _albumItem($client, $_) } @{$releases->{data}->{items}} ];
				if (scalar @$albums) {
					my $header = {
						name  => cstring($client, 'PLUGIN_QOBUZ_LAB_'. uc($releases->{id})),
						image => 'html/images/albums.png',
					};
					if ($releases->{data}->{has_more}) {
						my $cmd;
						if ($releases->{id} eq 'all' ) { $cmd = 'label/getAlbums'; }
						elsif ($releases->{id} eq 'awardedReleases' ) { $cmd = 'label/getAwardedReleases'; }
						if ($cmd) {
							$header->{url} = \&QobuzGetAlbums;
							$header->{passthrough} = [{ cmd => $cmd, args => { label_id => $labelId, sort => 'release_date', order => 'desc' } }];
						}
					}
					addHeader($header, $items, $albums);
				}
			}	
		}

		if ($label->{top_tracks}) {
			my $tracks = [ map { _trackItem($client, $_, 1); } @{$label->{top_tracks}} ];
			addHeader({	name  => cstring($client, 'PLUGIN_QOBUZ_TOP_TRACKS'), image => 'html/images/playlists.png' }, $items, $tracks) if scalar @$tracks;
		}

		if ($label->{playlists}) {
			my $playlists = [ map { _playlistItem($_, 1) } @{$label->{playlists}->{items}} ];
			if (scalar @$playlists) {
				my $header = {
					name  => cstring($client, 'PLUGIN_QOBUZ_PUBLICPLAYLISTS'),
					image => 'html/images/playlists.png',
				};
				if ($label->{playlists}->{has_more}) {
					$header->{url} = \&QobuzGetList;
					$header->{passthrough} = [{ type => 'playlists', cmd => 'label/getPlaylists', args => { label_id => $labelId, sort => 'release_date', order => 'desc' } }];
				}
				addHeader($header, $items, $playlists);
			}	
		}

		$api->getFavoriteStatus(sub {
			my $isFavorite = shift->{status};

			splice( @$items, 0, 0, QobuzFavoriteStatus($client, { label_ids => $labelId, add => !$isFavorite }) );
			splice( @$items, 0, 0, { name => cstring($client, 'PLUGIN_QOBUZ_LABEL') . ': ' . $label->{name}, image => 'plugins/Qobuz/html/images/label_svg.png' } ); 

			addHeader($items->[0]);

			$cb->({ items => $items }, @_ ); #calls callback function with all calling parameters

		}, { item_id => $label->{id}, type => 'label' });

	}, $args);
}

#Sven 2025-11-05 - a list of all awards 
sub QobuzAwardsExplore {
	my ($client, $cb, $params, $args) = @_;

	return if QobuzValidateWebToken(@_);

	$args = { cmd => 'award/explore', noPaging => 1 };

	setPaging($params, $args);

	getAPIHandler($client)->getData(sub {
		my $awards = shift;

		my @items = map { _awardItem($client, $_) } @{$awards->{items} || []};
		$cb->(cbParams($client, \@items, $args, $awards));
	}, $args);
}

#Sven 2026-05-17
sub _awardItem {
	my ($client, $award) = @_;

	my $item = {
		name  => $award->{name},
		image => $award->{image} || 'plugins/Qobuz/html/images/awards.png',
		type  => 'menu', #Sven - view type
		url   => \&QobuzAwardPage,
		passthrough => [ $award->{id} ],
	};
	$item->{line2} = $award->{magazine}->{name} if $award->{magazine} && $award->{magazine}->{name};
	return $item;
}

#Sven 2025-11-05 - the award info page
sub QobuzAwardPage {
	my ($client, $cb, $params, $awardId) = @_;

	return if QobuzValidateWebToken(@_);

	my $args = { cmd => 'award/page', args => { award_id => $awardId } };

	setGenre($args, $client);

	my $api = getAPIHandler($client);

	$api->getData(sub {
		my $award = shift;

		my $items = [];

		if ($award->{releases}) {
			for my $releases (@{$award->{releases}}) {		
				my @albums = map { _albumItem($client, $_) } @{$releases->{data}->{items}};
				if (scalar @albums) {
					my $header = {
						name  => ($releases->{id} eq 'all') ? cstring($client, 'PLUGIN_QOBUZ_REL_ALBUM') : uc($releases->{id}),
						image => 'html/images/albums.png',
					};
					if ($releases->{data}->{has_more}) {
						if ($releases->{id} eq 'all' ) { 
							$header->{url} = \&QobuzGetAlbums;
							$header->{passthrough} = [{ cmd => 'award/getAlbums', args => { award_id => $awardId, sort => 'release_date', order => 'desc' } }];
						}
					}
					addHeader($header, $items, \@albums);
				}
			}	
		}

		if ($award->{playlists}) {
			my @playlists = map { _playlistItem($_, 1) } @{$award->{playlists}->{items}};
			if (scalar @playlists) {
				my $header = {
					name  => cstring($client, 'PLUGIN_QOBUZ_PUBLICPLAYLISTS'),
					image => 'html/images/playlists.png',
				};
				if ($award->{playlists}->{has_more}) {
					$header->{url} = \&QobuzGetList;
					$header->{passthrough} = [{ type => 'playlists', cmd => 'award/getPlaylists', args => { award_id => $awardId, sort => 'release_date', order => 'desc' } }];
				}
				addHeader($header, $items, \@playlists);
			}	
		}
=head4 - Macht keinen Sinn 
		if ($award->{explore}) {
			my @awards = map { _awardItem($client, $_) } @{$award->{explore}->{items} || []};
			if (scalar @awards) {
				my $header = {
					name  => cstring($client, 'PLUGIN_QOBUZ_AWARDS'),
					image => 'plugins/Qobuz/html/images/awards.png',
				};
				if ($award->{explore}->{has_more}) {
					$header->{url} = \&QobuzGetList;
					$header->{passthrough} = [{ type => 'playlists', cmd => 'label/getPlaylists', args => { label_id => $awardId, sort => 'release_date', order => 'desc' } }];
				}
				addHeader($header, $items, \@awards);
			}	
		}	
=cut
		$api->getFavoriteStatus(sub {
			my $isFavorite = shift->{status};

			splice( @$items, 0, 0, QobuzFavoriteStatus($client, { award_ids => $awardId, add => !$isFavorite }) );
			splice( @$items, 0, 0, { name => cstring($client, 'PLUGIN_QOBUZ_AWARD') . ': ' . $award->{name}, image => 'plugins/Qobuz/html/images/awards_svg.png' } ); 

			addHeader($items->[0]);

			$cb->({ items => $items }, @_ ); #calls callback function with all calling parameters

		}, { item_id => $awardId, type => 'award' });

		#$cb->({ items => $items });
	}, $args);
}

#Sven 2022-05-18, 2025-09-17 v30.6.2
sub QobuzAlbums {
	my ($client, $cb, $params, $args) = @_;

	my @types = (
		['new-releases-full',	'PLUGIN_QOBUZ_DISCOVER_NEWRELEASES'], # entspricht der Liste aus den Apps.
#		['favorite/getNewReleases',	'PLUGIN_QOBUZ_RELEASE_RADAR'], #Sven 2025-10-21 - release radar
		['ideal-discography',	'PLUGIN_QOBUZ_DISCOVER_IDEALDISCOGRAPHY'],
		['qobuzissims',			'PLUGIN_QOBUZ_DISCOVER_QOBUZISSIMS'],
		['discover/albumOfTheWeek',	'PLUGIN_QOBUZ_DISCOVER_ALBUMOFTHEWEEK'], #Sven 2025-10-15 - albums of the week
		['most-streamed',		'PLUGIN_QOBUZ_DISCOVER_MOSTSTREAMED'],
		['press-awards',		'PLUGIN_QOBUZ_DISCOVER_PRESSAWARDS'],
		['editor-picks',		'PLUGIN_QOBUZ_EDITOR_PICKS'],
		['best-sellers',		'PLUGIN_QOBUZ_BESTSELLERS'],
		['most-featured',		'PLUGIN_QOBUZ_MOST_FEATURED'],
	);
	
	my $items = [];
	
	foreach (@types) { 
		my $params = { cmd => $$_[0], args => {} };
		if ($$_[1] eq 'PLUGIN_QOBUZ_RELEASE_RADAR') { 
			$params->{args}->{type} = 'artists';
			$params->{args}->{showDate} = 1;
		}	
		push @$items, {
			name => cstring($client, $$_[1]),
			url  => ($$_[0] =~ /\//) ? \&QobuzGetAlbums : \&QobuzFeaturedAlbums, #Sven 2025-10-21 - albums of the week, release radar
			image => 'html/images/albums.png',
			type  => 'albums', #Sven - view type
			passthrough => [$params]
		};
	};
	
	$cb->({ items => $items });
}

#Sven 2025-12-27
sub QobuzSearch {
	my ($client, $cb, $params, $args) = @_;
	# Wenn der Aufruf durch Slim::Menu::GlobalSearch->registerInfoProvider() (siehe Zeile 198) erfolgt ist $params undef und $args == { q => 'searchstring' }

	$args ||= {};
	my $type   = lc($args->{type}) || '';
	my $search = lc($args->{q});

	if ($type) {
		setPaging($params, $args);
	}
	else {
		$args->{args}->{limit} ||= 10;
	}	
	setGenre($args, $client);

	getAPIHandler($client)->search(sub {
		my $result = shift;

		if (!$result) {
			$cb->();
			return;
		}

		my $artists   = [ map { _artistItem($client, $_, 1) } @{$result->{artists}->{items} || [] } ];
	
		my $albums    = [ map { _albumItem($client, $_) } @{$result->{albums}->{items} || [] } ]; # : getAlbumsGrouped( $client, $result->{albums}, $search, $args->{args} );

		my $tracks    = [ map { _trackItem($client, $_, $params->{isWeb}) } @{$result->{tracks}->{items} || [] } ];
	
		my $playlists = [ map { _playlistItem($_, $params->{isWeb}) } @{$result->{playlists}->{items} || [] } ];
	
		my $items = [];

		my $func = sub { 
			my ($list, $_type, $caption) = @_;

			my $count = scalar @$list;
			my $total = $result->{$_type}->{total};
			if ($count > 0) {
				if ($type) { 
					$items = $list;
				}
				else {	
					my $header = {
						name  => cstring($client, $caption) . " ($count/$total)",
						image => $_type eq 'albums' ? 'plugins/Qobuz/html/images/Qobuz_MTL_svg_release-album.png' : "html/images/$_type.png",
					};
					if ($total > $count) {
						$header->{url} = \&QobuzSearch;
						$header->{passthrough} = [{ q => $search, type => $_type }];
					}	
					addHeader($header, $items, $list);
				}
			}
		};

		$func->($artists,   'artists',   'ARTISTS');
		$func->($albums,    'albums',    'ALBUMS');
		$func->($tracks,    'tracks',    'SONGS');
		$func->($playlists, 'playlists', 'PLAYLISTS');

		if ($type) {
			$cb->(cbParams($client, $items, $args, $result->{$type}));
		}
		else {
			$cb->({ items => $items });
		}	
	}, $args);
}

=head Sven 2026-04-19 - Macht bei Paging keinen Sinn mehr, da es nur funktionieren kann nachdem alle Alben geladen wurden und das will man ja gerade nicht.	
#Sven 2026-04-12 - Wird nur noch bei der Suche verwendet, deshalb die auskommentierten Teile
sub getAlbumsGrouped {
	my ($client, $results, $search, $args) = @_;
	
	my $releases = [];
	
	if ($results) {
		my $total = $results->{total};

		my $groupByReleaseType = (defined $args->{type}) ? $prefs->get('groupReleases') : 0;
		
		unless ($groupByReleaseType) {
			for my $album ( @{$results->{items} || []} ) {
				push @$releases, _albumItem($client, $album);
			}
			my $count = scalar @$releases;
			my $header = {
				name => cstring($client, 'ALBUMS') . " ($count/$total)",
				image => 'plugins/Qobuz/html/images/Qobuz_MTL_svg_release-album.png',
				playall => 1,
			};
			if ($total > $count) {	
				$header->{url} = \&QobuzSearch;
				$header->{passthrough} = [{ q => $search, type => 'albums' }];
			}
			my $items = [];
			addHeader($header, $items, $releases);
			return $items
		};
		
		my $albums = [];
		my $numAlbums = 0;
		my $eps = [];
		my $numEps = 0;
		my $singles = [];
		my $numSingles = 0;
		
		# group by release type
		for my $album ( @{$results->{items}} ) {
			if ($album->{duration} >= 1800 || $album->{tracks_count} > 6) {
				$album->{release_type} = ALBUM;
				$numAlbums++;
			} elsif ($album->{tracks_count} < 4) {
				$album->{release_type} = SINGLE;
				$numSingles++;
			} else {
				$album->{release_type} = EP;
				$numEps++;
			}
		}

#		my $filter = $args->{relType} || '';
#		if ($filter) {
#			for my $album ( @{$results->{items}} ) {
#				push @$releases, _albumItem($client, $album) if $album->{release_type} eq $filter;
#			}
#			return $releases;
#		}

		$results->{items} = [
			sort { $a->{release_type} cmp $b->{release_type} } @{$results->{items} || []}
		];

		my $lastReleaseType = "";
		
		for my $album ( @{$results->{items}} ) {
			my $albumItem = _albumItem($client, $album);

			if ($album->{release_type} eq ALBUM) {
				push @$albums, $albumItem;
			} elsif ($album->{release_type} eq EP) {
				push @$eps, $albumItem;
			} elsif ($album->{release_type} eq SINGLE) {
				push @$singles, $albumItem;
			}

			if ($album->{release_type} ne $lastReleaseType) {
				$lastReleaseType = $album->{release_type};
				my $relType = "";
				my $relNum = 0;
				my $relItems;
				my $relIcon = "";

				if ($lastReleaseType eq ALBUM) {
					$relType = cstring($client, 'ALBUMS');
					$relNum = $numAlbums;
					$relItems = $albums;
					$relIcon = 'plugins/Qobuz/html/images/Qobuz_MTL_svg_release-album.png';
				} elsif ($lastReleaseType eq EP) {
					$relType = cstring($client, 'RELEASE_TYPE_EPS');
					$relNum = $numEps;
					$relItems = $eps;
					$relIcon = 'plugins/Qobuz/html/images/Qobuz_MTL_svg_release-ep.png';
				} elsif ($lastReleaseType eq SINGLE) {
					$relType = cstring($client, 'RELEASE_TYPE_SINGLES');
					$relNum = $numSingles;
					$relItems = $singles;
					$relIcon = 'plugins/Qobuz/html/images/Qobuz_MTL_svg_release-single.png';
				} else {
					$relType = "Unknown";  #should never occur
				}

				my $header = {
					name => "$relType ($relNum/$total)",
					image => $relIcon,	
					playall => 1,
				};
#				if ($total > $relNum) {	
#					$header->{url} = \&QobuzSearch;
#					$header->{passthrough} = [{ q => $search, type => 'albums', relType => $lastReleaseType }];
#				}
				addHeader($header, $releases);
			}
			push @$releases, $albumItem;
		}
	}

	return $releases;
}
=cut

sub browseArtistMenu {
	my ($client, $cb, $params, $args) = @_;

	my $artistId = $params->{artist_id} || $args->{artist_id};
	if ( defined($artistId) && $artistId =~ /^\d+$/ && (my $artistObj = Slim::Schema->resultset("Contributor")->find($artistId))) {
		if (my ($extId) = grep /qobuz:artist:(\d+)/, @{$artistObj->extIds}) {
			($args->{artistId}) = $extId =~ /qobuz:artist:(\d+)/;
			return QobuzArtist($client, $cb, undef, { artistId => $args->{artistId} });
		}
		else {
			$args->{q}    = $artistObj->name;
			$args->{type} = 'artists';

			QobuzSearch($client, sub {
				my $items = shift || { items => [] };

				my $id;
				if (scalar @{$items->{items}} == 1) {
					$id = $items->{items}->[0]->{passthrough}->[0]->{artistId};
				}
				else {
					my @ids;
					$items->{items} = [ map {
						push @ids, $_->{passthrough}->[0]->{artistId};
						$_;
					} grep {
						Slim::Utils::Text::ignoreCase($_->{name} ) eq $artistObj->namesearch
					} @{$items->{items}} ];

					if (scalar @ids == 1) {
						$id = shift @ids;
					}
				}

				if ($id) {
					$args->{artistId} = $id;
					return QobuzArtist($client, $cb, $params, $args);
				}

				$cb->($items);
			}, $params, $args);

			return;
		}
	}

	$cb->([{
		title => cstring($client, 'EMPTY'),
		#type  => 'text' #Sven 2025-12-14 - Verursacht beim Anklicken einen Sprung ins Hauptmenu als Untermenü. absurdes Verhalten, nur wenn es der erste Menüpunkt ist.
	}]);
}

#Sven 2025-10-30
sub QobuzArtist {
	my ($client, $cb, $params, $args) = @_;

	my $api = getAPIHandler($client);

	$api->getArtistPage( sub {
		my $artist = shift;

		my $items = [];

		addHeader({ name => $artist->{name}, image => QOBUZ_ARTISTS_IMAGE }, $items);

		if ($artist->{biography}) {
			push @$items, {
				name  => cstring($client, 'PLUGIN_QOBUZ_BIOGRAPHY'),
				image => $artist->{image} || QOBUZ_ARTISTS_IMAGE,
				type  => 'menu',
				items => [{
					name => _stripHTML($artist->{biography}->{content}),
					type => 'textarea',
				}],
			};
		}
		else { #Sven
			push @$items, {
				name  => $artist->{name},
				image => $artist->{image} || QOBUZ_ARTISTS_IMAGE,
				#type  => 'text' #Sven 2025-12-14 - Verursacht beim Anklicken einen Sprung ins Hauptmenu als Untermenü. absurdes Verhalten, nur wenn es der erste Menüpunkt ist.
			};
		}	
 
		#Sven 2025-10-23 
		push @$items, {
			name => cstring($client, 'PLUGIN_QOBUZ_RADIO'),
			image => 'html/images/radio.png',
			type => 'menu', #'link',
			url  => \&QobuzRadio,
			passthrough => [{ artist_id => $artist->{id} }]
		};

		#Sven 2020-03-30
		#push @$items, {
		#	name => cstring($client, 'PLUGIN_QOBUZ_MANAGE_FAVORITES'),
		#	image => 'html/images/favorites.png',
		#	type => 'menu', #'link',
		#	url  => \&QobuzManageFavorites,
		#	passthrough => [{artistId => $artist->{id}, artist => $artist->{name}}]
		#};

	    my $posFavorite = scalar @$items;

		if ($artist->{top_tracks}) {
			my @tracks = map { _trackItem($client, $_, $params->{isWeb}) } @{$artist->{top_tracks}};
			if (my $count = scalar @tracks) {
				my $header = {
					name  => cstring($client, 'PLUGIN_QOBUZ_TOP_TRACKS'),
					image => 'html/images/playlists.png',
				};
				$header->{items} = \@tracks if $count > 5;
				addHeader($header, $items);
				#$header->{items} = $count > 5 ? \@tracks : [];
				push @$items, @tracks[0..4];
			}
		}

		if ($artist->{last_release}) {
			my $album = _albumItem($client, $artist->{last_release});
			addHeader({ name  => cstring($client, 'PLUGIN_QOBUZ_LASTRELEASE'), image => 'html/images/albums.png' }, $items, $album);
		}

		if ($artist->{releases}) {
			for my $releases (@{$artist->{releases}}) {		
				my @albums = map { _albumItem($client, $_) } @{$releases->{items}};
				if (scalar @albums) {
					my $header = {
						name  => cstring($client, 'PLUGIN_QOBUZ_REL_'. uc($releases->{type})),
						image => 'html/images/albums.png',
					};
					if ($releases->{has_more}) {
						$header->{url} = \&QobuzGetAlbums;
						$header->{passthrough} = [{ cmd => "artist/getReleasesList", args => { artist_id => $artist->{id}, release_type => $releases->{type}, track_size => 0, sort => 'release_date', genre_ids => '' } }];
					}
					addHeader($header, $items, \@albums);
				}				
			}	
		}

		if ($artist->{tracks_appears_on}) {
			my @tracks = map { _trackItem($client, $_, $params->{isWeb}) } @{$artist->{tracks_appears_on}};
			addHeader({ name => cstring($client, 'PLUGIN_QOBUZ_TRACKSAPPEARSON'), image => 'html/images/playlists.png' }, $items, \@tracks) if scalar @tracks;
		}

		if ($artist->{playlists}) {
			my @playlists = map { _playlistItem($_, $params->{isWeb}) } @{$artist->{playlists}->{items} || []};
			if (scalar @playlists) {
				my $header = { name => cstring($client, 'PLUGIN_QOBUZ_PUBLICPLAYLISTS'), image => 'html/images/playlists.png' };
				if ($artist->{playlists}->{has_more}) {
					$header->{url} = \&QobuzGetList;
					$header->{passthrough} = [{ type => 'playlists', cmd => 'artist/playlists', args => { artist_id => $artist->{id}, sort => 'release_date', order => 'desc' } }]; #, genre_ids => ''
				}
				addHeader($header, $items, \@playlists); 
			}	
		}

		if ($artist->{similar_artists}) {
			my @artists = map { _artistItem($client, $_, 1) } @{$artist->{similar_artists}->{items}};
			if (scalar @artists) {
				my $header = { name => cstring($client, 'PLUGIN_QOBUZ_SIMILAR_ARTISTS'), image => QOBUZ_ARTISTS_IMAGE };
				if ($artist->{similar_artists}->{has_more}) {
					$header->{url} = \&QobuzGetList;
					$header->{passthrough} = [{ type => 'artists', cmd => 'artist/getSimilarArtists', args => { artist_id => $artist->{id} } }]; #, genre_ids => ''
				}
				addHeader($header, $items, \@artists); 
			}
		}

		$api->getFavoriteStatus(sub {
			my $isFavorite = shift->{status};

			splice( @$items, $posFavorite, 0, QobuzFavoriteStatus($client, { artist_ids => $args->{artistId}, add => !$isFavorite }) );

			$cb->({ items => $items } );

		}, { item_id => $args->{artistId}, type => 'artist' });

	}, $args->{artistId}); 
}

#Sven 2025-09-15 v30.6.2
sub QobuzGenreSelection {
	my ($client, $cb, $params, $args) = @_;

	my $genreId = $args->{genreId} || '';
	my $genreFilter = _genreFilter($client, $args->{filter});

	# 1. PUFFER-LOGIK: Prüfen, ob wir von einem Checkbox-Klick kommen
	if ($params->{index} eq 0) {
		my $data = _genreData($genreFilter);
		if ($data->{refreshing}) {
			# Es ist ein interner Refresh!
			# Wir tun nichts, der Puffer bleibt erhalten.
			
			# WICHTIG: Flag sofort wieder löschen, damit ein späteres 
			# echtes, neues Betreten des Menüs wieder als "Neu" erkannt wird.
			$data->{refreshing} -= 1; 
		} else {
			# Das Flag war 0 oder nicht existent. Der Nutzer kommt gerade "frisch" 
			# aus dem Hauptmenü (oder hat das Menü neu geöffnet).
			# -> PUFFER INITIALISIEREN!
			$data->{genreList} = _getGenreList($genreFilter);
		}
	}

	getAPIHandler($client)->getGenres(sub {
		my $genres = shift;

		if (!$genres) {
			$log->error("Get genres failed");
			return;
		}

		my $items = []; 

		push @$items, {
			name => cstring($client, 'PLUGIN_QOBUZ_GENRE_SELECTALL'),
			image => 'html/images/genres.png',
			url => \&QobuzGenreToggle,
			passthrough => [{ genre => { id => '', name => cstring($client, 'PLUGIN_QOBUZ_ALL') }, filter => $genreFilter }],
			nextWindow => 'refresh'
		};

		for my $genre ( @{$genres->{genres}->{items}} ) {
			push @$items, { 
				name => $genre->{name},
				image => _isGenreSet($genre->{id}, "_$genreFilter") ? 'plugins/Qobuz/html/images/checkbox-checked_svg.png' : 'plugins/Qobuz/html/images/checkbox-empty_svg.png',
				url => \&QobuzGenreToggle,
				passthrough => [{ genre => $genre, filter => $genreFilter }],
				nextWindow => 'refresh'
			};
		}

		push @$items, {
			name => cstring($client, 'PLUGIN_QOBUZ_GENRE_STORE') . _genreCount($client, "_$genreFilter"),
			image => 'html/images/playlistsave.png',
			url => \&QobuzGenreStore,
			passthrough => [{ filter => $genreFilter }],
			nextWindow => 'parent'
		};

		$cb->({ items => $items });
	}, $genreId);
}

#Sven 2025-09-15
sub _isGenreSet {
	my ($genreId, $list_filter) = @_;
	my $result = 1;

	my $genreList = ($list_filter =~ /#/) ? $list_filter : _getGenreList($list_filter);

	unless ($genreList eq '##') { 
		$genreId = '#' . $genreId . '#';
		$result = 0 unless ($genreList=~/$genreId/);
	}

	return $result;
}

sub _getGenreList {
	my $filter = shift;

	return $tmpData->{$filter}->{genreList} || '##' if $filter =~ /_/; # holt die Genres aus dem Cache

	return $prefs->get($filter) || '##'; 
}

#Sven 2025-09-16
sub _getGenres {
	my ($client, $filter) = @_;

	my $genreList = _getGenreList(_genreFilter($client, $filter));
	
	$genreList = substr($genreList, 1, length($genreList)-2);
	$genreList=~s/##/,/g;
	
	return $genreList;
}

sub _genreCount {
	my ($client, $filter) = @_;

	my $genreList = _getGenreList($filter);

	return "\x{00A0}(" . cstring($client, 'PLUGIN_QOBUZ_ALL') . ')' if $genreList eq '##';

	my $count = ($genreList =~ tr/#//) / 2; 

	return "\x{00A0}($count)";
}

#Sven 2026-05-05
sub _genreFilter {
	my ($client, $name) = @_;
	$name ||= '';
	return "genres$name" . $prefs->client($client)->get('userId'); 
}

sub _genreData {
	my $filter = '_' . shift;

	$tmpData->{$filter} = { refreshing => 0 } unless ref $tmpData->{$filter};
	return $tmpData->{$filter};
}

sub QobuzGenreToggle {
	my ($client, $cb, $params, $args) = @_;

	my $genreId   = $args->{genre}->{id} || '';
	my $filter    = $args->{filter};
	my $genreList = _getGenreList("_$filter"); 

    my $checked = 0;
	$genreId = '#' . $genreId . '#';
	if ($genreId eq '##' || $genreList eq '##') {
		$genreList = $genreId;
		$checked = 1;
	}
	else {
		unless ($genreList=~s/$genreId//) { $genreList .= $genreId; $checked = 1 };
	}

	my $data = _genreData($filter);

	$data->{genreList} = $genreList;

	# 2. DIE FAHNE SETZEN!
	# Das sagt dem gleich folgenden QobuzGenreSelection()), dass er den Puffer in Ruhe lassen soll.
	$data->{refreshing} = 1;
	

	$cb->({ # only used for Defaul-Skin or Clasic-Skin, it can be empty for JsonRPC Clients like Material - $cb->();
		items => [{
			name  => $args->{genre}->{name},
			image => $checked ? 'plugins/Qobuz/html/images/checkbox-checked_svg.png' : 'plugins/Qobuz/html/images/checkbox-empty_svg.png',
			showBriefly => 1,
		}],
	});
}

sub QobuzGenreStore {
	my ($client, $cb, $params, $args) = @_;

	my $filter = $args->{filter};

	$prefs->set($filter, _getGenreList("_$filter"));
	
	$cb->();
}

#Sven 2026-04-10 - Paging
sub QobuzFeaturedAlbums {
	my ($client, $cb, $params, $args) = @_;

	setPaging($params, $args);
	setGenre($args, $client);

	$args->{args}->{type} = $args->{cmd}; # Setzt den Listentyp im API-Call

	getAPIHandler($client)->getFeaturedAlbums(sub {
		my $albums = shift->{albums};

		my @items = map { _albumItem($client, $_) } @{$albums->{items}};

		$cb->(cbParams($client, \@items, $args, $albums));

	}, $args); 
}

#Sven 2026-04-26 - Aufteilung auf gekaufte Albums und Titel umd PAging zu ermöglichen.
sub QobuzUserPurchases {
	my ($client, $cb, $params, $args) = @_;

	setPaging($params, $args);

	my $type = $args->{args}->{type} = $args->{type};

	getAPIHandler($client)->getUserPurchases(sub {
		my $result = shift;

		my $func = $type eq 'albums' ? \&_albumItem : \&_trackItem;
		
		my $items = [ map { $func->($client, $_, 1) } @{$result->{$type}->{items}} ];

		$cb->(cbParams($client, $items, $args, $result->{$type}));
	});
}

#Sven 2022-05-20, 2023-02-11 v2.8.1, 2026-04-26 - Wegen Sortierung bisher keine Paging Unterstützung
sub QobuzUserFavorites {
	my ($client, $cb, $params, $args) = @_;

	my $type = $args->{type};

	getAPIHandler($client)->getUserFavorites(sub {
		my $favorites = shift;
		
		my $items;
		my @aItem = @{$favorites->{$type}->{items}};
		if (scalar @aItem) {
			my %funcs = ( artists => \&_artistItem, albums => \&_albumItem, tracks => \&_trackItem, labels => \&_labelItem, awards => \&_awardItem );
			my $itemFn = $funcs{$type};
			my $isArtist = $type eq 'artists';
			my $sortFavsAlphabetically = ($isArtist && $prefs->get('sortArtistsAlpha')) ? 1 : $prefs->get('sortFavsAlphabetically') || 0;
			$isArtist = $sortFavsAlphabetically && $isArtist ? 1 : 0;

			$items = [ map { $itemFn->($client, $_, 1, $isArtist) } @aItem ];
			
			if ( $sortFavsAlphabetically ) {
				my $sortFields = { artists => ['name', 'name'], albums => ['line1', 'name'], tracks => ['line1', 'line2'], labels => ['name', 'name'], awards => ['name', 'name']};
				my $sortField  = $sortFields->{$type}[$sortFavsAlphabetically - 1];
				@$items = sort { Slim::Utils::Text::ignoreCaseArticles($a->{$sortField}) cmp Slim::Utils::Text::ignoreCaseArticles($b->{$sortField}) } @$items;
			};
		}

		$cb->( { items => $items } );
	}, $args);
}

#Sven 2022-05-17 look at 'Info multi API-Calls.pm'
sub QobuzManageFavorites {
	my ($client, $cb, $params, $args) = @_;
	
	my $status = { artist => -1, album => -1, track => -1};
	my $call = {};
	
	my $callback = sub {
		my $result = shift;
		
		if ($result) {
			$status->{$result->{type}} = $result->{status};
			delete($call->{$result->{type}});
		}
		
		return if (scalar keys %$call > 0);
		
		my $items = [];
		
		if ($status->{artist} > -1) {
			push @$items, {
				name => cstring($client, $status->{artist} ? 'PLUGIN_QOBUZ_REMOVE_FAVORITE' : 'PLUGIN_QOBUZ_ADD_FAVORITE', cstring($client, 'ARTIST') . " '" . $args->{artist} . "'"),
				#name => cstring($client, 'ARTIST') . ':' . $args->{artist},
				#line2 => cstring($client, $status->{artist} ? 'PLUGIN_QOBUZ_REMOVE_FAVORITE' : 'PLUGIN_QOBUZ_ADD_FAVORITE', $args->{artist}),
				image => 'html/images/favorites.png', #$status->{artist} ? 'html/images/favorites_remove.png' : 'html/images/favorites.png',
				type => 'link',
				url  => \&QobuzSetFavorite,
				passthrough => [{ artist_ids => $args->{artistId}, add => !$status->{artist} }],
				nextWindow => 'grandparent'
			};
		}
		
		if ($status->{album} > -1) {
			my $albumname = cstring($client, 'ALBUM') . " '" . $args->{album} . ($args->{artist} ? ' ' . cstring($client, 'BY') . ' ' . $args->{artist} : '') . "'";
			push @$items, {
				name => cstring($client, $status->{album} ? 'PLUGIN_QOBUZ_REMOVE_FAVORITE' : 'PLUGIN_QOBUZ_ADD_FAVORITE', $albumname),
				#name => $args->{album},
				#line2 => cstring($client, $status->{album} ? 'PLUGIN_QOBUZ_REMOVE_FAVORITE' : 'PLUGIN_QOBUZ_ADD_FAVORITE', $args->{album}),
				image => 'html/images/favorites.png', #$status->{album} ? 'html/images/favorites_remove.png' : 'html/images/favorites.png',
				type => 'link',
				url  => \&QobuzSetFavorite,
				passthrough => [{ album_ids => $args->{albumId}, add => !$status->{album} }],
				nextWindow => 'grandparent'
			};
		};
		
		if ($status->{track} > -1) {
			push @$items, {
				name => cstring($client, $status->{track} ? 'PLUGIN_QOBUZ_REMOVE_FAVORITE' : 'PLUGIN_QOBUZ_ADD_FAVORITE', cstring($client, 'TRACK') . " '" . $args->{title} . "'"),
				#name => $args->{title},
				#line2 => cstring($client, $status->{track} ? 'PLUGIN_QOBUZ_REMOVE_FAVORITE' : 'PLUGIN_QOBUZ_ADD_FAVORITE', $args->{title}),
				image => 'html/images/favorites.png', # $status->{track} ? 'html/images/favorites_remove.png' : 'html/images/favorites.png',
				type => 'link',
				url  => \&QobuzSetFavorite,
				passthrough => [{ track_ids => $args->{trackId}, add => !$status->{track} }],
				nextWindow => 'grandparent'
			};
		}
		
		$cb->( { items => $items } );
	};
	
	my $api = getAPIHandler($client);
	
	if ($args->{artist} && $args->{artistId}) {
		$call->{artist} = 1;
		$api->getFavoriteStatus($callback, { item_id => $args->{artistId}, type => 'artist' });
	}
	
	if ($args->{album}  && $args->{albumId}) {
		$call->{album} = 1;
		$api->getFavoriteStatus($callback, { item_id => $args->{albumId}, type => 'album' });
	}
	
	if ($args->{title}  && $args->{trackId}) {
		$call->{track} = 1;
		$api->getFavoriteStatus($callback, { item_id => $args->{trackId},  type => 'track' });
	}
}

#Sven 2026-05-12
sub QobuzFavoriteStatus{
	my ($client, $args) = @_;

	my $refresh = ($args->{add} || substr(getParams('item_id'),0,2) ne '9.') ? 'refresh' : ($args->{track_ids} ? 'grandparent' : 'parent'); 

	return {
		name  => cstring($client, $args->{add} ? 'PLUGIN_QOBUZ_ADD_FAVORITE' : 'PLUGIN_QOBUZ_REMOVE_FAVORITE', $args->{title} || ''),
		image => $args->{add} ? 'plugins/Qobuz/html/images/favorite_remove_svg.png' : 'plugins/Qobuz/html/images/favorite_add_svg.png',
		type => 'link',
		url  => \&QobuzSetFavorite,
		passthrough => [$args],
		nextWindow => $refresh,
	};
 }

#Sven 2022-05-13
sub QobuzSetFavorite {
	my ($client, $cb, $params, $args) = @_;

	getAPIHandler($client)->setFavorite(sub { 
		my $result = shift;
		$cb->({ items => [{
			name        => $args->{add} ? 'hinzugefügt' : 'entfernt' , # cstring($client, 'PLUGIN_QOBUZ_MUSIC_ADDED'),
			showBriefly => 1,
			nextWindow  => 'grandparent',
		}] });
	}, $args);
}

#Sven 2022-05-23, 2025-11-03. 2026-04-27
sub QobuzUserPlaylists {
	my ($client, $cb, $params, $args) = @_;

	setGenre($args, $client);

	getAPIHandler($client)->getUserPlaylists(sub {
		my $result = shift;

		$result = $result->{playlists};

		$cb->(cbParams($client, _getPlaylists($result, $params->{isWeb}, 1), $args, $result));
	}, $args);
}

#Sven 2025-09-17 v30.6.2
sub QobuzPlaylistTags {
	my ($client, $cb, $params, $args) = @_;

	getAPIHandler($client)->getTags(sub {
		my $tags = shift;

		if ($tags && ref $tags) {
			my $lang = lc(preferences('server')->get('language'));

			my @items = map {
				{
					name => $_->{name}->{$lang} || $_->{name}->{en},
					image => 'html/images/playlists.png',
					type  => 'playlists', #Sven
					url   => \&QobuzPublicPlaylists,
					passthrough => [{ tags => $_->{id} }]
				};
			} @$tags;

			unshift @items, {
				name  => cstring($client, 'PLUGIN_QOBUZ_ALL'),
				image => 'html/images/playlists.png',
				type  => 'playlists',
				url   => \&QobuzPublicPlaylists,
				passthrough => [{ tags => 'all' }]
			};

			$cb->( { items => \@items } );
		}
		else { $cb->(); } 
	});
}

#Sven 2025-09-17 v30.6.2
sub QobuzPublicPlaylists {
	my ($client, $cb, $params, $args) = @_;

	setPaging($params, $args);
	setGenre($args, $client);

	getAPIHandler($client)->getPublicPlaylists(sub {
		my $result = shift;

		$result = $result->{playlists};

		$cb->(cbParams($client, _getPlaylists($result, $params->{isWeb}), $args, $result));
	}, $args);
}

#Sven 2026-04-27
sub _getPlaylists {
	my ($result, $isWeb, $sort) = @_;

	my $playlists = [];

	foreach ( @{$result->{items}} ) {
		push @$playlists, _playlistItem($_, $isWeb) if defined $_->{tracks_count} && $_->{tracks_count};
	}

	if ($sort && $prefs->get('sortPlaylists')) {
		@$playlists = sort { Slim::Utils::Text::ignoreCaseArticles($a->{name}) cmp Slim::Utils::Text::ignoreCaseArticles($b->{name}) } @$playlists;
	}

	return $playlists;
}

#Sven 2022-05-23, 2026-04-27
sub QobuzSimilarPlaylists {
	my ($client, $cb, $params, $args) = @_;

	setPaging($params, $args);
	setGenre($args, $client);

	getAPIHandler($client)->getSimilarPlaylists(sub {
		my $result = shift;

		$result = $result->{similarPlaylist};

		$cb->(cbParams($client, _getPlaylists($result, $params->{isWeb}), $args, $result));
	}, $args);
}

#Sven 2022-05-11 called from _playlistItem
sub QobuzPlaylistItem {
	my ($client, $cb, $params, $playlist, $args) = @_;

	my $items = []; #ref array

	push @$items, {
		name  => $args->{name},
		name2 => $args->{owner},
		image => $args->{image},
		url   => \&QobuzPlaylistGetTracks,
		passthrough => [ $playlist->{id} ],
		type  => 'playlist',
		favorites_url  => 'qobuz://playlist:' . $playlist->{id} . '.qbz', #fügt dem Contextmenu"In Favoriten speichern" hinzu
		favorites_type => 'playlist',
	};

	push @$items, {
		name => _countDuration($client, $playlist->{tracks_count}, $playlist->{duration}),
		type => 'text',
	};

	my $temp = $playlist->{genres};
	if ($temp && ref $temp && scalar @$temp) {
		my $genre_s = '';
		map { $genre_s .= ', ' . $_->{name} } @$temp;
		push @$items, { name  => substr($genre_s, 2), label => 'GENRE', type => 'text' };
	}

	my $temp = $playlist->{featured_artists}; # is a ref of an array
	if ($temp && ref $temp && scalar @$temp) {
		my @artists = map { _artistItem($client, $_, 1) } @$temp;
		push @$items, { name => cstring($client, 'ARTISTS'), items => \@artists } if scalar @artists; #Ausgewählte Künstler
	}

	if ($playlist->{description}) {
		push @$items, {
			name  => cstring($client, 'DESCRIPTION'),
			items => [{ name => _stripHTML($playlist->{description}), type => 'textarea'}],
		};
	}

	#Sven 2022-05-23 created_at ist vom Datum her immer gleich public_at, die Uhrzeit in public_at ist immer 00:00:00.
	push @$items, {
		name => cstring($client, 'PLUGIN_QOBUZ_RELEASED_AT') . cstring($client, 'COLON') . ' ' . Slim::Utils::DateTime::shortDateF($playlist->{created_at}),
		type  => 'text'
		} if $playlist->{created_at};

	push @$items, {
		name => cstring($client, 'PLUGIN_QOBUZ_UPDATED_AT') . cstring($client, 'COLON') . ' ' . Slim::Utils::DateTime::shortDateF($playlist->{updated_at}),
		type  => 'text'
		} if $playlist->{updated_at};

	push @$items, {
		name => cstring($client, 'PLUGIN_QOBUZ_SIMILAR_PLAYLISTS'),
		type => 'playlists', #'link',
		url  => \&QobuzSimilarPlaylists,
		passthrough => [{ playlist_id => $playlist->{id} }],
		} if $playlist->{stores};

	if ($playlist->{owner}->{id} eq getAPIHandler($client)->userId) { #Sven
		push @$items, {
			name => cstring($client, 'PLUGIN_QOBUZ_REMOVE_PLAYLIST'),
			items => [{
				name => $args->{name} . ' - ' . cstring($client, 'PLUGIN_QOBUZ_REMOVE_PLAYLIST'),
				type => 'link',
				url  => \&QobuzPlaylistCommand,
				passthrough => [{ playlist_id => $playlist->{id}, command => 'delete' }],
				nextWindow => 'grandparent'
			}],	
		};
	}
	else {
		push @$items, {
			name => cstring($client, 'PLUGIN_QOBUZ_SUBSCRIPTION'),
			type => 'link',
			url  => \&QobuzPlaylistSubscription,
			passthrough => [ $playlist ],
		};
	}
	$cb->({ items => $items });
}

#Sven 2022-05-14
sub QobuzPlaylistSubscription {
	my ($client, $cb, $params, $playlist) = @_;
	
	getAPIHandler($client)->getUserPlaylists(sub {
		my $playlists = shift;
		my $isSubscribed;
		
		if ($playlists && ref $playlists && $playlists->{playlists} && ref $playlists->{playlists}) {
			my $playlistId = $playlist->{id};
			foreach (@{$playlists->{playlists}->{items}}) {
				if ($isSubscribed = ($_->{id} eq $playlistId)) { last };
			};
		};
		
		my $item = {
			name => $playlist->{name} . ' - ' . cstring($client, $isSubscribed ? 'PLUGIN_QOBUZ_UNSUBSCRIBE' : 'PLUGIN_QOBUZ_SUBSCRIBE'),
			#line2 => cstring($client, $subscribed ? 'PLUGIN_QOBUZ_UNSUBSCRIBE' : 'PLUGIN_QOBUZ_SUBSCRIBE'), #cstring($client, 'ALBUM')),
			image => 'html/images/favorites.png', #$isFavorite ? 'html/images/favorites_remove.png' : 'html/images/favorites_add.png',
			type => 'link',
			url  => \&QobuzPlaylistCommand,
			passthrough => [{ playlist_id => $playlist->{id}, command => ($isSubscribed ? 'unsubscribe' : 'subscribe') }],
			nextWindow => 'grandparent' #'parent' ist zu wenig, 'grandparent' spring zurück auf die Liste
		};
		
		$cb->( { items => [$item] } );
	});
}

#Sven 2022-05-14
sub QobuzPlaylistCommand {
	my ($client, $cb, $params, $args) = @_;
	
	getAPIHandler($client)->doPlaylistCommand(sub { $cb->() }, $args);
}

#Sven 2019-03-19
#Slim::Utils::DateTime::timeFormat(),
sub _sec2hms {
	my $seconds = @_[0] || '0';

	my $minutes   = int($seconds / 60);
	my $hours     = int($minutes / 60);
	return $hours eq 0 ? sprintf('%02s:%02s', $minutes, $seconds % 60) : sprintf('%s:%02s:%02s', $hours, $minutes % 60, $seconds % 60); 
}

#Sven 2019-04-11, 2022-05-10
sub _quality {
	my $meta = @_[0];
	
	$meta = $meta->{tracks}->{items}[0] if $meta->{tracks}; #Sven 2020-12-31 liest die Qualität aus dem 1. Track wenn $meta ein Album und kein Track ist
	
	my $channels = $meta->{maximum_channel_count};
	if ($channels) {
		if ($channels eq 2) { $channels = '' } # 'Stereo'
		elsif ($channels eq 1) { $channels = ' - Mono' }
		else { $channels = ' - ' . $channels . ' Kanal' }
		
		return $meta->{maximum_bit_depth} . '-Bit ' . $meta->{maximum_sampling_rate} . 'kHz' . $channels;
	}
	return $meta->{bitrate};
}

#Sven 2022-05-05 shows album infos before playing music, it is an enhanced version.
#Sven 2025-12-13 The album view is now configurable
sub QobuzGetTracks {
	my ($client, $cb, $params, $args) = @_;
	my $albumId = $args->{album_id};

	my $api = getAPIHandler($client);
	
	$api->getAlbum(sub {
		my $album = shift;
		my $items = [];
		
		if (!$album) {  # the album does not exist in the Qobuz library
			$log->warn("Get album ($albumId) failed");
			$api->getFavoriteStatus(sub {
				my $isFavorite = shift->{status};

				push @$items, {
					name  => cstring($client, 'PLUGIN_QOBUZ_ALBUM_NOT_FOUND'),
					#type  => 'text' #Sven 2025-12-14 - Verursacht beim Anklicken einen Sprung ins Hauptmenu als Untermenü. absurdes Verhalten, nur wenn es der erste Menüpunkt ist.
				};

				QobuzFavoriteStatus($client, { album_ids => $albumId, title => $args->{album_title}, add => 0 }) if $isFavorite; # if it's an orphaned favorite, let the user delete it

				$cb->( { items => $items }, @_ );
			}, { type => 'albums' }); #Sven 2023-10-09
			return;
		}
		elsif (!$album->{streamable} && !$prefs->get('playSamples')) {  # the album is not streamable
			push @$items, {
				name  => cstring($client, 'PLUGIN_QOBUZ_NOT_AVAILABLE'),
				#type  => 'text' #Sven 2025-12-14 - Verursacht beim Anklicken einen Sprung ins Hauptmenu als Untermenü. absurdes Verhalten, nur wenn es der erste Menüpunkt ist.
			};

			$cb->({
				items => $items,
			}, @_ );
			return;
		}

		my $artistname = $album->{artist}->{name} || '';
		my $albumname  = ($artistname && $album->{title} ? $artistname . ' - ' . $album->{title} : $artistname) || '';
		my $conductorname;
		my $albumcredits = $albumname . "\n\n";

		my $totalDuration = 0;
		my $trackNumber = 0;
		my $tracks = [];
		my $works = {};
		my $lastwork = "";
		my $worksfound = 0;
		my $noComposer = 0;
		my $workHeadingPos = 0;
		my $workPlaylistPos = $prefs->get('workPlaylistPosition');
		my $currentComposer = "";
		my $lastComposer = "";
		my $worksWorkId = "";
		my $worksWorkIdE = "";
		my $lastWorksWorkId = "";
		my $discontigWorks;
		my $workComposer;
		my $lastDisc;
		my $discs = {};
		my $performers = {};

		foreach my $track (@{$album->{tracks}->{items}}) {
			_addPerformers($client, $track, $performers);
			$totalDuration += $track->{duration};
			$albumcredits  .= _trackCredits($client, $track) . "\n\n";
			$conductorname  = _getConductor($track) unless ($conductorname);
			my $formattedTrack = _trackItem($client, $track);
			my $work = delete $formattedTrack->{work};

			# create a playlist for each "disc" in a multi-disc set except if we've got works (mixing disc & work playlists would go horribly wrong or at least be confusing!)
			if ( $prefs->get('showDiscs') && $formattedTrack->{media_count} > 1 && !$work ) {
				my $discId = delete $formattedTrack->{media_number};
				$discs->{$discId} = {
					index => $trackNumber,
					title => string('DISC') . " " . $discId,
					image => $formattedTrack->{image},
					tracks => []
				} unless $discs->{$discId};

				push @{$discs->{$discId}->{tracks}}, $formattedTrack;
			}

			if ( $work ) {
				# Qobuz sometimes would f... up work names, randomly putting whitespace etc. in names - ignore them
				my $workId = Slim::Utils::Text::matchCase(Slim::Utils::Text::ignorePunct($work));
				$workId =~ s/\s//g;
				my $displayWorkId = Slim::Utils::Text::matchCase(Slim::Utils::Text::ignorePunct($formattedTrack->{displayWork}));
				$displayWorkId =~ s/\s//g;

				# Unique work identifier, used to keep tracks together even if composer is missing from some, but on the other hand
				# still distinguishing between works with the same name but different composer!
				$currentComposer = $track->{composer}->{name};
				if ( $workId eq $lastwork && (!$lastComposer || !$currentComposer || $lastComposer eq $currentComposer) ) {
					# Stick with the previous value! ($worksWorkId = $worksWorkId;)
				} elsif ( $currentComposer ) {
					$worksWorkId = $displayWorkId;
				} else {
					$worksWorkId = $workId;
				}

				# Extended Work ID: will usually not change, but we need to keep non-contiguous tracks from the same work
				# separate if the user has chosen to integrate playlists with the work titles.
				$worksWorkIdE = $worksWorkId;
				if ( $workPlaylistPos eq "integrated" && $works->{$worksWorkId} ) {
					if ( $worksWorkId ne $lastWorksWorkId ) {
						$discontigWorks->{$worksWorkId} = $worksWorkId . $trackNumber;
					}
					if ( $discontigWorks->{$worksWorkId} ) {
						$worksWorkIdE = $discontigWorks->{$worksWorkId};
					}
				}

				if ( !$works->{$worksWorkIdE} ) {
					$works->{$worksWorkIdE} = {   # create a new work object
						index => $trackNumber,		# index of first track in the work
						title => $formattedTrack->{displayWork},
						tracks => []
					} ;
				}

				# Create new work heading, except when the user has chosen integrated playlists - in that case
				# the work-playlist headings will be spliced in later.
				if ( ( $workId ne $lastwork ) || ( $lastComposer && $currentComposer && $lastComposer ne $currentComposer ) ) {
					$workHeadingPos = push @$tracks,{
						name  => $formattedTrack->{displayWork},
						#type  => 'text' #Sven 2023-10-08 auskommentiert damit das Werk nicht hochgestellt angezeigt wird.
					} unless $workPlaylistPos eq "integrated";

					$noComposer = !$track->{composer}->{name};
					$lastwork = $workId;
				} else {
					$worksfound = 1;   # we found two consecutive tracks with the same work
				}

				push @{$works->{$worksWorkIdE}->{tracks}}, $formattedTrack if $works->{$worksWorkIdE};


				if ($noComposer && $track->{composer}->{name} && $workHeadingPos) {  #add composer to work title if needed
					# Can't update @$items here when using integrated playlists, as there is no work heading in @$items at present.
					if ( $workPlaylistPos ne "integrated" ) {
						@$tracks[$workHeadingPos-1]->{name} = $formattedTrack->{displayWork};
					}
					$works->{$worksWorkIdE}->{title} = $formattedTrack->{displayWork};
					$noComposer = 0;
				}

				# If we're using integrated playlists, save the work title to a temporary structure (including composer if possible -
				# i.e. when there's a composer in at least one of the tracks in the work group).
				if ( $workPlaylistPos eq "integrated" && (!$workComposer->{$worksWorkIdE}->{displayWork} || $track->{composer}->{name}) ) {
					$workComposer->{$worksWorkIdE}->{displayWork} = $formattedTrack->{displayWork};
				}

				$lastComposer = $track->{composer}->{name};

			} elsif ($lastwork ne "") {  # create a separator line for tracks without a work
				push @$tracks,{
					name  => "————————",
					type  => 'text'
				};
				$lastwork = "";
				$noComposer = 0;
			}

			$trackNumber++;
			$lastWorksWorkId = $worksWorkId;

			push @$tracks, $formattedTrack;
		}

		# create a playlist for each "disc" in a multi-disc set except if we've got works (mixing disc & work playlists would go horribly wrong or at least be confusing!)
		if ( $prefs->get('showDiscs') && scalar keys %$discs && !(scalar keys %$works) && _isReleased($album) ) {
			foreach my $disc (sort { $discs->{$b}->{index} <=> $discs->{$a}->{index} } keys %$discs) {
				my $discTracks = $discs->{$disc}->{tracks};

				# insert disc item before the first of its tracks
				splice @$tracks, $discs->{$disc}->{index}, 0, {
					name => $discs->{$disc}->{title},
					image => 'html/images/albums.png', #image => $discs->{$disc}->{image},
					type => 'playlist',
					playall => 1,
					url => \&QobuzWorkGetTracks,
					passthrough => [{
						tracks => $discTracks
					}],
					items => $discTracks
				} if scalar @$discTracks > 1;
			}
		}

		if (scalar keys %$works && _isReleased($album) ) { # don't create work playlists for unreleased albums
			# create work playlists unless there is only one work containing all tracks
			my @workPlaylists = ();
			if ( $worksfound || $workPlaylistPos eq "integrated" ) {   # only proceed if a work with more than 1 contiguous track was found
				my $workNumber = 0;
				foreach my $work (sort { $works->{$a}->{index} <=> $works->{$b}->{index} } keys %$works) {
					my $workTracks = $works->{$work}->{tracks};
					if ( scalar @$workTracks && ( scalar @$workTracks < $album->{tracks_count} || $workPlaylistPos eq "integrated" ) ) {
						if ( $workPlaylistPos eq "integrated" ) {
							# Add playlist as work heading (or just add as text if only one track in the work)
							my $idx = $works->{$work}->{index} + $workNumber;
							my $workTrackCount = @$workTracks;
							if ( $workTrackCount == 1 || $workTrackCount == $album->{tracks_count} ) {
								if ( $worksfound ) {
									splice @$tracks, $idx, 0, {
										name => $workComposer->{$work}->{displayWork},
										image => 'html/images/playlists.png',
									};
								} else {
									splice @$tracks, $idx, 0, {
										name => $workComposer->{$work}->{displayWork},
										type => 'text',
									}
								}
							} else {
								splice @$tracks, $idx, 0, {
									name => $workComposer->{$work}->{displayWork},
									image => 'html/images/playall.png',
									type => 'playlist',
									playall => 1,
									url => \&QobuzWorkGetTracks,
									passthrough => [{
										tracks => $workTracks
									}],
									items => $workTracks
								};
							}
							$workNumber++;
						} else {
							push @workPlaylists, {
								name => $works->{$work}->{title},
								image => 'html/images/playall.png',
								type => 'playlist',
								playall => 1,
								url => \&QobuzWorkGetTracks,
								passthrough => [{
									tracks => $workTracks
								}],
								items => $workTracks
							}
						}
					}
				}
			}
			if ( @workPlaylists ) {
				# insert work playlists according to the user preference
				if ( $workPlaylistPos eq "before" ) {
					unshift @$tracks, @workPlaylists;
				} elsif ( $workPlaylistPos eq "after" ) {
					push @$tracks, @workPlaylists;
				}
			}
		}

		#Page starts here

		#The playlist must not be at the beginning, otherwise the add/play buttons are displayed at the top, but they have no function here.
		#Therefore the genre is displayed first in the first line.
		#Since 2022 that's not true any more, playlist can be the first element.

		
		#Sven 2025-12-13
		my $dptype = $prefs->get('albumViewType');
		if ( $dptype eq "0") {
			#Playlist
			push @$items, {
				# name  => ($album->{version} ? $album->{title} . ' - ' . $album->{version} : $album->{title}),
				name  => sprintf('%s %s %s', ($album->{version} ? $album->{title} . ' - ' . $album->{version} : $album->{title}), cstring($client, 'BY'), $album->{artist}->{name}),
				# line1 => $album->{title} || '', 
				line2 => _countDuration($client, $album->{tracks_count}, $totalDuration). ' - (' . _quality($album) . ')',
				image => ref $album->{image} ? $album->{image}->{large} : $album->{image},
				type  => 'playlist',
				items => $tracks,
				favorites_url  => 'qobuz:album:' . $album->{id}, # war ein funktionierender Fix für Material-Skin, dort fehlte bis 2.9.5 der Menüpunkt "In Favoriten speichern" im Contextmenu
				favorites_type => 'playlist', # Standardwert ist 'playlist', sonst 'audio' (für Radios oder Tracks)
			};
		}
		elsif ( $dptype eq "1") {
			$items = $tracks;
		}

		my $posFavorite = scalar @$items;

		if (!_isReleased($album) ) {
			my $rDate = _localDate($album->{release_date_stream});
			push @$items, {
				name  => cstring($client, 'PLUGIN_QOBUZ_NOT_RELEASED') . ' (' . $rDate . ')',
				type  => 'text'
			};
		}

		push @$items, { name => $album->{genre}, label => 'GENRE', type  => 'text' };

		my $item = {};
		my $artist_ref = {}; #Referenz auf anonymen Hash

		if ($conductorname) {
			$artist_ref = lc($conductorname) eq lc($artistname) ? { name => $artistname, id => $album->{artist}->{id} } : { name => $conductorname };
			$item = _artistItem($client, $artist_ref);
			$item->{label} = 'CONDUCTOR';
			push @$items, $item;
		}

		if (!$artist_ref->{id} and ($artist_ref = $album->{artist})) { #only if artist != conductor
			if ($artist_ref->{id} != 145383) { # no Various Artists
				$item = _artistItem($client, $artist_ref);
				$item->{label} = 'ARTIST';
				push @$items, $item;
			}
		}

		if ($item = $album->{composer}) {
			if ($item->{id} != 573076 and $item->{id} != $artist_ref->{id}) { #no Various Composers && artist != composer
				$item = _artistItem($client, $item);
				$item->{label} = 'COMPOSER';
				push @$items, $item;
			}
		}

		#Sven 2022-05-05
		my $temp = $album->{artists}; # is a ref of an array
		if ($temp && ref $temp && scalar @$temp > 1) {
			my @artists = map { _artistItem($client, $_, 1) } @$temp;
			push @$items, { name => cstring($client, 'ARTISTS'), items => \@artists } if scalar @artists;
		}

		if ($album->{description}) {
			push @$items, {
				name  => cstring($client, 'DESCRIPTION'),
				items => [{ name => _stripHTML($album->{description}), type => 'textarea' }],
			};
		}

		#Sven 2022-05-24 - Stand heute Januar 24 scheint Focus von Qobuz nicht mehr unterstützt zu werden, items_focus ist immer undef;
		my $focusItems = $album->{items_focus};
		if ($focusItems && ref $focusItems && scalar @$focusItems) {
			my @fItems = map { {
				name => $_->{title},
				image => $_->{image},
				items => [{ name => $_->{accroche}, type => 'textarea' }],
				#url => \&QobuzFocus,
				#passthrough => [ { focus_id => $_->{id} }],
				}
			} @$focusItems;
			push @$items, { name  => cstring($client, 'PLUGIN_QOBUZ_FOCUS'), items => \@fItems } if scalar @fItems;
		}

		#Sven 2022-05-01
		my $awards = $album->{awards};
		if ($awards && ref $awards && scalar @$awards) {
			my @awItems = map { {
				name => Slim::Utils::DateTime::shortDateF($_->{awarded_at}) . ' - ' . $_->{name},
				image => 'html/images/albums.png',
				type => 'albums', #'text',
				url  => \&QobuzAwardPage,
				passthrough => [ $_->{award_id} ],
			 } } @$awards;
			push @$items, { name  => cstring($client, 'PLUGIN_QOBUZ_AWARDS'), items => \@awItems } if scalar @awItems;
		}

		push @$items, { name => cstring($client, 'PLUGIN_QOBUZ_CREDITS'), items => [{ name => $albumcredits, type => 'textarea' }] };

		# Add a consolidated list of all artists on the album
		$items = _albumPerformers($client, $performers, $album->{tracks_count}, $items);

		if ($album->{label} && $album->{label}->{name}) {
			push @$items, {
				name  => cstring($client, 'PLUGIN_QOBUZ_LABEL') . cstring($client, 'COLON') . ' ' . $album->{label}->{name},
				url   => \&QobuzLabelPage,
				passthrough => [ $album->{label}->{id} ],
				};
		}

		push @$items, { name => cstring($client, 'PLUGIN_QOBUZ_RELEASED_AT') . cstring($client, 'COLON') . ' ' . Slim::Utils::DateTime::shortDateF($album->{released_at}), type  => 'text' } if $album->{released_at};

		#Sven 2020-03-30
		push @$items, { name => 'Copyright', items => [{ name => _stripHTML($album->{copyright}), type => 'textarea' }] } if $album->{copyright};

		$item = trackInfoMenuBooklet($client, undef, undef, $album);
		push @$items, $item if $item;

		#Sven 2025-11-03 
		if ($album->{albums_same_artist}) {
			#$log->error(Data::Dump::dump($album->{albums_same_artist}));
			my @albums = map { _albumItem($client, $_) } @{$album->{albums_same_artist}->{items}};
			push @$items, { 
				name => cstring($client, 'PLUGIN_QOBUZ_SAMEARTIST'),
				type => 'albums', #Sven - view type
				items => \@albums, 
			} if scalar @albums;
		}	
		
		#Sven 2025-10-25 
		push @$items, { 
			name => cstring($client, 'PLUGIN_QOBUZ_SUGGEST'),
			type => 'albums', #Sven - view type
			url  => \&QobuzGetAlbums,
			passthrough => [{ cmd => 'album/suggest', args => { album_id => $albumId }, genreId => '' }]
		};
		
		#Sven 2025-10-23
		push @$items, {
			name => cstring($client, 'PLUGIN_QOBUZ_RADIO'),
			type => 'menu', #'link',
			url  => \&QobuzRadio,
			passthrough => [{ album_id => $albumId }]
		};

		if (defined $album->{replay_gain} && $prefs->get('showReplayGain')) {
			push @$items,{
				name  => sprintf( "%2.2f dB", $album->{replay_gain}),
				label => 'ALBUMREPLAYGAIN',
				type => 'text'
			};
		};

		#Sven 2025-12-13
		if ( $dptype eq "2") {
			push @$tracks, {
				name => cstring($client, 'PLUGIN_QOBUZ_ALBUM_INFOMENU'),
				type => 'menu', #'link',
				items => $items
			};

			$items = $tracks;
		}	

		$api->getFavoriteStatus(sub {
			my $isFavorite = shift->{status};

			splice( @$items, $posFavorite, 0, QobuzFavoriteStatus($client, { album_ids => $albumId, add => !$isFavorite }) );

			$cb->({ items => $items }, @_ ); #calls callback function with all calling parameters

		}, { item_id => $albumId, type => 'album' });
			
	}, { album_id => $albumId, extra => 'albumsFromSameArtist' } );
}

sub _addPerformers {
	my ($client, $track, $performers) = @_;

	if (my $trackPerformers = trackInfoMenuPerformers($client, undef, undef, $track)) {
		my $performerItems = $trackPerformers->{items};
		my $mediaNumber = $track->{'media_number'}||1;
		foreach my $item (@$performerItems) {
			$item->{'track'} = $track->{'track_number'};
			$item->{'disc'}  = $mediaNumber;
		}
		push @{$performers->{$mediaNumber}}, @$performerItems;
	}
}

sub _albumPerformers {
	my ($client, $performers, $trackCount, $items) = @_;

	my @uniquePerformers;
	my %seen = ();
	my $tracks;

	foreach my $disc (sort(keys %$performers)) {
		my %discAdded = ();
		foreach my $item (@{$performers->{$disc}}) {
			push @{$tracks->{$item->{'name'}}->{'tracks'}}, " " . cstring($client, 'DISC') . " $disc" . cstring($client, 'COLON') . " " unless $discAdded{$item->{'name'}}++ || scalar keys %$performers == 1;
			push @{$tracks->{$item->{'name'}}->{'tracks'}}, $item->{'track'};
			delete $item->{'track'};
			push(@uniquePerformers, $item) unless $seen{$item->{'name'}}++;
		}
	}

	if ( scalar @uniquePerformers ) {
		foreach my $item (@uniquePerformers) {
			my @tracks = @{$tracks->{$item->{'name'}}->{'tracks'}};
			my $creditCount = scalar @tracks - (scalar keys %$performers == 1 ? 0 : scalar keys %$performers);
			if ( @tracks && scalar $creditCount < $trackCount ) {
				$item->{'name'} .= " ( ";

				# collapse the track list so that, eg, 1,2,3,5,7,8,9,11,12 becomes 1-3, 5, 7-9, 11-12 and add punctuation to make multi-disc albums somewhat intelligible
				# there's probably a much more perly way of doing this...
				my $sep = "-";
				my $o;
				for my $i ( 0 .. $#tracks ) {
					my $currentValue = $tracks[$i];
					my $currentIsNumber = looks_like_number($currentValue);
					my $nextValue = $tracks[$i+1];
					my $nextIsNumber = looks_like_number($nextValue);
					if ( $currentIsNumber && $nextIsNumber && $nextValue == $currentValue+1 ) {
						$o .= "$currentValue$sep" if $sep;
						$sep = undef;
					} else {
						$o .= "$currentValue";
						$sep = "-";
						if ( $currentIsNumber && $nextIsNumber ) {
							$o .= ", ";
						} elsif ( $currentIsNumber && $nextValue && !$nextIsNumber ) {
							$o .= "; ";
						}
					}
				}

				$item->{'name'} .= "$o )";
			}
		}

		my $item = {
			name => cstring($client, 'PLUGIN_QOBUZ_PERFORMERS'),
			items => \@uniquePerformers,
			type => 'actions',
		};
		push @$items, $item;
	}

	return $items;
}

#Sven 2022-05-10 returns a single string with track credits
sub _trackCredits {
	my ($client, $track) = @_;
	my $details;

	if ($track->{track_number}) {
		$details = sprintf("%02s. %s\n\n", $track->{track_number}, $track->{title});
	}
	else { #called from trackInfoMenuPerformer
	  if ($track->{album}) {
      $details = ' - ' . ((ref $track->{album}) ? $track->{album}->{title} : $track->{album});
	  };
		$details = $track->{title} . $details . "\n\n";
	}

	if ($track->{composer}) {
		my $composer = (ref $track->{composer}) ? $track->{composer}->{name} : $track->{composer};
		$details .= ' . ' . cstring($client, 'COMPOSER') . ': ' . $composer . "\n" if $composer;
	}

	$details .= sprintf(" . %s : %s - (%s)\n\n%s\n", cstring($client, 'LENGTH'), _sec2hms($track->{duration}), _quality($track), cstring($client, 'PLUGIN_QOBUZ_CREDITS'));

	map { s/,/: /; $details .= ' . ' . $_ . "\n"; } split(/ - /, $track->{performers});

	return $details;
}

sub _getConductor {
	my $track = shift;
	
    my $temp = $track->{performers};
	my $pos = index($temp, 'Conductor');
	
	if ($pos >= 0) {
		my $name = substr($temp, 0, $pos - 2);
		$pos = rindex($name, ' - ');
		$name = substr($name, $pos+3) if $pos >= 0;
		return $name;
	}
	return "";
}

sub QobuzWorkGetTracks {
	my ($client, $cb, $params, $args) = @_;
	my $tracks = $args->{tracks};

	$cb->({
		type => 'playlist',
		playall => 1,
		items => $tracks
	});
}

#Sven 2023-10-07
sub QobuzPlaylistGetTracks {
	my ($client, $cb, $params, $playlistId) = @_;

	getAPIHandler($client)->getPlaylistTracks(sub {
		my $playlist = shift;

		if (!$playlist) {
			$log->error("Get playlist ($playlistId) failed");
			$cb->();
			return;
		}

		my $tracks = [];

		foreach my $track (@{$playlist->{tracks}->{items}}) {
			push @$tracks, _trackItem($client, $track, $params->{isWeb});
		}
		$cb->({
			items => $tracks,
		}, @_ );
	}, $playlistId);
}

#Sven 2020-04-01
sub _albumItem {
	my ($client, $album) = @_;

	my $artist = $album->{artist}->{name} || '';
	my $albumname = $album->{title} || '';
	my $albumYear = $prefs->get('showYearWithAlbum') ? $album->{year} || (localtime($album->{released_at}))[5] + 1900 || 0 : 0;

	if ( $album->{hires_streamable} && $albumname !~ /hi.?res|bits|khz/i && $prefs->get('labelHiResAlbums') && Plugins::Qobuz::API::Common->getStreamingFormat($album) eq 'flac' ) {
		$albumname .= ' ' . cstring($client, 'PLUGIN_QOBUZ_HIRES');
	}

	my $item = { image => ref $album->{image} ? $album->{image}->{large} : $album->{image} };

	$item->{favorites_url}  = 'qobuz:album:' . $album->{id}, # für Menüpunkt "In Favoriten speichern" im Contextmenu in Material-Skin
	$item->{favorites_type} = 'playlist', # Standardwert ist 'playlist', sonst 'audio' (für Radios oder Tracks)

	my $sortFavsAlphabetically = $prefs->get('sortFavsAlphabetically') || 0;
	if ($sortFavsAlphabetically == 1) {
		$item->{name} = $albumname . ($artist ? ' - ' . $artist : '');
	}
	else {
		$item->{name} = $artist . ($artist && $albumname ? ' - ' : '') . $albumname;
	}

	if ($albumname) {
		$item->{line1} = $albumname;
		#$item->{line2} = $artist . " (" . $album->{tracks_count}. ' - ' . (ref $album->{genre} ? $album->{genre}->{name} : $album->{genre}) . ($albumYear ? ' - ' . $albumYear . ')' : ')'); #Sven 2023-10-09 track_count, genre and year added
		$item->{line2} = ( join(', ', map { $_->{name} } Plugins::Qobuz::API::Common->getMainArtists($album)) || $artist )
						. " (" . $album->{tracks_count}. ' - ' . (ref $album->{genre} ? $album->{genre}->{name} : $album->{genre}) . ($albumYear ? ' - ' . $albumYear . ')' : ')'); #Sven 2023-10-09 track_count, genre and year added
#						. ($albumYear ? ' (' . $albumYear . ')' : '');
		$item->{name} .= $albumYear ? "\n(" . $albumYear . ')' : '';
	}

	if ( $prefs->get('parentalWarning') && $album->{parental_warning} ) {
		$item->{name}  .= ' [E]';
		$item->{line1} .= ' [E]';
	}

#if ( ! _isReleased($album)  || (!$album->{streamable} && ! $prefs->get('playSamples')) ) {
#	my $sorry = ' - ' . cstring($client, 'PLUGIN_QOBUZ_NOT_AVAILABLE');
#	$item->{name}  .= $sorry;
#	$item->{line2} .= $sorry;
#	#$item->{type} = 'text';
#}
#else {
		if (!$album->{streamable} || !_isReleased($album) ) {
			$item->{name}  = '* ' . $item->{name};
			$item->{line2} = '* ' . $item->{line2};
		} else {
			$item->{type}  = ($prefs->get('albumViewType') eq "0") ? 'link' : 'playlist';
		}
		
		$item->{url}         = \&QobuzGetTracks;
		$item->{passthrough} = [{ album_id => $album->{id}, album_title => $album->{title} }];
#}

	return $item;
}

#Sven 2019-04-17, 2025-11-03, 26-05-08
sub _artistItem {
	my ($client, $artist, $withIcon, $sorted) = @_;

	my $artistId = $artist->{id};

	#Sven 2022-05-11 - Erweiterung um Anzeige von Rollen, falls vorhanden
	my $roles = $artist->{roles};
	my $url = 'qobuz://artist:' . $artistId;
		
	my $item =  {
		name => $artist->{name} . (($roles && scalar @$roles) ? ' (' . join(', ', map { $_ } @$roles) . ')' : ''),
		type => 'artist',
		favorites_url  => $url, # fügt dem Contextmenu "In Favoriten speichern" hinzu
		playlist => $url, # Erzeugt den Eintrag 'presetParams' im JsonRpc Response mit den Werten favorites_url, favorites_title und favorites_type, siehe Funktion _favoritesParams() in Slim/Control/XMLBrowser.pm 
						  # gleichzeitig erkennt Material Skin den Item als Künstler und stellt das Image rund dar. play => $url funktioniert auch, hat aber Nebenwirkungen beim Übertragen in die Wiedergabeliste. 
		url  => \&QobuzArtist,
		passthrough => [{ artistId => $artistId }],
		
	};

	$item->{image}   = $artist->{image} || QOBUZ_ARTISTS_IMAGE if $withIcon;
	$item->{textkey} = substr( Slim::Utils::Text::ignoreCaseArticles($item->{name}), 0, 1 ) if $sorted;

	return $item;
}

#Sven 2020-03-28, 2022-05-11
sub _playlistItem {
	my ($playlist, $isWeb) = @_;

	my $args =  { 
		name  => $playlist->{name} || $playlist->{title},
		owner => $playlist->{owner}->{name},
		image => Plugins::Qobuz::API::Common->getPlaylistImage($playlist),
	};

	return {
		name  => $args->{name}, # . (($isWeb && $owner) ? " - $owner" : ''),
		line2 => join(' - ', ($args->{owner}, $playlist->{tracks_count},  _sec2hms($playlist->{duration}))),
		url   => \&QobuzPlaylistItem,
		image => $args->{image},
		type  => 'link',
		passthrough => [ $playlist, $args ],
	};
}

#Sven 2025-11-03
sub _countDuration {
	my ($client, $count, $duration) = @_;

	return $count . ' ' . cstring($client, ($count eq 1) ? 'PLUGIN_QOBUZ_TRACK' : 'PLUGIN_QOBUZ_TRACKS' ) . ' - ' . cstring($client, 'LENGTH') . ' ' . _sec2hms($duration);
}

#Sven 2023-10-08, 2025-09-22 $isWeb currently has no effect, not even in the original version of v3.6.2.
sub _trackItem {
	my ($client, $track, $isWeb) = @_;

	my $title  = Plugins::Qobuz::API::Common->addVersionToTitle($track);
	$title = sprintf('%02s. %s', $track->{track_number}, $title) if $track->{track_number};
	my $album  = $track->{album};
	#my $artist = Plugins::Qobuz::API::Common->getArtistName($track, $album);
	my $artistNames = [ map { $_->{name} } Plugins::Qobuz::API::Common->getMainArtists($album) ];
	Plugins::Qobuz::API::Common->removeArtistsIfNotOnTrack($track, $artistNames);
	if ($track->{performer} && Plugins::Qobuz::API::Common->trackPerformerIsMainArtist($track) ) {
		push @$artistNames, $track->{performer}->{name};
	}
	my %seen;
	my $artist = join(', ', grep { !$seen{$_}++ } @$artistNames);
	my $albumtitle = $album->{title} || '';
	if ( $albumtitle && $prefs->get('showDiscs') ) {
		$albumtitle = Slim::Music::Info::addDiscNumberToAlbumTitle($albumtitle,$track->{media_number},$album->{media_count});
	}

	my $item = {
		name  => sprintf('%s %s %s %s %s', $title, cstring($client, 'BY'), $artist, cstring($client, 'FROM'), $albumtitle),
		line1 => $title,
		line2 => $artist . ($artist && $albumtitle ? ' - ' : '') . $albumtitle . ' - ' . _sec2hms($track->{duration}), #Sven
		line2 => join( ' - ', ($artist, $albumtitle, _sec2hms($track->{duration})) ), #Sven
		image => Plugins::Qobuz::API::Common->getImageFromImagesHash($album->{image}),
	};

	if ( $track->{hires_streamable} && $item->{name} !~ /hi.?res|bits|khz/i && $prefs->get('labelHiResAlbums') && Plugins::Qobuz::API::Common->getStreamingFormat($album) eq 'flac' ) {
		$item->{name}  .= ' ' . cstring($client, 'PLUGIN_QOBUZ_HIRES');
		$item->{line1} .= ' ' . cstring($client, 'PLUGIN_QOBUZ_HIRES');
	}

	# Enhancements to work/composer display for classical music (tags returned from Qobuz are all over the place)
	if ( isClassique($track->{album}) && $prefs->get('useClassicalEnhancements') ) {
		if ( $track->{work} ) {
			$item->{work} = $track->{work};
		} else {
			# Try to set work to the title, but without composer if it's in there
			if ( $track->{composer}->{name} && $track->{title} ) {
				my @titleSplit = split /:\s*/, $track->{title};
				$item->{work} = $track->{title};
				if ( index($track->{composer}->{name}, $titleSplit[0]) != -1 ) {
					$item->{work} =~ s/\Q$titleSplit[0]\E:\s*//;
				}
			}
			# try to remove the title (ie track, movement) from the work
			my @titleSplit = split /:\s*/, $track->{title};
			my $tempTitle = @titleSplit[-1];
			$item->{work} =~ s/:\s*\Q$tempTitle\E//;
			$item->{line1} =~ s/\Q$item->{work}\E://;
		}
		$item->{displayWork} = $item->{work};
		if ( $track->{composer}->{name} ) {
			$item->{displayWork} = $track->{composer}->{name} . string('COLON') . ' ' . $item->{work};
			my $composerSurname = (split ' ', $track->{composer}->{name})[-1];
			$item->{line1} =~ s/\Q$composerSurname\E://;
		}
		$item->{line2} .= " - " . $item->{work} if $item->{work};
	}

	if ( $album ) {
		$item->{year} = $album->{year} || substr($album->{release_date_stream},0,4) || 0;
	}

	if ( $prefs->get('parentalWarning') && $track->{parental_warning} ) {
		$item->{name} .= ' [E]';
		$item->{line1} .= ' [E]';
	}

	if ($album && $album->{released_at} && $album->{released_at} > time) {
	#if ($track->{released_at} && $track->{released_at} > time) {
		$item->{items} = [{
			name => cstring($client, 'PLUGIN_QOBUZ_NOT_RELEASED'),
			type => 'textarea'
		}];
	}
	elsif (!$track->{streamable} && (!$prefs->get('playSamples') || !$track->{sampleable})) {
		$item->{items} = [{
			name => cstring($client, 'PLUGIN_QOBUZ_NOT_AVAILABLE'),
			type => 'textarea'
		}];
		$item->{name}  = '* ' . $item->{name};
		$item->{line1} = '* ' . $item->{line1};
	}
	else {
		$item->{name}      = $item->{name} . ' *' if !$track->{streamable};
		$item->{line1}     = '* ' . $item->{line1} if !$track->{streamable};
		#$item->{line2}     = $item->{line2} . ' *' if !$track->{streamable};
		$item->{play}      = Plugins::Qobuz::API::Common->getUrl($client, $track);
		$item->{on_select} = 'play';
		$item->{playall}   = 1;
	}

	$item->{url} = $item->{play} if $item->{play}; #Wurde am 26.10.2024 von Michael Herger hinzugefügt, wegen Material-Skin?
	# Diese Änderung hatte mein Track-Menü verschwinden lassen.
	#if ($item->{play}) { #Sven 2025-09-22 jetzt wird das Track-Menü erst erzeugt und angezeigt, wenn auf den Track geklickt wird und der Menüpunkt 'Mehr...' gewählt wird.
	#	$item->{url} = \&QobuzTrackMenu;
	#	$item->{passthrough} = [{ track => $track, item => $item, artist => $artist }];
	#};
	$item->{tracknum}     = $track->{track_number};
	$item->{media_number} = $track->{media_number};
	$item->{media_count}  = $album->{media_count};

	#Sven 2026-05-13 - Erzeugt den Menüeintrag 'More', dieser ruft dann Slim::Menu::TrackInfo::menu() auf
	$item->{itemActions} = {
		info => {
			command => ['trackinfo', 'items'],
            fixedParams => { menu => 'trackinfo', url => $item->{play} },
		}
	};

	return $item;
}

=head2 Wird nicht mehr verwendet, siehe _trackItem(2946)
#Sven 2025-09-22 Is the contextmenu more... of a track
sub QobuzTrackMenu {
	my ($client, $cb, $params, $args) = @_;
	
	my $track = $args->{track};
	my $album = $track->{album};
	my $item  = $args->{item};

#	$log->error(_dump($item));

	my $items = [];

	#push @$items, _albumItem($client, $album);

	push @$items, {
		name => cstring($client, 'PLUGIN_QOBUZ_CREDITS'),
		items => [{name => _trackCredits($client, $track), type => 'textarea'}],
	};

	# Add a consolidated list of all artists on the album
	my $performers = {};
	_addPerformers($client, $track, $performers);
	$items = _albumPerformers($client, $performers, 1, $items);
	
	#Sven 2025-10-23
	push @$items, {
		name => cstring($client, 'PLUGIN_QOBUZ_RADIO'),
		type => 'menu', #'link',
		url  => \&QobuzRadio,
		passthrough => [{ track_id => $track->{id} }]
	};

#	push @$items, {
#		name => cstring($client, 'PLUGIN_QOBUZ_MANAGE_FAVORITES'),
#		url  => \&QobuzManageFavorites,
#		passthrough => [{
#			trackId => $track->{id}, title => $args->{title},
#			albumId => $album->{id}, album => $album->{title},
#			artist => $args->{artist},
#		}],
#	};

	my $menu = {
		name  => $item->{title},
		type  => 'opml',
		items => $items,
		cover => $item->{image},
		menuComplete => 1,
	};

	$menu->{play} = $item->{play} if $item->{play};

	$cb->( $menu );
}
=cut

#Sven 2026-05-15 Das Kontextmenü eines Tracks, erzeugt den Menüpunkt 'Auf Qobuz' im 'Mehr'-Menü.
sub trackInfoMenu {
	my ( $client, $url, $track, $remoteMeta, $tags ) = @_;

	return {
		name => cstring($client, 'PLUGIN_ON_QOBUZ'),
		url  => \&QobuzTrackInfoMenu,
		passthrough => [{ url => $url, track => $track, remoteMeta => $remoteMeta, tags => $tags }],
	};
}

sub QobuzTrackInfoMenu {
	my ( $client, $cb, $params, $args ) = @_;

	my $url   = $args->{url};
	my $track = $args->{track};
	my $remoteMeta = $args->{remoteMeta};
	my $tags  = $args->{tags};

	my $artist = $track->remote ? $remoteMeta->{artist} : $track->artistName;
	my $album  = $track->remote ? $remoteMeta->{album}  : ( $track->album ? $track->album->name : undef );
	my $title  = $track->remote ? $remoteMeta->{title}  : $track->title;
	my $label  = $track->remote ? $remoteMeta->{label} : undef;
	my $labelId = $track->remote ? $remoteMeta->{labelId} : undef;
	my $composer  = $track->remote ? [$remoteMeta->{composer}] : undef;
	my $work = $composer && $remoteMeta->{work} ? ["$remoteMeta->{composer} $remoteMeta->{work}"] : undef;
	
	$artist = (split /,/, $artist)[0]; #Sven 2022-05-03 somtimes a list of artists are received

	my $items = [];

	my ($trackId) = Plugins::Qobuz::ProtocolHandler->crackUrl($url); #Sven 2025-09-27 fix $trackId is defined only with Qobuz url
	if (defined $trackId) {
=head3		
		my $albumId = $remoteMeta ? $remoteMeta->{albumId} : undef;
		my $artistId= $remoteMeta ? $remoteMeta->{artistId} : undef;

		if ($trackId || $albumId || $artistId) {
			my $args = {};
			if ($artistId && $artist) {
				$args->{artistId} = $artistId;
				$args->{artist}   = $artist;
			}

			if ($trackId && $title) {
				$args->{trackId} = $trackId;
				$args->{title}   = $title;
			}

			if ($albumId && $album) {
				$args->{albumId} = $albumId;
				$args->{album}   = $album;
			}

			push @$items, {
				name => cstring($client, 'PLUGIN_QOBUZ_MANAGE_FAVORITES'),
				url  => \&QobuzManageFavorites,
				passthrough => [$args],
			} if keys %$args
		}
=cut
		if (my $item = trackInfoMenuCredits($client, undef, undef, $remoteMeta)) {
			push @$items, $item;
		}
		
		push @$items, {
			name  => cstring($client, 'PLUGIN_QOBUZ_RADIO'),
			type => 'link', #'menu'
			url   => sub { # Die direkte Methode über url => \&QobuzRadio funktioniert nicht immer, offenbar ein Problem durch das Caching.
						my ($client, $cb, $params, $args) = @_;
						Slim::Control::Request::executeRequest($client, ['qobuz', 'command', ['radio', $cb, $params, $args]]);
					 },
			passthrough => [{ track_id => $trackId }],		 
		};

		# Add a consolidated list of all artists on the track
		my $performers = {};
		_addPerformers($client, $remoteMeta, $performers);
		$items = _albumPerformers($client, $performers, 1, $items);

		if (my $item = trackInfoMenuBooklet($client, undef, undef, $remoteMeta)) {
			push @$items, $item
		}
	}

	my $menu = _objInfoHandler( $client, $artist, $album, $title, $items, $label, $labelId, $composer, $work );

	$items = $menu->{items} ? $menu->{items} : [$menu];

	if (defined $trackId) {
		getAPIHandler($client)->getFavoriteStatus(sub {
			my $isFavorite = shift->{status};
		
			splice( @$items, 0, 0, QobuzFavoriteStatus($client, { track_ids => $trackId, add => !$isFavorite, title => cstring($client, 'TRACK') . " '" . $title . "'" }) );
		
			#$log->error(_dump($items));
		
			$cb->({ items => $items } );
		
		}, { item_id => $trackId, type => 'track' });
	}
	else {
		$cb->({ items => $items });
	}
	#return _objInfoHandler( $client, $artist, $album, $title, $items, $label, $labelId, $composer, $work );
}

sub artistInfoMenu {
	my ($client, $url, $artist, $remoteMeta, $tags, $filter) = @_;

	return _objInfoHandler( $client, $artist->name );
}

#Sven - Kontextmenu eines Albums, wird im Plugin selbst nicht aufgerufen
sub albumInfoMenu {
	my ($client, $url, $album, $remoteMeta, $tags, $filter) = @_;

	my $albumTitle = $album->title;
	my @artists;
	push @artists, $album->artistsForRoles('ARTIST'), $album->artistsForRoles('ALBUMARTIST');

	my $label;
	my $labelId;
	my $composers;
	my $works;
	my $items = [];

	if ( !%$remoteMeta && $url =~ /^qobuz:/ ) {
		my $albumId = (split /:/, $url)[-1];

		my $qobuzAlbum = $cache->get('album_with_tracks_' . $albumId);
		unless ($qobuzAlbum && ref $qobuzAlbum) {
			getAPIHandler($client)->getAlbum(sub {
				$qobuzAlbum = shift;

				$log->error('albumInfoMenu: getAlbum():Callback()');

				if (!$qobuzAlbum) {
					$log->error("Get album ($albumId) failed");
					return;
				}
				elsif ( $qobuzAlbum->{release_date_stream} && $qobuzAlbum->{release_date_stream} lt Slim::Utils::DateTime::shortDateF(time, "%Y-%m-%d") ) {
					$cache->set('album_with_tracks_' . $albumId, $qobuzAlbum, QOBUZ_DEFAULT_EXPIRY);
					$log->error('albumInfoMenu: getAlbum():Callback() - Albumdaten in Cache speichern');
				}
			}, $albumId);
		}
		else {
			my %seen;
			my $performers = {};
			my $albumcredits;
			foreach my $track (@{$qobuzAlbum->{tracks}->{items}}) {
				_addPerformers($client, $track, $performers);
				$albumcredits .= _trackCredits($client, $track) . "\n\n";
				my $composer = $track->{'composer'}->{'name'};
				my $work = $track->{'work'};
				if ( $track->{'album'}->{'label'} && !$seen{$track->{'label'}} ) {
					$seen{$track->{'album'}->{'label'}} = 1;
					$label = $track->{'album'}->{'label'};
					$labelId = $track->{'album'}->{'labelId'};
				}
				if ( $composer && !$seen{$composer} ) {
					$seen{$composer} = 1;
					push @$composers, $composer;
				}
				if ( $composer && $work && !$seen{"$work $composer"} ) {
					$seen{"$work $composer"} = 1;
					push @$works, "$composer $work";
				}
			}

			my $args = {};
			$args->{albumId} = $qobuzAlbum->{id};
			$args->{album} = $qobuzAlbum->{title};
			$args->{artistId} = $qobuzAlbum->{artist}->{id};
			$args->{artist} = $qobuzAlbum->{artist}->{name};
			push @$items, {
				name => cstring($client, 'PLUGIN_QOBUZ_MANAGE_FAVORITES'),
				url  => \&QobuzManageFavorites,
				passthrough => [$args],
			} if keys %$args;

			if ($albumcredits) {
				$albumcredits = $qobuzAlbum->{title} . "\n\n" . $albumcredits;
				push @$items, { name => cstring($client, 'PLUGIN_QOBUZ_CREDITS'), items => [{ name => $albumcredits, type => 'textarea' }] };
			}

			$items = _albumPerformers($client, $performers, $qobuzAlbum->{tracks_count}, $items);

			if ($qobuzAlbum->{description}) {
				push @$items, {
					name  => cstring($client, 'DESCRIPTION'),
					items => [{
						name => _stripHTML($qobuzAlbum->{description}),
						type => 'textarea',
					}],
				};
			};

			if (my $item = trackInfoMenuBooklet($client, undef, undef, $qobuzAlbum)) {
				push @$items, $item
			}
		}
	}

	return _objInfoHandler( $client, $artists[0]->name, $albumTitle, undef, $items, $label, $labelId, $composers, $works);
}

sub _objInfoHandler {
	my ( $client, $artist, $album, $track, $items, $label, $labelId, $composer, $work ) = @_;

	#Sven 2025-09-28 fix for context menu of a radio playlist item, no 'on Qobuz' if album or artist is not present.
	$track = undef unless ($artist || $album); 

	$items ||= [];

	push @$items, {
		name  => cstring($client, 'PLUGIN_QOBUZ_LABEL') . cstring($client, 'COLON') . ' ' . $label,
		url   => \&QobuzLabelPage,
		passthrough => [ $labelId ],
	} if $label && $labelId;

	#Sven 2025-09-28 QobuzSearch with type (albums, artists, tracks, ...), optimized code which is independent from unknown names.
	my $sItems = [ 
		{ type => 'artists', value => $artist, caption => 'ARTIST' },
		{ type => 'albums',  value => $album,  caption => 'ALBUM' },
		{ type => 'tracks',  value => $track,  caption => 'TRACK' },
	];
	foreach (@$composer) { #Sven 2025-10-24
		push @$sItems, { type => 'artists',  value => $_,  caption => 'COMPOSER' } unless ($_ eq $artist);
	}	
	push @$sItems, { type => 'works',    value => $_,  caption => 'PLUGIN_QOBUZ_WORK' } foreach @$work;

	foreach (@$sItems) {
		push @$items, {
			name => cstring($client, 'PLUGIN_QOBUZ_SEARCH', cstring($client, $_->{caption}), $_->{value}),
			url  => \&QobuzSearch,
			passthrough => [{
				q => $_->{value},
				type => $_->{type}, #Sven 2025-09-28
			}]
		} if $_->{value};
	}

	my $menu;
	if ( scalar @$items == 1) {
		$menu = $items->[0];
		$menu->{name} = cstring($client, 'PLUGIN_ON_QOBUZ');
	}
	elsif (scalar @$items) {
		$menu = {
			name  => cstring($client, 'PLUGIN_ON_QOBUZ'),
			items => $items
		};
	}

	return $menu if $menu;
}

#Sven - my version
sub trackInfoMenuCredits {
	my ( $client, $url, $track, $remoteMeta, $tags ) = @_;

	if ( $remoteMeta && $remoteMeta->{performers} ) {
		return { name => cstring($client, 'PLUGIN_QOBUZ_CREDITS'), items => [{name => _trackCredits($client, $remoteMeta), type => 'textarea'}] };
	}
}

my $MAIN_ARTIST_RE = qr/MainArtist|\bPerformer\b|ComposerLyricist/i;
my $ARTIST_RE = qr/Performer|Keyboards|Synthesizer|Vocal|Guitar|Lyricist|Composer|Bass|Drums|Percussion||Violin|Viola|Cello|Trumpet|Conductor|Trombone|Trumpet|Horn|Tuba|Flute|Euphonium|Piano|Orchestra|Clarinet|Didgeridoo|Cymbals|Strings|Harp/i;
my $STUDIO_RE = qr/StudioPersonnel|Other|Producer|Engineer|Prod/i;

sub trackInfoMenuPerformers {
	my ( $client, $url, $track, $remoteMeta, $tags ) = @_;

	#if ( $remoteMeta && (my $performers = $remoteMeta->{performers}) ) {
	if ( $remoteMeta && $remoteMeta->{performers} ) {
		my @performers = map {
			s/,?\s?(MainArtist|AssociatedPerformer|StudioPersonnel|ComposerLyricist)//ig;
			s/,/:/;
			{
				name => $_,
				url  => \&QobuzSearch,
				passthrough => [{
					q => (split /:/, $_)[0],
				}]
			}
		} sort {
			return $a cmp $b if $a =~ $MAIN_ARTIST_RE && $b =~ $MAIN_ARTIST_RE;
			return -1 if $a =~ $MAIN_ARTIST_RE;
			return 1 if $b =~ $MAIN_ARTIST_RE;

			return $a cmp $b if $a =~ $ARTIST_RE && $b =~ $ARTIST_RE;
			return -1 if $a =~ $ARTIST_RE;
			return 1 if $b =~ $ARTIST_RE;

			return $a cmp $b if $a =~ $STUDIO_RE && $b =~ $STUDIO_RE;
			return -1 if $a =~ $STUDIO_RE;
			return 1 if $b =~ $STUDIO_RE;

			return $a cmp $b;
		} split(/ - /, $remoteMeta->{performers});

		return {
			name => cstring($client, 'PLUGIN_QOBUZ_PERFORMERS'),
			items => \@performers,
		};
	}

	return {};
}

sub trackInfoMenuBooklet {
	my ( $client, $url, $track, $remoteMeta, $tags ) = @_;

	my $item;

	eval {
		my $goodies = $remoteMeta->{goodies};
		if ($goodies && ref $goodies && scalar @$goodies) {

			# Browser client (eg Material)
			if ( Slim::Utils::Versions->compareVersions($::VERSION, '8.4.0') >= 0 && _isBrowser($client)
				# or null client (eg Default skin)
				|| !$client->controllerUA ) {
				if (scalar @$goodies == 1 && lc(@$goodies[0]->{name}) eq "livret num\xe9rique") {
					$item = {
						name => _localizeGoodies($client, @$goodies[0]->{name}),
						weblink => @$goodies[0]->{url},
					};
				} else {
					my $items = [];
					foreach ( @$goodies ) {
						if ($_->{url} =~ $GOODIE_URL_PARSER_RE) {
							push @$items, {
								name => _localizeGoodies($client, $_->{name}),
								weblink => $_->{url},
							};
						}
					}
					if (scalar @$items) {
						$item = {
							name => cstring($client, 'PLUGIN_QOBUZ_GOODIES'),
							items => $items
						};
					}
				}
			}
			# jive clients like iPeng etc. can display web content, but need special handling...
			elsif ( _canWeblink($client) )  {
				$item = {
					name => cstring($client, 'PLUGIN_QOBUZ_GOODIES'),
					itemActions => {
						items => {
							command  => [ 'qobuz', 'goodies' ],
							fixedParams => {
								goodies => to_json($goodies),
							}
						},
					},
				};
			}
		}
	};

	return $item;
}

sub _localizeGoodies {
	my ($client, $name) = @_;

	if ( my $localizedToken = $localizationTable{$name} ) {
		$name = cstring($client, $localizedToken);
	}

	return $name;
}

sub _getGoodiesCLI {
	my $request = shift;

	my $client = $request->client;

	if ($request->isNotQuery([['qobuz'], ['goodies']])) {
		$request->setStatusBadDispatch();
		return;
	}

	$request->setStatusProcessing();

	my $goodies = [ eval { grep {
		$_->{url} =~ $GOODIE_URL_PARSER_RE;
	} @{from_json($request->getParam('goodies'))} } ] || '[]';

	my $i = 0;

	if (!scalar @$goodies) {
		$request->addResult('window', {
			textArea => cstring($client, 'EMPTY'),
		});
		$i++;
	}
	else {
		foreach (@$goodies) {
			$request->addResultLoop('item_loop', $i, 'text', _localizeGoodies($client, $_->{name}) . ' - ' . $_->{description}); #Sven 2022-05-01 add decription
			$request->addResultLoop('item_loop', $i, 'weblink', $_->{url});
			$i++;
		}
	}

	$request->addResult('count', $i);
	$request->addResult('offset', 0);

	$request->setStatusDone();
}

#Sven 2025-10-25 - New cli command to get show an album or an radio
sub cliQobuzCommand {
	my $request = shift;
	
	# check this is the correct query.
	if ($request->isNotCommand([['qobuz'], ['command']])) {
		$request->setStatusBadDispatch();
		return;
	}

	# get our parameters
	my $client  = $request->client();

	my $params  = $request->getParam('_aParams');
	if (ref $params eq 'ARRAY') {
		my $command =  $params->[0];
		if ($command eq 'album' || $command eq 'radio') {
			my $func = ($command eq 'album') ? \&QobuzGetTracks : \&QobuzRadio;
			$func->($client, $params->[1], $params->[2], $params->[3]); 
		}
	}	
	elsif (my $menu = $request->getParam('menu')) {
		my $func = \&$menu;
		#$func->($client, $request->getParam('trackId'));
	}
		
	$request->setStatusDone();
}

#Sven - ab hier ist der Kode bisher identisch mit der Version von Michael Herger
sub cliQobuzPlayAlbum {
	my $request = shift;

	# check this is the correct query.
	if ($request->isNotCommand([['qobuz'], ['playalbum', 'addalbum']])) {
		$request->setStatusBadDispatch();
		return;
	}

	# get our parameters
	my $client = $request->client();
	my $albumId = $request->getParam('_p2');

	getAPIHandler($client)->getAlbum(sub {
		my $album = shift;

		if (!$album) {
			$log->error("Get album ($albumId) failed");
			return;
		}

		$log->error("Album-ID:$albumId");

		my $tracks = [];

		foreach my $track (@{$album->{tracks}->{items}}) {
			push @$tracks, Plugins::Qobuz::API::Common->getUrl($client, $track);
		}

		my $action = $request->isCommand([['qobuz'], ['addalbum']]) ? 'addtracks' : 'playtracks';

		$client->execute( ["playlist", $action, "listref", $tracks] );
	}, $albumId);

	$request->setStatusDone();
}

sub _canWeblink {
	my ($client) = @_;
	return $client && $client->controllerUA && ($client->controllerUA =~ $WEBLINK_SUPPORTED_UA_RE || $client->controllerUA =~ $WEBBROWSER_UA_RE);
}

sub _isBrowser {
	my ($client) = @_;
	return ( $client && $client->controllerUA && $client->controllerUA =~ $WEBBROWSER_UA_RE );
}

sub _stripHTML {
	my $html = shift;
	$html =~ s/<(?:[^>'”]*|([‘”]).*?\1)*>//ig;
	return $html;
}

sub _imgProxy { 
	if (CAN_IMAGEPROXY) {
		my ($url, $spec) = @_;

		main::DEBUGLOG && $log->debug("Artwork for $url, $spec");

		# https://github.com/Qobuz/api-documentation#album-cover-sizes
		my $size = Slim::Web::ImageProxy->getRightSize($spec, {
			50 => 50,
			160 => 160,
			300 => 300,
			600 => 600
		}) || 'max';

		$url =~ s/(\d{13}_)[\dmax]+(\.jpg)/$1$size$2/ if $size;

		main::DEBUGLOG && $log->debug("Artwork file url is '$url'");

		return $url;
	}
}

sub _isReleased {  # determine if the referenced album has been released
	my ($album) = @_;
	my $ltime = time;
	# only check date field if the release date is within +/- 14 hours of now
	if ($ltime > ($album->{released_at} + 50400)) {
		return 1;
	} elsif ($ltime < ($album->{released_at} - 50400)) {
		return 0;
	} else {  # check the local date
		my $ldate = Slim::Utils::DateTime::shortDateF($ltime, "%Y-%m-%d");
		return ($ldate ge $album->{release_date_stream});
	}
}

sub _isMainArtist {  # determine if an artist is a main artist on the release
	my ($artistId, $album) = @_;

	if ($album->{artist} && $album->{artist}->{id} == $artistId) {
		return 1;
	} elsif (ref $album->{artists} && scalar @{$album->{artists}} ) {  # check the other artists
		for my $artists ( @{$album->{artists}} ) {
			if ($artists->{id} == $artistId && grep(/main-artist/, @{$artists->{roles}})) {
				return 1;
			}
		}
	}
	return 0;
}

sub _isMainArtistByName {  # determine if an artist is a main artist on the release
	my ($artistName, $album) = @_;

	$artistName = lc($artistName);
	if ($album->{artist} && lc($album->{artist}->{name}) eq $artistName) {
		return 1;
	} elsif (ref $album->{artists} && scalar @{$album->{artists}} ) {  # check the other artists
		for my $artists ( @{$album->{artists}} ) {
			if (lc($artists->{name}) eq $artistName && grep(/main-artist/, @{$artists->{roles}})) {
				return 1;
			}
		}
	}
	return 0;
}

sub _localDate {  # convert input date string in format YYYY-MM-DD to localized short date format
	my $iDate = shift;
	my @dt = split(/-/, $iDate);
	return strftime(preferences('server')->get('shortdateFormat'), 0, 0, 0, $dt[2], $dt[1] - 1, $dt[0] - 1900);
}

# TODO - make search per account
sub addRecentSearch {
	my $search = shift;
	main::DEBUGLOG && $log->is_debug && $log->debug("++addRecentSearch");

	my $list = $prefs->get('qobuz_recent_search') || [];

	$list = [ grep { $_ ne $search } @$list ];

	push @$list, $search;

	shift(@$list) while scalar @$list > MAX_RECENT;

	$prefs->set( 'qobuz_recent_search', $list );
	main::DEBUGLOG && $log->is_debug && $log->debug("--addRecentSearch");
	return;
}

sub _recentSearchesCLI {
	my $request = shift;
	my $client = $request->client;
	main::DEBUGLOG && $log->is_debug && $log->debug("++_recentSearchesCLI");

	# check this is the correct command.
	if ($request->isNotCommand([['qobuz'], ['recentsearches']])) {
		$request->setStatusBadDispatch();
		return;
	}

	my $list = $prefs->get('qobuz_recent_search') || [];
	my $del = $request->getParam('deleteMenu') || $request->getParam('delete') || 0;

	if (!scalar @$list || $del >= scalar @$list) {
		$log->error('Search item to delete is outside the history list!');
		$request->setStatusBadParams();
		return;
	}

	my $items = [];

	if (defined $request->getParam('deleteMenu')) {
		push @$items,
		{
			text => cstring($client, 'DELETE') . cstring($client, 'COLON') . ' "' . ($list->[$del] || '') . '"',
			actions => {
				go => {
					player => 0,
					cmd    => ['qobuz', 'recentsearches' ],
					params => {
						delete => $del
					},
				},
			},
			nextWindow => 'parent',
		},
		{
			text => cstring($client, 'PLUGIN_QOBUZ_CLEAR_SEARCH_HISTORY'),
			actions => {
				go => {
					player => 0,
					cmd    => ['qobuz', 'recentsearches' ],
					params => {
						deleteAll => 1
					},
				}
			},
			nextWindow => 'grandParent',
		};

		$request->addResult('offset', 0);
		$request->addResult('count', scalar @$items);
		$request->addResult('item_loop', $items);
	} elsif ($request->getParam('deleteAll')) {
		$prefs->set( 'qobuz_recent_search', [] );
	} elsif (defined $request->getParam('delete')) {
		splice(@$list, $del, 1);
		$prefs->set( 'qobuz_recent_search', $list );
	}

	$request->setStatusDone;
	main::DEBUGLOG && $log->is_debug && $log->debug("--_recentSearchesCLI");
	return;
}

sub getAPIHandler {
	my ($clientOrId) = @_;

	my $api;

	if (ref $clientOrId) {
		# $clientOrId is a Player::Client object
		$api = $clientOrId->pluginData('api');
		
		if ( !$api ) {
			my $userdata = Plugins::Qobuz::API::Common->getAccountData($clientOrId);
			# if there's no account assigned to the player, just pick one
			if (!$userdata) {
				my $userId = Plugins::Qobuz::API::Common->getSomeUserId($clientOrId); 
				$prefs->client($clientOrId)->set('userId', $userId) if $userId;
			}
			$api = $clientOrId->pluginData( api => Plugins::Qobuz::API->new({ client => $clientOrId }) ); # hier wird client und userId gespeichert
		}
	}
	else {
		# kommt im Kode eigentlich nicht vor, $client könnte durch Fehlfunktion vieleicht undef sein und dann hier landen, eine gültige Id wird jedenfals nirgends übergeben.
		# $clientOrId is a Qobuz user-ID
		$clientOrId ||= Plugins::Qobuz::API::Common->getSomeUserId($clientOrId);
		$api = Plugins::Qobuz::API->new({
			userId => $clientOrId # hier wird nur userId gespeichert
		});
	}

	logBacktrace("Failed to get a Qobuz API instance: $clientOrId") unless $api;

	return $api;
}

1;

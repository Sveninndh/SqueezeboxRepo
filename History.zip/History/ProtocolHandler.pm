package Plugins::History::ProtocolHandler;
# History copyright (c) 2023 by SvenInNdh

use strict;
#use base qw(Slim::Player::Protocols::File);

use Slim::Utils::Log;
use Slim::Utils::Strings qw(string cstring);

my $log = logger('plugin.history');

my $URL_REGEX = qr{(^file:\/\/.+(\.m3u)$)|(^db:album\.)}i; #qr{^file:\/\/.+(\.m3u)$}i; qr{(^file:\/\/.+(\.m3u)$)|(^db:album\.id=)}i;
Slim::Player::ProtocolHandlers->registerURLHandler($URL_REGEX, __PACKAGE__);

sub explodePlaylist {
	my ( $class, $client, $url, $cb ) = @_;
	#$log->error(Data::Dump::dump($url));
	my $uris = { type => 'opml', title => '', items => [] };
	if ( $url =~ /^file:\/\/(.+)(\.m3u)$/i ) {
		my $path   = Slim::Utils::Misc::pathFromFileURL($url);
		my @tracks = Slim::Formats::Playlists::M3U->read($path, undef, undef);
	    $uris->{items} = [ map { Plugins::History::Plugin::getTrackItemExt($client, (blessed $_) ? $_->url : $_) } @tracks ];
	}
	else {
		my $albumid = getAlbum($url)->{id};
		if ($albumid) {
			my $request = Slim::Control::Request::executeRequest($client, ['titles', 0, 100, 'album_id:' . $albumid, 'tags:aulc']);
			my $titles = $request->getResult('titles_loop');
			$uris->{items} = [ map { Plugins::History::Plugin::getTrackItem($client, $_); } @$titles ];
		}
	}
	$cb->( $uris );
}

sub getIcon {
	my ( $class, $url ) = @_;
	my $album = getAlbum($url, 1)->{album};
	if ($album && $album->artwork) {
		return 'music/' . $album->artwork . '/cover.png';
	}
	if ($url =~ /^file:.+(\.m3u)$/) {
		return 'html/images/playlists.png'
	}
	return 'html/images/albums.png'
}

sub getAlbum {
	my ($url, $forceAlbumObject) = @_;
	my $album;
	my $id;
	if ($url =~ /^db:album\.title=/) {
		$album = getAlbumFromTitle($url); 
		$id = $album->id if $album;
	}
	elsif ($url =~ /^db:album\.id=/) {
		$id    = substr($url,12,5);
		$album = Slim::Schema->find('Album', $id) if $forceAlbumObject;
	}
	return { id => $id, album => $album };
}

sub getAlbumFromTitle {
	my $url = shift;
	my $query = {};
	my $joins = [];
	$url =~ s/^db://;
	foreach my $condition (split /&(?:amp;)?/, $url) {
		if ($condition =~ /^(\w+)\.(\w+)=(.+)/) {
			my ($dbClass2, $key, $value) = ($1, $2, $3);
			
			if (utf8::is_utf8($value)) {
				utf8::decode($value);
				utf8::encode($value);
			}
			
			$key   = URI::Escape::uri_unescape($key);
			$value = URI::Escape::uri_unescape($value);
			
			if ($dbClass2 ne 'album') {
				$key = "$dbClass2.$key";
				push @$joins, $dbClass2;
			}
			
			$query->{$key} = $value;
		}
	}
	#$log->error(Data::Dump::dump({ query => $query, joins => $joins }));
	return Slim::Schema->search( 'Album', $query, { join => $joins } )->single();
}

=head1
sub _logCallStack {
	my $i = shift || 1;
	my $caller = "\nStack Trace:\n";
	while ( (my @call_details = (caller($i++))) ){
		$caller .= $call_details[1].":".$call_details[2]." in function ".$call_details[3]."\n";
	};
	$log->error($caller);
}
=cut

1;
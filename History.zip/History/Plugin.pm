package Plugins::History::Plugin;
# History copyright (c) 2023-10-27 by SvenInNdh (SvenInNdh@gmail.com)
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License, version 2.

use strict;
use base qw(Slim::Plugin::OPMLBased); #use base qw(Slim::Plugin::Base);

use Slim::Control::Request;
use Slim::Utils::Strings qw(string cstring);
use Slim::Utils::Prefs;

# create a logging object
my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.history',
	'defaultLevel' => 'WARN',
	'description'  => getMyDisplayName(),
});

# get a preference object
my $prefs = preferences('plugin.history');

$prefs->init({ addDelay => 10, maxHistorySize => 50 });

# globals
my $cache;
my $history = [];
my $fav_cliAdd_func; #Sven 2023-10-20
my $infoAlbum_func;  #Sven 2023-10-29

# setup routine
sub initPlugin {
	my $class = shift;
	
	$cache = Slim::Utils::Cache->new('history', 3, 1);
	#$cache = Slim::Utils::DbCache->new({ namespace => 'history' });
	
	Slim::Control::Request::subscribe( \&addTrack, [['playlist'],['newsong']]);
	Slim::Control::Request::subscribe( \&stopTrack, [['playlist'],['stop']]);
	
	#Sven 2023-11-03 Eine Möglichkeit einen InfoProvidor abzuleiten bzw. zu überschreiben
	my $infoProvidor = Slim::Menu::TrackInfo->getInfoProvider();
	if ($infoProvidor) { 
		$infoAlbum_func = $infoProvidor->{album}->{func};
		#überschreibt den orignalen InfoAlbum Providor 'album'
		Slim::Menu::TrackInfo->registerInfoProvider( album => (
			after => 'contributors',
			func  => \&trackInfoAlbum,
		) );
	}
	
	require Plugins::History::ProtocolHandler;
	if (main::WEBUI) {
		require Plugins::History::Settings;
		Plugins::History::Settings->new();
	}
	
	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => 'history',
		menu   => 'radios',
		is_app => 1,
		weight => 1,
	);
}

sub postinitPlugin {
	my $class = shift;
	
	#Sven 2023-10-20 korrigiert den Audiotype beim Speichern von M3U-Playlisten in den Favoriten
	#hierzu wird die original Methode cliAdd() aus dem Favoriten Plugin überschrieben.
	#postinitPlugin wird offenbar erst aufgerufen wenn alle Plugins (auch die internen) initialisiert sind.
	$fav_cliAdd_func = Slim::Control::Request::addDispatch(['favorites', 'add'], [0, 0, 1, \&cliAdd]);
	
	validateHistory();

}

sub getMyDisplayName { 'PLUGIN_HISTORY' }

# don't add this plugin to the Extras menu
sub playerMenu {}

sub getHistory {
	return $cache->get('history') || [];
}

#Sven 2023-10-27 Löscht nicht mehr gültige Tracks aus dem Wiedergabeverlauf nach einem Neustart
sub validateHistory {
	my $tracks = getHistory();
	
	my $size = scalar(@$tracks);
	for ( my $index = 0; $index < scalar(@$tracks); $index++ ) {
		my $entry = @$tracks[$index];
#		$log->error($entry);
#		if ($entry =~ /^radioparadise:/) {
#			splice(@$tracks, $index, 1);
#			$index--;
#			next;
#		}	
		unless ( Slim::Music::Info::isRemoteURL($entry) ) {
			unless ( Slim::Music::Info::isFile($entry) ) {
				splice(@$tracks, $index, 1);
				$index--;
			}
		}
	}
	$cache->set('history', $tracks, 'never') unless ( $size eq scalar(@$tracks) );
}

sub handleFeed {
	my ($client, $cb, $args) = @_;

#Sven 2023-10-30 Testkode um aus einer Track Url die album_id und die Tracks abzufragen.	
#	my $request = Slim::Control::Request::executeRequest($client, ['songinfo', 0,  4, 'url:' . 'file:///music/Pop/Rihanna/Unapologetic%20-%20Deluxe%20Edition/08%20-%20Rihanna%20-%20What%20Now.flac', 'tags:ec']);
#	my $tracks = $request->{_results}->{songinfo_loop};
#	my $album_id = @$tracks[2]->{album_id};
#	my $cover = '/music/' . @$tracks[3]->{coverid} . '/cover.jpg';
#	$request = Slim::Control::Request::executeRequest($client, ['titles', 0, 100, 'album_id:' . $album_id]);
#	$log->error(Data::Dump::dump({ cover => $cover }));
#	$log->error(Data::Dump::dump($request));

	if ( $args->{index} == 0 ) {
		my $tracks = getHistory();
		$history = [];
		foreach (@$tracks) {
			my $track = getTrackItemExt($client, $_);
			push @$history, $track if $track;
			#$log->error(Data::Dump::dump($track));
		};
	}
	$cb->({ items => $history });
}

sub addTrack {
	my $request = shift;
	my $client = $request->client();
	if ( defined $client ) {
		#my $id = $client->id(); # id = e0:69:95:35:53:a3
		#$log->error('addTrack - ' . $id);
		Slim::Utils::Timers::killTimers($client, \&addHistory);
		my $track = Slim::Player::Playlist::track($client);
		if ( defined $track ) {
			my $url  = ( blessed $track ) ? $track->url : $track;
			if ( $url =~ /^(http|https):/i ) { return; } # Filtert Radiostationen heraus
			Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + $prefs->get('addDelay'), \&addHistory, ($url) );
		}
	}
}

sub stopTrack {
	my $request = shift;
	my $client = $request->client();
	if ( defined $client ) {
		Slim::Utils::Timers::killTimers($client, \&addHistory);
	}
}

sub addHistory {
	my ($client, $url) = @_;
	
	if ( defined $url ) {
		my $tracks = getHistory();
		my $index  = 0;
		foreach (@$tracks) {
			if ( $_ eq $url ) {
				return if ($index eq 0);
				splice(@$tracks, $index, 1);
				last;
			}
			$index += 1;
		}
		unshift(@$tracks, $url);
		my $size = $prefs->get('maxHistorySize');
		while (scalar(@$tracks) > $size) { pop(@$tracks); }
		$cache->set('history', $tracks, 'never');
	}
}

sub getTrackItem {
	my ( $client, $meta, $url ) = @_;
	
	$meta = getTrackMetaFromUrl($client, $url) unless $meta;
	
	my $item = {
		name	  => sprintf('%s %s %s %s %s', $meta->{title}, cstring($client, 'BY'), $meta->{artist}, cstring($client, 'FROM'), $meta->{album}),
		line1	  => $meta->{title},
		line2	  => $meta->{artist} . ($meta->{artist} && $meta->{album} ? ' - ' : '') . $meta->{album},
		play	  => $meta->{url},
		on_select => 'play',
		playall   => 1,
	};
	if (defined $meta->{cover}) { $item->{image} = $meta->{cover}; }
	elsif (defined $meta->{coverid}) { $item->{image} = '/music/' . $meta->{coverid} . '/cover.jpg'; }
	return $item;
}

#Sven 2023-11-02 adds a submenu with the album item of the track
sub getTrackItemExt {
	my ( $client, $url ) = @_;
	
	my $track;
	my $meta = getTrackMetaFromUrl($client, $url);
	if (defined $meta) {
		my $items = [];
		push @$items, {
			name  => $meta->{album},
			label => 'ALBUM',
			url   => getAlbumUrl($meta->{url}, $meta->{albumId}),
			type  => 'playlist',
			image => $meta->{cover},
			#value => $meta->{albumId},
		};
		$track = getTrackItem($client, $meta);
		$track->{items} = $items;
	}
	#$log->error(Data::Dump::dump($track));
	return $track;
}

sub getTrackMetaFromUrl {
	my ( $client, $url ) = @_;
	my $meta = undef;
	
	if ( $url =~ /^file:\/\//i ) {
		my $request = Slim::Control::Request::executeRequest($client, ['songinfo', 0,  6, 'url:' . $url, 'tags:elca']);
		my $track = $request->getResult('songinfo_loop');
		$meta = {
			title   => @$track[1]->{title},
			album   => @$track[3]->{album},
			albumId => @$track[2]->{album_id},
			cover   => '/music/' . @$track[4]->{coverid} . '/cover.jpg',
			artist  => @$track[5]->{artist},
			url     => $url,
		};
		
	}
	elsif ( my $handler = Slim::Player::ProtocolHandlers->handlerForURL($url) ) {
		if ( $handler->can('getMetadataFor') ) {
			$meta = $handler->getMetadataFor($client, $url);
		}
		if ( defined $meta ) {
			if ( ! defined $meta->{cover} && $handler->can('getIcon') ) {
				$meta->{cover} = $handler->getIcon($url);
			}
			$meta->{url} = $url;
		}
	}
	#$log->error(Data::Dump::dump($meta));
	return $meta;
}

sub getAlbumUrl {
	my ($url, $albumId) = @_;
	if ( $url =~ /^file:/i ) {
		my $album = Slim::Schema->find('Album', $albumId);
		return Slim::Schema::Album::url($album) if $album;
		return 'db:album.id=' . $albumId; #  . '&libraryTracks.library=-1';
	}
	elsif ( $url =~ /^qobuz:/i ) {
		return 'qobuz:album:' . $albumId,
	}
	return $albumId;
}

#Sven 2023-10-20 korrigiert den Audiotype beim Speichern von M3U-Playlisten in den Favoriten
sub cliAdd {
	my $request = shift;

	if ($request->isNotCommand([['favorites'], ['add', 'addlevel']])) {
		$request->setStatusBadDispatch();
		return;
	}

	my $url = $request->getParam('url');
	
	#$log->error(Data::Dump::dump($url));
	#_logCallStack();

	#Sven 2023-10-20 korrigiert den Audiotype beim Speichern von M3U-Playlisten in den Favoriten
	if ($url =~ /^file:(.*)(\.m3u|\.qbz)$/i) {
#		my $icon = $request->getParam('icon');
#		$request->addParam('icon', 'html/images/playlists.png') if ! $icon || $icon eq 'list';
		$request->addParam('type', 'playlist');
	}

	if (defined $fav_cliAdd_func) {
		$fav_cliAdd_func->($request);
	}
}

#Sven 2023-11-02 bei Track wird beim Contextmenu der Menupunkt 'Album' eingefügt.
#Bei Favoriten steht da bei Track aus der Musik-Bibliothek im Feld 'url' einfach nur 'blabla'.
sub trackInfoAlbum {
	my ( $client, $url, $track, $remoteMeta, $tags, $filter ) = @_;
	#$log->error(Data::Dump::dump($url));
	#$log->error(Data::Dump::dump($track));
	#$log->error(Data::Dump::dump($remoteMeta));
	
	if ( $url =~ /^qobuz:\/\//i ) {
		return { name => $remoteMeta->{album}, label => 'ALBUM', url => 'qobuz:album:' . $remoteMeta->{albumId}, type => 'playlist', icon => $remoteMeta->{cover} };
	}
	elsif ( $url =~ /^file:\/\//i ) {
		my $album = Slim::Schema->find('Album', $track->albumid);
		#$log->error(Data::Dump::dump($album));
		if ($album) {
			my $item = { name => $album->name, label => 'ALBUM', url => Slim::Schema::Album::url($album), type => 'playlist' };
			if ($album->artwork) {
				$item->{icon} = 'music/' . $album->artwork . '/cover.png';
			}
			return $item;
		}
	}
	return $infoAlbum_func->(@_);
}

=head1
sub _logCallStack {
	my $i = shift || 1;
	my $caller = "\nStack Trace:\n";
	while ( (my @call_details = (caller($i++))) ){
		$caller .= $call_details[1].":".$call_details[2]." in function ".$call_details[3]."\n";
	};
	$log->error($caller);
}
=cut

1;


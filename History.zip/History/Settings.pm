package Plugins::History::Settings;
# History copyright (c) 2023 by SvenInNdh

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;

my $prefs = preferences('plugin.history');

sub name {
	return Slim::Web::HTTP::CSRF->protectName('PLUGIN_HISTORY_BASIC_SETTINGS');
}

sub page {
	return Slim::Web::HTTP::CSRF->protectURI('plugins/History/settings/basic.html');
}

sub prefs {
	return ($prefs, 'addDelay', 'maxHistorySize' );
}

sub getPrefs {
	return $prefs;
}

#sub needsClient {
#	return 0;
#}

1;

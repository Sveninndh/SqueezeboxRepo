package Plugins::Qobuz::HomeExtras;

use strict;

use Slim::Utils::Log;
use Plugins::Qobuz::Plugin;

my $log = logger('plugin.qobuz');

Plugins::Qobuz::HomeExtraQobuz->initPlugin();
Plugins::Qobuz::HomeExtraBestsellers->initPlugin();
Plugins::Qobuz::HomeExtraPress->initPlugin();
Plugins::Qobuz::HomeExtraPicks->initPlugin();
Plugins::Qobuz::HomeExtraNewReleases->initPlugin();
# Plugins::Qobuz::HomeExtraWeeklyQ->initPlugin();

main::INFOLOG && $log->is_info && $log->info("Registered Home Extras for Qobuz");

1;

package Plugins::Qobuz::HomeExtraBase;

use Slim::Utils::Log;

use base qw(Plugins::MaterialSkin::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	my $tag = $args{tag};

	#Sven 2026-06-01
	my $extra = {
		title => $args{title},
		icon  => $args{icon} || Plugins::Qobuz::Plugin->_pluginDataFor('icon'),
		needsPlayer => 1,
	};

	$extra->{count} = $args{count} if $args{count}; #Sven 2026-06-01 - Notwendig um den Parameter count (Anzahl der Elemente in der HomeExtra-Zeile) durchzureichen

	$class->SUPER::initPlugin(
		feed  => sub { handleFeed($tag, @_) },
		tag   => "QobuzExtras${tag}",
		extra => $extra,
	);
}

sub handleFeed {
	my ($tag, $client, $cb, $args) = @_;

	$args->{params}->{menu} = "home_heroes_${tag}";

	Plugins::Qobuz::Plugin::handleFeed($client, $cb, $args);
}

sub handleExtra {
	my ($class, $client, $cb, $count, $userId) = @_;

	$class->SUPER::handleExtra($client, sub {
		my $results = shift;

		my $icon = Plugins::Qobuz::Plugin->_pluginDataFor('icon');
		foreach (@{$results->{item_loop} || []}) {
			$_->{icon} ||= $icon;
		}

		$cb->($results);
	}, $count, $userId);
}

1;



package Plugins::Qobuz::HomeExtraQobuz;

use base qw(Plugins::Qobuz::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	$class->SUPER::initPlugin(
		title => 'PLUGIN_QOBUZ',
		tag => 'qobuz',
		count => 20
	);
}

1;

package Plugins::Qobuz::HomeExtraBestsellers;

use base qw(Plugins::Qobuz::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	$class->SUPER::initPlugin(
		title => 'PLUGIN_QOBUZ_BESTSELLERS',
		tag => 'best-sellers'
	);
}

1;

package Plugins::Qobuz::HomeExtraPress;

use base qw(Plugins::Qobuz::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	$class->SUPER::initPlugin(
		title => 'PLUGIN_QOBUZ_DISCOVER_PRESSAWARDS',
		tag => 'press-awards'
	);
}

1;

package Plugins::Qobuz::HomeExtraPicks;

use base qw(Plugins::Qobuz::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	$class->SUPER::initPlugin(
		title => 'PLUGIN_QOBUZ_EDITOR_PICKS',
		tag => 'editor-picks',
	);
}

1;

package Plugins::Qobuz::HomeExtraNewReleases;

use base qw(Plugins::Qobuz::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	$class->SUPER::initPlugin(
		title => 'PLUGIN_QOBUZ_DISCOVER_NEWRELEASES',
		tag => 'new-releases-full',
	);
}

1;

# package Plugins::Qobuz::HomeExtraWeeklyQ;

# use base qw(Plugins::Qobuz::HomeExtraBase);

# sub initPlugin {
# 	my ($class, %args) = @_;

# 	$class->SUPER::initPlugin(
# 		title => 'PLUGIN_QOBUZ_MYWEEKLYQ',
# 		tag => 'weeklyq',
# 	);
# }

# 1;

package Plugins::Qobuz::Addon;
# private

use strict;

sub favMenu {}

sub check {
	return shift;
}

1;

package Plugins::Qobuz::HomeExtras;

use strict;

use Slim::Utils::Log;
use Plugins::Qobuz::Plugin;

my $log = logger('plugin.qobuz');

# Plugins::Qobuz::HomeExtraQobuz->initPlugin(); # siehe Kommentar bei der Funktion
Plugins::Qobuz::HomeExtraBestsellers->initPlugin();
Plugins::Qobuz::HomeExtraPress->initPlugin();
Plugins::Qobuz::HomeExtraPicks->initPlugin();
Plugins::Qobuz::HomeExtraNewReleases->initPlugin();
# Plugins::Qobuz::HomeExtraWeeklyQ->initPlugin(); # Qobuz unterstützt seit Herbst 2025 MyWeeklyQ nicht mehr

main::INFOLOG && $log->is_info && $log->info("Registered Home Extras for Qobuz");

1;

package Plugins::Qobuz::HomeExtraBase;

use Slim::Utils::Log;

use base qw(Plugins::MaterialSkin::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	my $tag = $args{tag};

	#Sven 2026-06-01
	my $extra = {
		title => $args{title},
		icon  => $args{icon} || Plugins::Qobuz::Plugin->_pluginDataFor('icon'),
		needsPlayer => 1,
	};

	$extra->{count} = $args{count} if $args{count}; #Sven 2026-06-01 - Notwendig um den Parameter count (Anzahl der Elemente in der HomeExtra-Zeile) durchzureichen

	$class->SUPER::initPlugin(
		feed  => sub { handleFeed($tag, @_) },
		tag   => "QobuzExtras${tag}",
		extra => $extra,
	);
}

sub handleFeed {
	my ($tag, $client, $cb, $args) = @_;

	$args->{params}->{menu} = "home_heroes_${tag}";

	Plugins::Qobuz::Plugin::handleFeed($client, $cb, $args);
}

sub handleExtra {
	my ($class, $client, $cb, $count, $userId) = @_;

	$class->SUPER::handleExtra($client, sub {
		my $results = shift;

		my $icon = Plugins::Qobuz::Plugin->_pluginDataFor('icon');
		foreach (@{$results->{item_loop} || []}) {
			$_->{icon} ||= $icon if $_->{text}; # Damit die Leerelemente die Slim\Control\XMLBrowser.pm in Zeile 1013 erzeugt nicht unnötig $icon zugewiesen bekommen.
		}

		$cb->($results);
	}, $count, $userId);
}

1;

=head2
# This shows the full Qobuz start menu in a "Home Extra" view.
# Dies zeigt das vollständige Qobuz-Startmenü in einer „Home Extra“-Ansicht.
# Da ich zwei 'header' im diesem Menü verwende, habe ich diese ziemlich sinnfreie Funktion entfernt, da das zu unnötigen Irritationen geführt hat.
package Plugins::Qobuz::HomeExtraQobuz;

use base qw(Plugins::Qobuz::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	$class->SUPER::initPlugin(
		title => 'PLUGIN_QOBUZ',
		tag => 'qobuz',
		count => 20
	);
}

1;
=cut

package Plugins::Qobuz::HomeExtraBestsellers;

use base qw(Plugins::Qobuz::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	$class->SUPER::initPlugin(
		title => 'PLUGIN_QOBUZ_BESTSELLERS',
		tag => 'best-sellers'
	);
}

1;

package Plugins::Qobuz::HomeExtraPress;

use base qw(Plugins::Qobuz::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	$class->SUPER::initPlugin(
		title => 'PLUGIN_QOBUZ_DISCOVER_PRESSAWARDS',
		tag => 'press-awards'
	);
}

1;

package Plugins::Qobuz::HomeExtraPicks;

use base qw(Plugins::Qobuz::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	$class->SUPER::initPlugin(
		title => 'PLUGIN_QOBUZ_EDITOR_PICKS',
		tag => 'editor-picks',
	);
}

1;

package Plugins::Qobuz::HomeExtraNewReleases;

use base qw(Plugins::Qobuz::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	$class->SUPER::initPlugin(
		title => 'PLUGIN_QOBUZ_DISCOVER_NEWRELEASES',
		tag => 'new-releases-full',
	);
}

1;

=head2
# Qobuz unterstützt seit Herbst 2025 MyWeeklyQ nicht mehr
package Plugins::Qobuz::HomeExtraWeeklyQ;

use base qw(Plugins::Qobuz::HomeExtraBase);

sub initPlugin {
 	my ($class, %args) = @_;

 	$class->SUPER::initPlugin(
 		title => 'PLUGIN_QOBUZ_MYWEEKLYQ',
 		tag => 'weeklyq',
 	);
}

1;
=cut

=head Infos
2025-11-05 History v1.5.0 copyright (c) by SvenInNdh (SvenInNdh@gmail.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License, version 2.

2023-10-20 korrigiert den Audiotype beim Speichern von M3U-Playlisten in den Favoriten. Entfernt ab v1.4.7
2023-11-02 Im Trackmenü wird beim Contextmenu der Menupunkt 'Album' eingefügt.
		   Bei Favoriten steht da bei Tracks aus der Musik-Bibliothek im Feld 'url' einfach nur 'blabla'.
2023-11-03 Eine Möglichkeit einen InfoProvidor abzuleiten bzw. zu überschreiben
2024-01-20 Unterstützung von Radiostreams hinzugefügt - Dank an Michael Herger einiger Ideen.
2024-01-20 Erzeugt das Trackmenü - Dank an Michael Herger für Idee und Teile seines Programmcodes aus 'What Was That Tune'.
2024-01-22 Playereinstellung für 'Anzeigemodus'.
2024-01-23 Einlesen der Stationsnamen bei Radiostreams über die Metadaten die der Stream sendet.
2024-01-25 Entfernen von Titeln aus dem Wiedergabeverlauf in den Einstellungen
2024-02-01 Cachen der Verlaufsanzeige um in 95% aller Fälle falsche Zuordnungen beim Abspielen oder
           öffnen des Menüs eines Eintrags aus dem Verlauf zu vermeiden.
2024-02-02 Playereinstellung für 'Titelauswahlmodus'.
2025-09-28 Einige Optimierungen, Anzeige von Radiotiteln, suchen der Titel bzw. Alben in Qobuz falls das Plugin installiert ist.
2025-10-24 Änderung um Problme ohne installiertes Qobuz Plugin kzu vermeiden.
=cut

# $log->error(Data::Dump::dump( ));

package Plugins::History::Plugin;

use strict;
use base qw(Slim::Plugin::OPMLBased);

use Slim::Control::Request;
use Slim::Utils::Strings qw(string cstring);
use Slim::Utils::Prefs;

#use Plugins::History::Menu;

use constant DEFAULT_EXPIRY => 60 * 5;
# create a logging object
my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.history',
	'defaultLevel' => 'ERROR',
	'description'  => 'PLUGIN_HISTORY',
});

# get preference objects
my $prefs = preferences('plugin.history');
my $prefsServer = preferences('server');

$prefs->init({ addDelay => 10, maxHistorySize => 50, delopt => '0' });

# globals
my $cache;
my $fav_cliAdd_func;	# 2023-10-20
my $infoAlbum_func;		# 2023-10-29
my $station_name = {};	# 2024-01-22 Speichert der ermittelten Stationsnamen pro Player
my $init_History = 0;	# 2024-01-24  1 = Migration und Validierung, 0 = none
my $cacheHistory = {};	# 2024-02-01 Cachen der Anzeige des Wiedergabeverlaufs
my $isQobuz = 0;        # 2025-10-24 Damit es ohne Qobuz Plugin keine Probleme gibt.

# setup routine
sub initPlugin {
	my $class = shift;

	# gibt einen Pointer auf den Cache mit dem Namespace 'history' zurück, falls er noch nicht existiert wird er erzeugt.
	$cache = Slim::Utils::Cache->new('history', 3, 1);

	Slim::Control::Request::subscribe( \&addTrack, [['playlist','newmetadata']] );
	Slim::Control::Request::subscribe( \&stopTrack, [['playlist'],['stop']]);

	Slim::Menu::TrackInfo->registerInfoProvider( historyTrackInfo => (
		#after => 'top',
		func  => \&nowPlayingInfoMenu,
	) );

	#Sven 2023-11-03, 2025-09-28 - Eine Möglichkeit einen InfoProvidor abzuleiten bzw. zu überschreiben
	my $infoProvidor = Slim::Menu::TrackInfo->getInfoProvider();
	if ($infoProvidor) { 
		$infoAlbum_func = $infoProvidor->{album}->{func};
		#Sven - überschreibt den orignalen InfoAlbum Providor 'album' - SLIM:MENU:TRACKINFO:infoAlbum()
		$infoProvidor->{album}->{func} = \&trackInfoAlbum;
	}

	if (main::WEBUI) {
		require Plugins::History::Settings;
		require Plugins::History::SettingsPlayer;
		Plugins::History::Settings->new();
		Plugins::History::SettingsPlayer->new();
	}
	
	$init_History = 1;
	
	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => 'history',
		is_app => 1,
	);
}

#Sven 2025-10-24 
sub postinitPlugin {
	my $class = shift;
	
	if ( Slim::Utils::PluginManager->isEnabled('Plugins::Qobuz::Plugin') ) {
		eval {
			require Plugins::Qobuz::Plugin;
		};
		$isQobuz = 1;
	}
}

sub nowPlayingInfoMenu {
	my ( $client, $url, $track, $remoteMeta, $tags ) = @_;

	return unless $client && $tags;

	return {
		name => $client->string(getDisplayName()),
		type => 'link',
		url  => \&handleFeed,
		isContextMenu => 1,
	};
}

sub getDisplayName { 'PLUGIN_HISTORY' }

# don't add this plugin to the Extras menu
sub playerMenu {}

sub getHistory {
	return $cache->get('history') || [];
}

# 2024-01-25 Serviceroutine - Migration und Validierung
sub doValidate {
	my $client = shift;

	my $items = getHistory();
	return $items unless $init_History;
	
	my $size  = scalar(@$items);
	# Migration und Validierung
	if ($size > 0 && (ref(@$items[$size-1]) ne 'HASH') ) { #Sven Migration des Datenformats der History-Liste auf aktuelle Version
		my $id = $client->id();
		for ( my $index = 0; $index < $size; $index++ ) {
			if (ref(@$items[$index]) ne 'HASH') {
				my $item = { url => @$items[$index], clientid => $id };
				@$items[$index] = $item;
			}
		}
	}
	# Löscht nicht mehr gültige Tracks aus dem Wiedergabeverlauf
	for ( my $index = 0; $index < scalar(@$items); $index++ ) {
		my $meta = getItemMeta($client, @$items[$index]);
		unless (defined $meta && $meta->{title}) {
			splice(@$items, $index, 1);
			$index--;
		}
	}
	
	$cache->set('history', $items, 'never') unless ( $size eq scalar(@$items) );
	
	$init_History = 0;

	return $items;
}

# 2024-01-25 Entfernen von Einträgen im Wiedergabeverlauf, wird in settings.pm aufgerufen 
sub removeItems {
	my ($clientId, $option, $radioname) = @_;
	
	my $items = getHistory();
	my $size  = scalar(@$items);
	for ( my $index = 0; $index < scalar(@$items); $index++ ) {
		my $entry = @$items[$index];
		if ( $entry->{clientid} eq $clientId ) {
			if (exists $entry->{remote_title}) { # ist ein radiostream
				next if ( $option eq '1' );
				unless ( $radioname eq '' ) {
					next unless ($entry->{remote_title} =~ /$radioname/i); # wenn keine Radiostreams entfernt werden sollen überspringen
				}
			}
			else {
				next if ( $option eq '0'); # wenn nur Radiostreams entfernt werden sollen überspringen
			}
			splice(@$items, $index, 1);
			$index--;
		}
	}
	$cache->set('history', $items, 'never') unless ( $size eq scalar(@$items) );
}

sub getPlayers {
	my $items = getHistory();

	my $clients = {};
	foreach ( @$items ) {
		$clients->{$_->{clientid}}++;
	}

	my $players = [];
	foreach ( sort keys %{ $clients } ) {
		my $playername = $_;
		my $client = Slim::Player::Client::getClient($_);
		if ($client) {
			$playername = $client->name;
		}
		else {
			eval {
				$playername = Slim::Utils::Prefs::Client->new($prefsServer, $_)->get('playername');
			};
			$@ && $log->warn("Failed to get player name from prefs: $@");
		}
		push @$players, { name => $playername, id => $_ };
	}

	return $players;
}

sub handleFeed {
	my ($client, $cb, $params, $args) = @_;

	my $id;
	my $mode = $prefs->client($client)->get('mode');
	
	if ($mode eq '2') {
		if ( !$args || !$args->{client} ) {
			my $items = [];
			push @$items, {
				type => 'link',
				name => cstring($client, 'ALL'),
				url  => \&handleFeed,
				passthrough => [{ client => '_ALL_' }]
			};

			my $players = getPlayers();
			foreach ( @$players) {
				push @$items, {
					type => 'link',
					name => $_->{name},
					url  => \&handleFeed,
					passthrough => [{ client => $_->{id} }]
				};
			}
			
			$cb->({ items => $items });
			return;
		}
		else {
			$id = $args->{client};
		}
	}
	else {
		$id = ($mode eq '0') ? '_ALL_' : $client->id();
	}

=head
	Der Wiedergabeverlauf wird nur im Moment des Aufrufs aktualisiert. Während er Anzeigt wird verändert er sich nicht, auch wenn
	in dieser Zeit neue Einträge dazu kommen.
	Wenn ein Wiedergabeverlauf angezeigt wird, kann gleichzeitig ein Radiosender spielen oder ein Album bzw. eine Playlist.
	Bei jedem neuen Song wird dann ein neuer Eintrag im Wiedergabeverlauf erzeugt.
	Leider ist keine Möglichkeit bekannt die Anzeige des Verlaufs automatisch zu aktualisieren sobald er sich ändert.
	Intern werden aber schon die neuen Werte geladen und dann stimmen die Einträge nicht mehr mit der Anzeige überein.
	Das Plugin 'What Was That Tune?' hat genau das gleiche Problem. Wenn dort aus der Anzeige des Wiedergabeverlaufs ist, der falsche Titel abgespielt wird
	oder im Untermenu des Titels nichts oder völlig falsche Werte angezeigt werden, liegt das genau an dieser Problematik.
	Um das Problem zu entschärfen speichere ich die Liste in einem Cache pro Player. Der Verlauf wird dann immer nur aus dem Cache angezeigt
	und erst dann wieder neu geladen wenn man den Verlauf erneut aufruft.
	Mir ist auch nichts bekannt an dem man ablesen könnte, ob eine gerade angezeigte Liste wieder verlassen wurde.
	Daher gibt es als sicheren Triggerpunkt nur den Moment unmittelbar bevor die Verlaufliste angezeigt wird.
	An dieser Stelle wird dann der Cache gelöscht und dies triggert dann das Neueinlesen des Verlaufs bevor er dann zur Anzeige kommt.
	Dies Funktioniert solange nicht zwei Benutzer zur gleichen Zeit den gleichen Player steuern.
	Da das in der Praxis jedoch kaum vorkommt funktioniert die Lösung hier in den allermeisten Fällen sehr gut.
=cut
	delete $cacheHistory->{$id} if ($params->{index} == 0 );
	my $items = getPlayhistory($client, $id);
	$cb->({ items => $items });
}

sub getPlayhistory {
	my ($client, $id) = @_;

	if (my $cached = $cacheHistory->{$id}) {
		return $cached;
	}

	my $sid = ($id eq '_ALL_') ? '' : $id;
	
	my $playdirect = $prefs->client($client)->get('trackmode');
	   $playdirect = ($playdirect) ? ($playdirect eq '0') : 1;

	my $items = doValidate($client);
	my $history = [];
	foreach (@$items) {
		push @$history, getTrackItem($client, $_, $playdirect) if ( ! $sid || $_->{clientid} eq $sid);
	};
	
	$cacheHistory->{$id} = $history;
	
	main::DEBUGLOG && $log->is_debug && $log->debug(Data::Dump::dump($history));

	return $history;
}

sub getTrackItem {
	my ( $client, $HiItem, $playdirect ) = @_;

	my $meta = getItemMeta($client, $HiItem);
	my $album = $meta->{album};
	my ($name, $line1, $line2);
	if (exists $meta->{remote_title}) { #Radiostream
		$name  = $line1 = $meta->{remote_title};
		$line2 = $meta->{artist} . ' - ' . $meta->{title};
		$line2 = sprintf('%s %s %s', $meta->{title}, cstring($client, 'BY'), $meta->{artist});
		if ($album) { $line2 .= sprintf(' %s %s', cstring($client, 'FROM'), $album); }
	}
	else {
		$name  = sprintf('%s %s %s %s %s', $meta->{title}, cstring($client, 'BY'), $meta->{artist}, cstring($client, 'FROM'), $album);
		$line1 = $meta->{title};
		$line2 = join(' - ', grep { $_ } ($meta->{artist}, $album, _sec2hms($meta->{duration})));
	}
	my $item = {
		name	=> $name,
		line1	=> $line1,
		line2	=> $line2,
		url		=> \&trackMenu,
		passthrough => [ $meta ],
	};
	$item->{image} = $meta->{cover} || '/music/' . $meta->{coverid} . '/cover.jpg';
	
	if ($playdirect) {
		$item->{play}	   = $meta->{url};
		$item->{playall}   = 1;
		$item->{on_select} = 'play';
	}

	return $item;
}

sub getItemMeta {
	my ( $client, $item ) = @_;
	my $meta = undef;
	my $url  = $item->{url};
	if (exists $item->{remote_title}) { # Bedingung ist nur bei Radiostreams wahr.
		$meta = {
			title		 => $item->{title},
			artist		 => $item->{artist},
			remote_title => $item->{remote_title},
			url			 => $url,
		};

		if (exists $item->{album}) {
			$meta->{album} = $item->{album};
			# Clean up album because Radio Now Playing can put extra info at the end
			$meta->{album} =~ s/ ?\| .*//;
		}

		if ( defined $item->{cover} ) {
			$meta->{cover} = $item->{cover};
		}
		else {
			$meta->{coverid} = $item->{coverid};
		}
	}
	elsif ( $item->{album} ) {
		$meta = {
			title    => $item->{title},
			tracknum => $item->{tracknum},
			duration => $item->{duration},
			album    => $item->{album},
			cover    => '/music/' . $item->{coverid} . '/cover.jpg',
			artist   => $item->{artist},
			url      => $url,
		};
	}
	elsif ( Slim::Music::Info::isFile($url) ) {
		my $request = Slim::Control::Request::executeRequest($client, ['songinfo', 0,  6, 'url:' . $url, 'tags:elca']); #c = coverid, a = artist, e = album_id, l = album, K = artwork_url, N = remote_title
		my $track = $request->getResult('songinfo_loop');
		$meta = {
			title   => @$track[1]->{title},
			album   => @$track[3]->{album},
			albumId => @$track[2]->{album_id},
			cover   => '/music/' . @$track[4]->{coverid} . '/cover.jpg',
			artist  => @$track[5]->{artist},
			url     => $url,
		};
	}
	elsif ( my $handler = Slim::Player::ProtocolHandlers->handlerForURL($url) ) {
		if ( $handler->can('getMetadataFor') ) {
			$meta = $handler->getMetadataFor($client, $url);
		}
		if ( defined $meta ) {
			if ( ! defined $meta->{cover} && $handler->can('getIcon') ) {
				$meta->{cover} = $handler->getIcon($url);
			}
			$meta->{url} = $url;
		}
	}

	return $meta;
}

sub addTrack {
	my $request = shift;

	my $client = $request->client();
	return unless ($client && $client->isPlaying());

	my $url = Slim::Player::Playlist::url($client);
	return unless $url;

	my $meta = getSongMeta($client, $url);
	return unless defined $meta;

	Slim::Utils::Timers::killTimers($client, \&addItem);
	Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + $prefs->get('addDelay'), \&addItem, ($meta) );
}

sub stopTrack {
	my $request = shift;
	my $client = $request->client();
	if ( defined $client ) {
		Slim::Utils::Timers::killTimers($client, \&addItem);
	}
}

sub getSongMeta {
	my ($client, $url) = @_;
	my $id   = $client->id();
	my $meta = { url => $url, clientid => $id };

	my $request = Slim::Control::Request::executeRequest($client, ['songinfo', 0, 7, 'url:' . $url, 'tags:NKal']); #c = coverid, a = artist, e = album_id, d = duration, r = bitrate, l = album, K = artwork_url, N = remote_title
	if ($request) {
		main::DEBUGLOG && $log->is_debug && $log->debug(Data::Dump::dump($request->getResults()));
		my $songinfo;

		eval {
			$songinfo = $request->getResult('songinfo_loop');
		};

		if ($@) {
			$log->warn("Failed to get song information: $@\n" . Data::Dump::dump($request->getResults()));
			return;
		}

		foreach (@$songinfo) {
			my ($k, $v) = each %$_;
			$k = 'cover' if ($k eq 'artwork_url');
			$meta->{$k} = $v || '';
		}
	}

	return undef unless $meta->{title};

	if ( $url =~ /(^radioparadise:|stream.radioparadise.com)/i ) { # behandlung von Radio Paradise
		unless ($meta->{artist}) {
			
			my $station = join(' - ', grep { $_ } ($meta->{title}, $meta->{remote_title}));
			unless ($station =~ /radio paradise/i) { $station = 'Radio Paradise - ' . $station; }
			$station_name->{$id} = $station;
			return;
		}
		$meta->{remote_title} = $station_name->{$id};
	}
	elsif ( $url =~ /^accur:/i ) { # behandlung von Accuradio
		return undef unless $meta->{artist};
		$meta->{cover} = 'html/images/radio.png'; # wegen 'hot linking' werden die artwork links von Accuradio geblockt.
		$meta->{remote_title} = 'Accuradio';
	}
	elsif ( $url =~ /^(http|https):/i ) { # sonstige Radiostreams, TuneIn etc.
		
		if ( $meta->{remote_title} ) { #|| $meta->{remote_title} =~ /$meta->{artist}/i );
			$station_name->{$id} = $meta->{remote_title};
		}
		return undef if ( ! $meta->{artist} || $meta->{remote_title} =~ /$meta->{artist}/i );
		$meta->{remote_title} = $station_name->{$id} unless ($meta->{remote_title});
		return undef if ($meta->{remote_title} eq $meta->{title});
	}
	else { $station_name->{$id} = ''; }

	return $meta;
}

sub addItem {
	my ($client, $item) = @_;

	my $items = getHistory();
	my $id = $item->{clientid};
	if ( exists $item->{remote_title} ) { # verhindert bei Radiostreams doppelten Eintrag
		my $previous = undef;
		my $index = 0;
		foreach (@$items) {
			if ($_->{clientid} eq $id) {
				$previous = $_;
				last;
			}
			$index += 1;
		}
		if (defined $previous && exists $previous->{remote_title}) {
			if ($previous->{title} eq $item->{title} && $previous->{artist} eq $item->{artist}) {
				return;
			}
		}
	}
	else { # holt den gerade gespielten Track nach vorne, wenn er bereits in der History enthalten ist.
		my $url   = $item->{url};
		my $index = 0;
		foreach (@$items) {
			if ( $_->{url} eq $url && $_->{clientid} eq $id) {
				return if ($index eq 0);
				splice(@$items, $index, 1);
				last;
			}
			$index += 1;
		}
		$item = { url => $url, clientid => $id };
	}

	my $size = $prefs->get('maxHistorySize');
	unshift(@$items, $item);
	while (scalar(@$items) > $size) { pop(@$items); } # Verkleinert den Wiedergabeverlauf falls mehr als maxHistorySize Einträge enthält.
	$cache->set('history', $items, 'never');
}

# 2023-11-02 bei Track wird beim Contextmenu der Menupunkt 'Album' eingefügt.
# Bei Favoriten steht da bei Track aus der Musik-Bibliothek im Feld 'url' einfach nur 'blabla'.
# on_select => 'play', playall => 1,
sub trackInfoAlbum {
	my ( $client, $url, $track, $remoteMeta, $tags, $filter ) = @_;
	
	#$log->error(Data::Dump::dump( { isQobuz => $isQobuz, remoteMeta => $remoteMeta } ));
	
	my $item;
	if ( $isQobuz && $url =~ /^qobuz:\/\//i ) { #Sven 2025-10-24 Wird nur bei installierten Qobuz Plugin ausgeführt.
		$item = {
			name  => $remoteMeta->{album},
			image => $remoteMeta->{cover},
			label => 'ALBUM',
			type  => 'link',
			url   => sub { 
						my ($client, $cb, $params, $args) = @_;
						Slim::Control::Request::executeRequest($client, ['qobuz', 'command', ['album', $cb, $params, $args]]);
					 },
			passthrough => [{ album_id => $remoteMeta->{albumId}, album_title => $remoteMeta->{album} }]
		};
	}
	else {
		my $album = $remoteMeta->{album};

		unless ($remoteMeta->{remote_title}) { $remoteMeta->{album} = ''; } #Sven - Damit der Standard TrackInfoProvidor für Alben das Album als Liste anzeigt.
	
		$item = $infoAlbum_func->(@_); #Sven - Aufruf des Standard TrackInfoProvidors SLIM:MENU:TRACKINFO:infoAlbum() für Alben, siehe initLogin()

		if ($remoteMeta->{cover} && $item->{type} eq 'playlist') { $item->{icon} = $remoteMeta->{cover} } 
		#delete $item->{label};

		$remoteMeta->{album} = $album;
	}

	return $item;
}

sub trackMenu {
	my ($client, $cb, $params, $meta) = @_;

	$cb->( getTrackMenu( $client, $meta ) );
}

# 2024-01-20 Erzeugt das Trackmenü - danke an Michael Herger für Idee und Teile seines Kodes aus 'What Was That Tune' menu.pm.
sub getTrackMenu {
	my ($client, $remoteMeta) = @_;
	my $tags = { menuMode => 'history' };
	
	my $url = $remoteMeta->{url};
	
	my $track = Slim::Schema->objectForUrl( {
		url => $url,
		create => 1,
	} );
	
	# Function to add menu items
	my $addItem = sub {
		my ( $ref, $items ) = @_;

		if ( defined $ref->{func} ) {

			# skip jive-only items for non-jive UIs
			return if $ref->{menuMode} && !$tags->{menuMode};

			my $item = eval { $ref->{func}->( $client, $url, $track, $remoteMeta, $tags ) };
			if ( $@ ) {
				$log->error( 'History menu item "' . $ref->{name} . '" failed: ' . $@ );
				return;
			}

			return unless defined $item;
			

			if ( ref $item eq 'ARRAY' ) {
				if ( scalar @{$item} ) {
					push @{$items}, @{$item};
				}
			}
			elsif ( ref $item eq 'HASH' ) {
				return if $ref->{menuMode} && !$tags->{menuMode};
				if ( scalar keys %{$item} ) {
					push @{$items}, $item;
				}
			}
			else {
				$log->error( 'History menu item "' . $ref->{name} . '" failed: not an arrayref or hashref' );
			}
		}
	};

	# If we don't have an ordering, generate one.
	# This will be triggered every time a change is made to the
	# registered information providers, but only then. After
	# that, we will have our ordering and only need to step
	# through it.
	my $infoOrdering = Slim::Menu::TrackInfo->getInfoOrdering();

	# Now run the order, which generates all the items we need
	my $items = [];

	for my $ref ( @{ $infoOrdering } ) {
		# Skip items with a defined parent, they are handled
		# as children below
		next if $ref->{parent};

		# Add the item
		$addItem->( $ref, $items );

		# Look for children of this item
		my @children = grep {
			$_->{parent} && $_->{parent} eq $ref->{name}
		} @{ $infoOrdering };

		if ( @children ) {
			my $subitems = $items->[-1]->{items} = [];

			for my $child ( @children ) {
				$addItem->( $child, $subitems );
			}
		}
	}

	# Remove distinct play/add items and add a single playable URL
	if ($track->url) {
		$items = [ grep {
			($_->{jive} && $_->{jive}->{actions}) ? undef : $_
		} @$items ];

		my $playdirect = $prefs->client($client)->get('trackmode');
		$playdirect = ($playdirect) ? ($playdirect eq '0') : 1;
		unless ($playdirect) {
			unshift @$items, {
				name => $remoteMeta->{remote_title} || Slim::Music::TitleFormatter::infoFormat($track, '', 'TITLE - ARTIST', $remoteMeta),
				type => 'audio',
				url => $url
			};
		}
	}

	return {
		name  => $track->title || Slim::Music::Info::getCurrentTitle( $client, $url, 1 ),
		type  => 'opml',
		items => $items,
		play  => $url,
		cover => $remoteMeta->{cover} || $remoteMeta->{icon} || '/music/' . ($track->coverid || 0) . '/cover.jpg',
		menuComplete => 1,
	};
}

#Sven 2019-03-19
#Slim::Utils::DateTime::timeFormat(),
sub _sec2hms {
	my $seconds = shift;

	return $seconds unless ($seconds);

	my $minutes   = int($seconds / 60);
	my $hours     = int($minutes / 60);
	return sprintf('%s:%02s:%02s', $hours, $minutes % 60, $seconds % 60) if ($hours);
	return sprintf('%02s:%02s', $minutes, $seconds % 60); 
}

1;


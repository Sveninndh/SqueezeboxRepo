package Plugins::History::Settings;
# History copyright (c) 2023 by SvenInNdh

use strict;
use base qw(Slim::Web::Settings);

#use Slim::Utils::Log;
use Slim::Utils::Prefs;

my $prefs = preferences('plugin.history');
#my $log = logger('plugin.history');

sub name {
	return Slim::Web::HTTP::CSRF->protectName('PLUGIN_HISTORY');
}

sub page {
	return Slim::Web::HTTP::CSRF->protectURI('plugins/History/settings/basic.html');
}

sub prefs {
	my ($class, $client) = @_;
	return ($prefs, qw(addDelay maxHistorySize delopt));
}

sub getPrefs {
	return $prefs;
}

sub handler {
	my ($class, $client, $params) = @_;

	if ( $params->{saveSettings} ) {
		my $radioname = $params->{pref_radioname};
		my $delopt    = $params->{pref_delopt};
		foreach (keys %$params) {
			next unless /^clientid_/;
			if (my $id = $params->{$_}) {
				# hier die Routine zum Löschen aufrufen
				Plugins::History::Plugin::removeItems($id, $delopt, $radioname);
			}
		}
		#$prefs->set('delopt', $delopt);
	}
	#else { $params->{'delopt'} = $prefs->get('delopt'); }

	$params->{clients} = Plugins::History::Plugin::getPlayers();

	return $class->SUPER::handler( $client, $params );
}
#sub needsClient {
#	return 0;
#}

1;

package Plugins::History::HomeExtras;

use strict;
use Plugins::History::Plugin;

Plugins::History::HomeExtraLastPlayed->initPlugin();

1;


package Plugins::History::HomeExtraBase;

use base qw(Plugins::MaterialSkin::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	my $tag = $args{tag};

	my $extra = {
		title => $args{title},
		icon  => $args{icon} || Plugins::Qobuz::Plugin->_pluginDataFor('icon'),
		needsPlayer => 1,
	};

	$extra->{count} = $args{count} if $args{count};

	$class->SUPER::initPlugin(
		feed => sub { handleFeed($tag, @_) },
		tag  => "HistoryExtras${tag}",
		extra => $extra,
	);
}

sub handleFeed {
	my ($tag, $client, $cb, $args) = @_;

	$args->{params}->{menu} = "home_heroes_${tag}";

	Plugins::History::Plugin::handleFeed($client, $cb, $args);
}

1;


package Plugins::History::HomeExtraLastPlayed;

use base qw(Plugins::History::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	$class->SUPER::initPlugin(
		title => 'PLUGIN_HISTORY',
		tag   => 'lastplayed',
		icon  => 'plugins/History/html/images/history_svg.png',
		count => 20,
	);
}

1;


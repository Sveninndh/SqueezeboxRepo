=head Infos
2026-05-08 History v2.0.0 copyright (c) by SvenInNdh (SvenInNdh@gmail.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License, version 2.

2023-10-20 korrigiert den Audiotype beim Speichern von M3U-Playlisten in den Favoriten. Entfernt ab v1.4.7
2023-11-02 Im Trackmenü wird beim Contextmenu der Menupunkt 'Album' eingefügt.
		   Bei Favoriten steht da bei Tracks aus der Musik-Bibliothek im Feld 'url' einfach nur 'blabla'.
2023-11-03 Eine Möglichkeit einen InfoProvidor abzuleiten bzw. zu überschreiben
2024-01-20 Unterstützung von Radiostreams hinzugefügt - Dank an Michael Herger einiger Ideen.
2024-01-20 Erzeugt das Trackmenü - Dank an Michael Herger für Idee und Teile seines Programmcodes aus 'What Was That Tune'.
2024-01-22 Playereinstellung für 'Anzeigemodus'.
2024-01-23 Einlesen der Stationsnamen bei Radiostreams über die Metadaten die der Stream sendet.
2024-01-25 Entfernen von Titeln aus dem Wiedergabeverlauf in den Einstellungen
2024-02-01 Cachen der Verlaufsanzeige um in 95% aller Fälle falsche Zuordnungen beim Abspielen oder
           öffnen des Menüs eines Eintrags aus dem Verlauf zu vermeiden.
2024-02-02 Playereinstellung für 'Titelauswahlmodus'.
2025-09-28 Einige Optimierungen, Anzeige von Radiotiteln, suchen der Titel bzw. Alben in Qobuz falls das Plugin installiert ist.
2025-10-24 Änderung um Probleme ohne installiertes Qobuz Plugin zu vermeiden.
2026-01-12 Support für HomeExtras, der Wiedergabeverlauf kann in Material auch als scrollbare Liste angezeigt werden.
2026-01-26 Neuer cli Query Dispatcher 'cliHistoryQuery' für Implementation von Qobuz DailyQ und WeeklyQ.
2026-01-28 Unterstützung von Lyrion Benutzern ( 'lmsuser' ), in Verbindung mit Material und Qobuz Plugin Sven's-Version sinnvoll.
2026-05-15 Verbesserung des Aufrufs des TrackInfoMenu Kontextmenüs.
=cut

package Plugins::History::Plugin;

use strict;
use base qw(Slim::Plugin::OPMLBased);

use Slim::Control::Request;
use Slim::Utils::Strings qw(string cstring);
use Slim::Utils::Prefs;
#use Slim::Utils::Log; # Wegen logBacktrace()

#use Plugins::History::Menu;

use constant DEFAULT_EXPIRY => 60 * 5;
# create a logging object
my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.history',
	'defaultLevel' => 'ERROR',
	'description'  => 'PLUGIN_HISTORY',
});

# get preference objects
my $prefs = preferences('plugin.history');
my $prefsServer = preferences('server');

$prefs->init({ addDelay => 10, maxHistorySize => 50, delopt => '0', trackmode => '0' });

# globals
my $cache;
my $fav_cliAdd_func;	# 2023-10-20
my $infoAlbum_func;		# 2023-10-29
my $station_name = {};	# 2024-01-22 Speichert der ermittelten Stationsnamen pro Player
my $cacheHistory = {};	# 2024-02-01 Cachen der Anzeige des Wiedergabeverlaufs
my $isQobuz = 0;        # 2025-10-24 Damit es ohne Qobuz Plugin keine Probleme gibt.
my $controller = {};	# Der Zugriff ist $controller->{$player->id}->{lmsuser}.

# setup routine
sub initPlugin {
	my $class = shift;

	Slim::Control::Request::subscribe( \&addTrack, [['playlist','newmetadata']] );
	Slim::Control::Request::subscribe( \&stopTrack, [['playlist'],['stop']] );
	Slim::Control::Request::subscribe( \&updateLmsUser, [['playlistcontrol']] );

	Slim::Control::Request::addDispatch(['history', 'query', '_aParams'], [1, 1, 0, \&cliHistoryQuery]);

	#Sven 2023-11-03, 2025-09-28 - Eine Möglichkeit einen InfoProvidor abzuleiten bzw. zu überschreiben
	my $infoProvidor = Slim::Menu::TrackInfo->getInfoProvider();
	if ($infoProvidor) { 
		$infoAlbum_func = $infoProvidor->{album}->{func};
		#Sven - überschreibt den orignalen InfoAlbum Providor 'album' - SLIM:MENU:TRACKINFO:infoAlbum()
		$infoProvidor->{album}->{func} = \&trackInfoAlbum;
	}

	require Plugins::History::ProtocolHandler;
	if (main::WEBUI) {
		require Plugins::History::Settings;
		require Plugins::History::SettingsPlayer;
		Plugins::History::Settings->new();
		Plugins::History::SettingsPlayer->new();
	}
	
	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => 'history',
		is_app => 1,
	);
}

#Sven 2025-10-24 
sub postinitPlugin {
	my $class = shift;
	
	if ( Slim::Utils::PluginManager->isEnabled('Plugins::Qobuz::Plugin') ) {
		eval {
			require Plugins::Qobuz::Plugin;
		};
		$isQobuz = ($@) ? 0 : 1;
	}

	#Sven - HomeExtras 2026-01-12
	if ( Slim::Utils::PluginManager->isEnabled('Plugins::MaterialSkin::Plugin') && Plugins::MaterialSkin::Plugin->can('registerHomeExtra') ) {
		eval {
			require Plugins::History::HomeExtras;
		};
		$log->error("Could not load History Home Extras: $@") if $@;
	}
}

sub setLmsUser {
	my ($clientId, $lmsUser) = @_;
	$controller->{$clientId}->{lmsuser} = $lmsUser if $clientId;
}

sub getLmsUser {
	my $clientId = shift;
	return $controller->{$clientId}->{lmsuser} || '';
}

sub updateLmsUser {
	my $request = shift;

	if ( my $lmsUser = $request->getParam('user_id') ) {
		my $client = $request->client();
	    setLmsUser($client->id(), $lmsUser) if $client;
	}
}

sub signalHomeExtraUpdate {
    Slim::Control::Request::notifyFromArray(undef, ['material-skin', 'notification', 'internal', 'refresh-home']);
}

sub getDisplayName { 'PLUGIN_HISTORY' }

# don't add this plugin to the Extras menu
sub playerMenu {}

sub getCache {
	# Gibt einen Pointer auf den Cache mit dem Namespace 'history' zurück, falls er noch nicht existiert wird er erzeugt.
	# Bei Versionsänderung wird vorherige Version gelöscht. Version ist nicht etwa ein unterschiedlicher Typ eines Caches.
	return $cache ||= Slim::Utils::Cache->new('history', 4, 1); # Namespace, Version, noPeriodicPurge
}

sub getHistory {
	return getCache()->get('history') || [];
}

sub setHistory {
	getCache()->set('history', shift || [], 'never');
}

# 2024-01-25 Entfernen von Einträgen im Wiedergabeverlauf, wird in settings.pm aufgerufen 
sub removeItems {
	my ($clientId, $option, $radioname) = @_;

	# $option = 0 - Nur Radiostreams entfernen
	# $option = 1 - Alles außer Radiostreams entfernen
	# $option = 2 - Alles entfernen

	my $isQobuzUrl   = qr{^qobuz};
	my $isQobuzTrack = qr{^qobuz:\/\/([0-9]+)\.(flac|mp3)$};
	
	my $items = getHistory();
	my $size  = scalar @$items;
	for ( my $i = 0; $i < scalar @$items; $i++ ) {
		my $entry = $items->[$i];
		if ( $entry->{clientid} eq $clientId ) {
			if (exists $entry->{remote_title}) { # ist ein radiostream
				next if $option eq '1';
				unless ( $radioname eq '' ) {
					if ( $entry->{remote_title} ) {
						#$log->error(_dump($entry->{remote_title}, $radioname, $entry));
						next unless $entry->{remote_title} =~ /$radioname/i; # wenn keine Radiostreams entfernt werden sollen überspringen
					}	
					else {
						#$log->error(_dump($entry->{title}, $radioname, $entry));
						next unless $entry->{title} =~ /$radioname/i || $entry->{url} =~ /$radioname/i;
					}	
				}
				$log->error(_dump('radiostream gelöscht', $entry->{remote_title} || $entry->{title}));
			}
			else {
				# next if $option eq '0'; # wenn nur Radiostreams entfernt werden sollen überspringen
				if ($option eq '0') { # wenn nur Radiostreams entfernt werden sollen noch prüfen ob Qobuz Track URL korrekt ist, sonst löschen
					next unless $entry->{url} =~ $isQobuzUrl;
					next if $entry->{url} =~ $isQobuzTrack; # löscht fehlerhafte Einträge von Qobuz
				}
				elsif ($option eq '2') {
					unless ( $radioname eq '' ) {
						next unless $entry->{title} =~ /$radioname/i || $entry->{url} =~ /$radioname/i;
					}	
				}
				$log->error(_dump('Track gelöscht', $entry->{title}, $entry->{url}));
			}
			splice(@$items, $i, 1);
			$i--;
		}
	}
	setHistory($items) unless $size eq scalar(@$items);
}

sub getPlayers {
	my $items = getHistory();

	my $clients = {};
	foreach ( @$items ) {
		$clients->{$_->{clientid}}++;
	}

	my $players = [];
	foreach ( sort keys %{ $clients } ) {
		my $playername = $_;
		my $client = Slim::Player::Client::getClient($_);
		if ($client) {
			$playername = $client->name;
		}
		else {
			eval {
				$playername = Slim::Utils::Prefs::Client->new($prefsServer, $_)->get('playername');
			};
			$@ && $log->warn("Failed to get player name from prefs: $@");
		}
		push @$players, { name => $playername, id => $_ };
	}

	return $players;
}

sub handleFeed {
	my ($client, $cb, $args, $passthrough) = @_;

	my $id;
	my $mode = $prefs->client($client)->get('mode');
	my $params  = $args->{params};
	my $lmsUser = ($params) ? $params->{user_id} : ''; #Sven 2026-02-02
	if ($lmsUser) { setLmsUser($client->id(), $lmsUser); }
	else { $lmsUser = getLmsUser($client->id()); }

	#Sven - HomeExtras - 2026-01-12
	if ( $params && $params->{menu} && (my ($homeExtra) = $params->{menu} =~ /^home_heroes_(.*)/) ) {
		if ($homeExtra eq 'lastplayed') {
			$id = ($mode eq '1') ? $client->id() : '_ALL_';
			#if (getLmsUser($client->id())) { $lmsUser = getLmsUser($client->id()) }
			#else { setLmsUser($client->id(), $lmsUser); }
		}
		else { $cb->(); return; }	
	}
	else {
		#setLmsUser($client->id(), $lmsUser);
		if ($mode eq '2') {
			if ( !$passthrough || !$passthrough->{client} ) {
				my $items = [];
				push @$items, {
					type => 'link',
					name => cstring($client, 'ALL'),
					url  => \&handleFeed,
					passthrough => [{ client => '_ALL_' }]
				};

				my $players = getPlayers();
				foreach ( @$players) {
					push @$items, {
						type => 'link',
						name => $_->{name},
						url  => \&handleFeed,
						passthrough => [{ client => $_->{id} }]
					};
				}
				
				$cb->({ items => $items });
				return;
			}
			else {
				$id = $passthrough->{client};
			}
		}
		else {
			$id = ($mode eq '0') ? '_ALL_' : $client->id();
		}
	}
=head
	Der Wiedergabeverlauf wird nur im Moment des Aufrufs aktualisiert. Während er anzeigt wird verändert er sich nicht, auch wenn
	in dieser Zeit neue Einträge dazu kommen.
	Wenn ein Wiedergabeverlauf angezeigt wird, kann gleichzeitig ein Radiosender spielen oder ein Album bzw. eine Playlist.
	Bei jedem neuen Song wird dann ein neuer Eintrag im Wiedergabeverlauf erzeugt.
	Leider ist keine Möglichkeit bekannt die Anzeige des Verlaufs automatisch zu aktualisieren sobald er sich ändert.
	Intern werden aber schon die neuen Werte geladen und dann stimmen die Einträge nicht mehr mit der Anzeige überein.
	Das Plugin 'What Was That Tune?' hat genau das gleiche Problem. Wenn dort aus der Anzeige des Wiedergabeverlaufs der falsche Titel abgespielt wird
	oder im Untermenu des Titels nichts oder völlig falsche Werte angezeigt werden, liegt das genau an dieser Problematik.
	Um das Problem zu entschärfen speichere ich die Liste in einem Cache pro Player. Der Verlauf wird dann immer nur aus dem Cache angezeigt
	und erst dann wieder neu geladen wenn man den Verlauf erneut aufruft.
	Mir ist auch nichts bekannt an dem man ablesen könnte, ob eine gerade angezeigte Liste wieder verlassen wurde.
	Daher gibt es als sicheren Triggerpunkt nur den Moment unmittelbar bevor die Verlaufliste angezeigt wird.
	An dieser Stelle wird dann der Cache gelöscht und dies triggert dann das Neueinlesen des Verlaufs bevor er dann zur Anzeige kommt.
	Dies Funktioniert solange nicht zwei Benutzer zur gleichen Zeit den gleichen Player steuern.
	Da das in der Praxis jedoch kaum vorkommt funktioniert die Lösung hier in den allermeisten Fällen sehr gut.
=cut
	delete $cacheHistory->{$lmsUser ? $lmsUser : $id} if $args->{index} eq 0;
	my $items = getPlayhistory($client, $id, $lmsUser);
	return $cb->() unless scalar @$items;
	$cb->({ items => $items }); 
}

sub getPlayhistory {
	my ($client, $id, $lmsUser) = @_;

	my $key = $lmsUser ? $lmsUser : $id;  # Wenn Material 'lmsuser' sendet;

	if (my $cached = $cacheHistory->{$key}) {
		return $cached;
	}

	my $clientId = ($id eq '_ALL_') ? '' : $id; # filtert nach Player oder alle Player
	
	my $playdirect = $prefs->client($client)->get('trackmode');
	$playdirect = ($playdirect) ? ($playdirect eq '0') : 1;

	my $items = getHistory();
	my $history = [];
	foreach (@$items) {
		my $checkId = ($clientId) ? 1 : 0;
		if ($lmsUser) { # Wenn Material 'lmsuser' sendet werden immer alle Einträge dieses Benutzers auf allen Playern angezeigt
			if ($_->{lmsuser}) { # wenn im History Eintrag 'lmsuser' vorhanden ist dann auf Übereinstimmung prüfen
				if ($_->{lmsuser} eq $lmsUser) { $checkId = 0; } # bei Übereinstimmung Eintrag ohne weitere Prüfung übernehmen
				else { next } # keine Übereinstimmung unterdrückt den Eintrag
			}; # wenn es im History Eintrag kein Feld 'lmsuser' gibt so wird der Player Filter geprüft.
		}
		if ($checkId) { # falls noch die clientid geprüft werden muss
			next unless $_->{clientid} eq $clientId; # keine Übereinstimmung der clientId unterdrückt den Eintrag
		}
		my $meta = getItemMeta($client, $_);
		if ( defined $meta && $meta->{title} ) {
			$meta->{id} = $key . ':' . scalar @$history;
			push @$history, getTrackItem($client, $meta, $playdirect); # Ungültig gewordene Einträge werden herausgefiltert
		}
	};
	
	$cacheHistory->{$key} = $history;
	
	main::DEBUGLOG && $log->is_debug && $log->debug(Data::Dump::dump($history));

	return $history;
}

sub getTrackItem {
	my ( $client, $meta, $playdirect ) = @_;

	my $album = $meta->{album};
	my ($name, $line1, $line2);
	if (exists $meta->{remote_title}) { #Radiostream
		$name  = $line1 = $meta->{remote_title} || $meta->{title};
		$line2 = $meta->{artist} . ' - ' . $meta->{title};
		$line2 = sprintf('%s %s %s', $meta->{title}, cstring($client, 'BY'), $meta->{artist});
		if ($album) { $line2 .= sprintf(' %s %s', cstring($client, 'FROM'), $album); }
	}
	else {
		$name  = sprintf('%s %s %s %s %s', $meta->{title}, cstring($client, 'BY'), $meta->{artist}, cstring($client, 'FROM'), $album);
		$line1 = $meta->{title};
		$line2 = join(' - ', grep { $_ } ($meta->{artist}, $album, _sec2hms($meta->{duration})));
	}
	my $item = {
		name	=> $name,
		line1	=> $line1,
		line2	=> $line2,
		meta    => $meta, # Wird für getMeta() benötigt
#		url		=> \&trackMenu,
#		passthrough => [ $meta ],
	};
	$item->{image} = $meta->{cover} || '/music/' . $meta->{coverid} . '/cover.jpg';
	
	if ($playdirect) {
		$item->{play}	   = $meta->{url};
		$item->{playall}   = 1;
		$item->{on_select} = 'play';
	}

	#Sven 2026-05-13 - Erzeugt den Menüeintrag 'More', dieser ruft dann Slim::Menu::TrackInfo::menu() auf
	$item->{itemActions} = {
		info => {
			command => ['trackinfo', 'items'],
            fixedParams => { menu => 'trackinfo', url => "history:$meta->{id}" },
		}
	};

	return $item;
}

sub getItemMeta {
	my ( $client, $item ) = @_;

	my $meta = undef;
	my $url  = $item->{url};
	if (exists $item->{remote_title}) { # Bedingung ist nur bei Radiostreams wahr.
		$meta = {
			title		 => $item->{title},
			artist		 => $item->{artist},
			remote_title => $item->{remote_title},
			url			 => $url,
		};

		if (exists $item->{album}) {
			$meta->{album} = $item->{album};
			# Clean up album because Radio Now Playing can put extra info at the end
			$meta->{album} =~ s/ ?\| .*//;
		}

		if ( defined $item->{cover} ) {
			$meta->{cover} = $item->{cover};
		}
		else {
			$meta->{coverid} = $item->{coverid};
		}
	}
	elsif ( $item->{album} ) {
		$meta = {
			title    => $item->{title},
			tracknum => $item->{tracknum},
			duration => $item->{duration},
			album    => $item->{album},
			cover    => '/music/' . $item->{coverid} . '/cover.jpg',
			artist   => $item->{artist},
			url      => $url,
		};
	}
	elsif ( Slim::Music::Info::isFile($url) ) {
		my $request = Slim::Control::Request::executeRequest($client, ['songinfo', 0,  6, 'url:' . $url, 'tags:elca']); #c = coverid, a = artist, e = album_id, l = album, K = artwork_url, N = remote_title
		my $track = $request->getResult('songinfo_loop');
		$meta = {
			title   => @$track[1]->{title},
			album   => @$track[3]->{album},
			albumId => @$track[2]->{album_id},
			cover   => '/music/' . @$track[4]->{coverid} . '/cover.jpg',
			artist  => @$track[5]->{artist},
			url     => $url,
		};
	}
	elsif ( my $handler = Slim::Player::ProtocolHandlers->handlerForURL($url) ) {
		if ( $handler->can('getMetadataFor') ) {
			$meta = $handler->getMetadataFor($client, $url);
		}
		if ( defined $meta ) {
			if ( ! defined $meta->{cover} && $handler->can('getIcon') ) {
				$meta->{cover} = $handler->getIcon($url);
			}
			$meta->{url} = $url;
		}
	}

	return $meta;
}

sub addTrack {
	my $request = shift;

	my $client = $request->client();
	return unless ($client && $client->isPlaying());

	my $url = Slim::Player::Playlist::url($client);
	return unless $url;

	Slim::Utils::Timers::killTimers($client, \&addItem);
	Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + $prefs->get('addDelay'), \&addItem, $url );
}

sub stopTrack {
	my $request = shift;
	my $client = $request->client();
	if ( defined $client ) {
		Slim::Utils::Timers::killTimers($client, \&addItem);
	}
}

sub getSongMeta {
	my ($client, $url) = @_;
	my $id   = $client->id();
	my $meta;

	if ( my $handler = Slim::Player::ProtocolHandlers->handlerForURL($url) ) {
		if ( $handler->can('getMetadataFor') ) {
			$meta = $handler->getMetadataFor($client, $url);
		}
		if ( defined $meta ) {
			if ( ! defined $meta->{cover} && $handler->can('getIcon') ) {
				$meta->{cover} = $handler->getIcon($url);
			}
			$meta->{url} = $url;
			$meta->{clientid} =  $id;
			unless ( $meta->{lmsusert} ) {
				my $lmsUser = getLmsUser($id);
				$meta->{lmsusert} = $lmsUser if $lmsUser;
			}
		}
	}

	unless ($meta) {
		$meta = { url => $url, clientid => $id };
		my $request = Slim::Control::Request::executeRequest($client, ['songinfo', 0, 7, 'url:' . $url, 'tags:NKal']); # a = artist,  l = album, K = artwork_url, N = remote_title
		if ($request) {
			main::DEBUGLOG && $log->is_debug && $log->debug(Data::Dump::dump($request->getResults()));
			my $songinfo;

			eval {
				$songinfo = $request->getResult('songinfo_loop');
			};

			if ($@) {
				$log->warn("Failed to get song information: $@\n" . Data::Dump::dump($request->getResults()));
				return;
			}

			foreach (@$songinfo) {
				my ($k, $v) = each %$_;
				$k = 'cover' if $k eq 'artwork_url';
				$meta->{$k} = $v || '';
			}

			my $lmsUser = getLmsUser($id);
			$meta->{lmsusert} = $lmsUser if $lmsUser;
		}
	}
	
	return undef unless $meta->{title};

	#$log->error(_dump($meta));

	if ( $url =~ /(^radioparadise:|stream.radioparadise.com)/i ) { # behandlung von Radio Paradise
		unless ($meta->{artist}) {
			my $station = join(' - ', grep { $_ } ($meta->{title}, $meta->{remote_title}));
			unless ($station =~ /radio paradise/i) { $station = 'Radio Paradise - ' . $station; }
			$station_name->{$id} = $station;
			return;
		}
		$meta->{remote_title} = $station_name->{$id};
	}
	elsif ( $url =~ /^accur:/i ) { # Behandlung von Accuradio
		return undef unless $meta->{artist};
		$meta->{cover} = 'html/images/radio.png'; # wegen 'hot linking' werden die artwork links von Accuradio geblockt.
		$meta->{remote_title} = 'Accuradio';
	}
	elsif ( $url =~ /^(http|https):/i ) { # sonstige Radiostreams, TuneIn etc.
		$station_name->{$id} = $meta->{remote_title} if $meta->{remote_title};  #|| $meta->{remote_title} =~ /$meta->{artist}/i );
		return undef if ! $meta->{artist} || $meta->{remote_title} =~ /$meta->{artist}/i;
		$meta->{remote_title} = $station_name->{$id} if !$meta->{remote_title};
		return undef if $meta->{remote_title} eq $meta->{title};
	}
	else { $station_name->{$id} = ''; }

	return $meta;
}

sub addItem {
	my ($client, $url) = @_;

	my $item = getSongMeta($client, $url);
	return unless defined $item;

	my $items = getHistory();
	my $id = $item->{clientid};
	if ( exists $item->{remote_title} ) { # Radiostream
		# verhindert bei Radiostreams doppelten Eintrag
		my $previous = undef;
		for ( my $i = 0; $i < scalar @$items; $i++ ) {
			my $track = $items->[$i];
			if ($track->{clientid} eq $id) {
				$previous = $track;
				last;
			}
		}	
		
		if (defined $previous && exists $previous->{remote_title}) {
			if ($previous->{title} eq $item->{title} && $previous->{artist} eq $item->{artist}) {
				return;
			}
		}
	}
	else { # Track von Streamingdienst oder aus Lyrion Datenbank
		my $url = $item->{url};

		my $lmsUser = $item->{lmsuser} || getLmsUser($client->id());

		# holt den gerade gespielten Track nach vorne, wenn er bereits in der History enthalten ist.
		for ( my $i = 0; $i < scalar @$items; $i++ ) {
			my $track = $items->[$i];
			if ( $track->{url} eq $url ) {
				if ($lmsUser) {
					next unless $lmsUser eq $track->{lmsuser};
				}
				else {
					next unless $track->{clientid} eq $id;
				}
				splice(@$items, $i, 1);
				last;
			}
		}
		
		$item = { url => $url, clientid => $id };
		$item->{lmsuser} = $lmsUser if $lmsUser;
	}
	
	my $size = $prefs->get('maxHistorySize');
	unshift(@$items, $item);
	while (scalar(@$items) > $size) { pop(@$items); } # Verkleinert den Wiedergabeverlauf falls mehr als maxHistorySize Einträge enthält.
	setHistory($items);
	signalHomeExtraUpdate();
}

# 2023-11-02 bei Track wird beim Contextmenu der Menupunkt 'Album' eingefügt.
# Bei Favoriten steht da bei Track aus der Musik-Bibliothek im Feld 'url' einfach nur 'blabla'.
# on_select => 'play', playall => 1,
sub trackInfoAlbum {
	my ( $client, $url, $track, $remoteMeta, $tags, $filter ) = @_;
	
	my $item;
	if ( $isQobuz && $url =~ /^qobuz:\/\//i ) { #Sven 2025-10-24 Wird nur bei installierten Qobuz Plugin ausgeführt.
		$item = {
			name  => $remoteMeta->{album},
			image => $remoteMeta->{cover},
			label => 'ALBUM',
			type  => 'link',
			url   => sub { 
						my ($client, $cb, $params, $args) = @_;
						Slim::Control::Request::executeRequest($client, ['qobuz', 'command', ['album', $cb, $params, $args]]);
					 },
			passthrough => [{ album_id => $remoteMeta->{albumId}, album_title => $remoteMeta->{album} }]
		};
	}
	else {
		my $album = $remoteMeta->{album};

		$remoteMeta->{album} = '' unless $remoteMeta->{remote_title}; #Sven - Damit der Standard TrackInfoProvidor für Alben das Album als Liste anzeigt.
	
		$item = $infoAlbum_func->(@_); #Sven - Aufruf des Standard TrackInfoProvidors SLIM:MENU:TRACKINFO:infoAlbum() für Alben, siehe initLogin()

		if ($remoteMeta->{cover} && $item->{type} eq 'playlist') { $item->{icon} = $remoteMeta->{cover} } 
		#delete $item->{label};

		$remoteMeta->{album} = $album;
	}

	return $item;
}

=head2 - Wird erst einmal nicht mehr benutzt, da das TrackInfoMenu jetzt durch eine Aktion aufgerufen wird.
sub trackMenu {
	my ($client, $cb, $params, $meta) = @_;

	$cb->( getTrackMenu( $client, $meta ) );

	#my $url = $meta->{url};

	# Workaround: In Slim::Menu::TrackInfo->menu() Zeile 260 fehlt create => 1, deshalb fehlt bei vielen Tracks ein Track-Objekt und muss für die Funktion erzeugt werden.
	#my $track = Slim::Schema->objectForUrl( { 
	#	url => $url,
	#	create => 1,
	#} );

	#$cb->( Slim::Menu::TrackInfo->menu($client, $url, $track, undef, undef) );
}
=cut

#Sven 2026-05-16 - Wird von trackInfoURL() in ProtocolHandler.pm aufgerufen.
sub getTrackInfoMenu {
	my ( $client, $url ) = @_;

	my ($key, $id) = $url =~ /^history:(\w+):(\d+)$/;

	if ($key ne '' && $id ne '') {
		if (my $cached = $cacheHistory->{$key}) {
			my $meta = $cached->[$id]->{meta};
			#$meta->{remote_title} = "" unless defined $meta->{remote_title};
			return getTrackMenu($client, $meta) if $meta; # Es wird ein eigenes Menü erzeugt.
		}
	}	
	return { items => [{ name => $url, type => 'text' }, { name => 'Keine Metadaten gefunden!', type => 'text'}] }; # Falls etwas schief läuft
	#return 0; # Es wurde kein Menü erzeugt, eine Rückgabe von FALSE führt die Standard menu() Routinen von Lyrion aus.
}	

# 2024-01-20 Erzeugt das Trackmenü - Ist zum größten Teil eine Kopie der Funktion menu() aus Slim\Menu\TrackInfo.pm
#            Wird hier benötigt um die bereits vorhandenen Meta-Daten zu nutzen und ein Track-Objekt zu erzeugen falls es noch nicht existiert.
#            Die Originalfunktion bricht bei nicht vorhandenem Track-Objekt einfach ab. 
sub getTrackMenu {
	my ($client, $remoteMeta) = @_;
	my $tags = { menuMode => 'history' };

	my $url = $remoteMeta->{url};

	my $track = Slim::Schema->objectForUrl( {
		url => $url,
		create => 1,
	} );
	
	# Function to add menu items
	my $addItem = sub {
		my ( $ref, $items ) = @_;

		if ( defined $ref->{func} ) {

			# skip jive-only items for non-jive UIs
			return if $ref->{menuMode} && !$tags->{menuMode};

			my $item = eval { $ref->{func}->( $client, $url, $track, $remoteMeta, $tags ) };
			if ( $@ ) {
				$log->error( 'History menu item "' . $ref->{name} . '" failed: ' . $@ );
				return;
			}

			return unless defined $item;
			

			if ( ref $item eq 'ARRAY' ) {
				if ( scalar @{$item} ) {
					push @{$items}, @{$item};
				}
			}
			elsif ( ref $item eq 'HASH' ) {
				return if $ref->{menuMode} && !$tags->{menuMode};
				if ( scalar keys %{$item} ) {
					push @{$items}, $item;
				}
			}
			else {
				$log->error( 'History menu item "' . $ref->{name} . '" failed: not an arrayref or hashref' );
			}
		}
	};

	# If we don't have an ordering, generate one.
	# This will be triggered every time a change is made to the
	# registered information providers, but only then. After
	# that, we will have our ordering and only need to step
	# through it.
	my $infoOrdering = Slim::Menu::TrackInfo->getInfoOrdering();

	# Now run the order, which generates all the items we need
	my $items = [];

	for my $ref ( @{ $infoOrdering } ) {
		# Skip items with a defined parent, they are handled
		# as children below
		next if $ref->{parent};

		# Add the item
		$addItem->( $ref, $items );

		# Look for children of this item
		my @children = grep {
			$_->{parent} && $_->{parent} eq $ref->{name}
		} @{ $infoOrdering };

		if ( @children ) {
			my $subitems = $items->[-1]->{items} = [];

			for my $child ( @children ) {
				$addItem->( $child, $subitems );
			}
		}
	}

	# Remove distinct play/add items and add a single playable URL
	if ($track->url) {
		$items = [ grep {
			($_->{jive} && $_->{jive}->{actions}) ? undef : $_
		} @$items ];

		my $playdirect = $prefs->client($client)->get('trackmode');
		$playdirect = ($playdirect) ? ($playdirect eq '0') : 1;
		unless ($playdirect) {
			unshift @$items, {
				name => $remoteMeta->{remote_title} || Slim::Music::TitleFormatter::infoFormat($track, '', 'TITLE - ARTIST', $remoteMeta),
				type => 'audio',
				url => $url
			};
		}
	}

	return {
		name  => $track->title || Slim::Music::Info::getCurrentTitle( $client, $url, 1 ),
		type  => 'opml',
		items => $items,
		play  => $url,
		cover => $remoteMeta->{cover} || $remoteMeta->{icon} || '/music/' . ($track->coverid || 0) . '/cover.jpg',
		menuComplete => 1,
	};
}

#Sven 2019-03-19
#Slim::Utils::DateTime::timeFormat(),
sub _sec2hms {
	my $seconds = shift;

	return $seconds unless ($seconds);

	my $minutes   = int($seconds / 60);
	my $hours     = int($minutes / 60);
	return sprintf('%s:%02s:%02s', $hours, $minutes % 60, $seconds % 60) if ($hours);
	return sprintf('%02s:%02s', $minutes, $seconds % 60); 
}

#Sven 2026-02-17
sub cliHistoryQuery {
	my $request = shift;
	
	# check this is the correct query.
	if ( $request->isNotQuery([['history'], ['query']]) ) {
		$request->setStatusBadDispatch();
		return;
	}

	# get our parameters
	my $client  = $request->client();
	my ($command, $lmsUser, $count, $filter) = @{$request->getParam('_aParams')};

	my $items = getHistory();

	my $result = [];
	if ($count) {
		my $tracks = [];
		foreach (@$items) { # Holt alle gehörten Tracks eines Benutzers aus der History
			if ($_->{url} =~ /$filter/i && ( ! $lmsUser || $_->{lmsuser} eq $lmsUser ) ) { # immer die History über alle Player holen, deshalb kann ' (! $id || $_->{clientid} eq $id) && ' entfallen
				push @$tracks, $_->{url};
			}	
		};
		my $tc = scalar @$tracks;
		if ($tc <= $count) { # Wenn es nicht mehr als $count Elemente gibt diese zurückgeben.
			$result = $tracks;
		}
		else {
			# Jetzt zufällig $count Elemente aus der Trackliste auswählen und dann zurückgeben.
			while ($count && $tc--) { 
				my $ix = int(rand($count--));
				push @$result, $tracks->[$ix];
				splice(@$tracks, $ix, 1);
			}
		}	
	}

	$request->addResult('_aValue', $result);

	$request->setStatusDone();
}

sub _dump {
	my $out = "\n";
	foreach (@_) {
		$out .= Data::Dump::dump($_) . "\n";
	}
	return $out;
}
1;

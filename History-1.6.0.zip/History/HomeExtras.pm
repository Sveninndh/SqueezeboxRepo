package Plugins::History::HomeExtras;

use strict;
use Plugins::History::Plugin;

#Plugins::History::HomeExtraHistory->initPlugin();
Plugins::History::HomeExtraLastPlayed->initPlugin();

1;

package Plugins::History::HomeExtraBase;

use base qw(Plugins::MaterialSkin::HomeExtraBase);
use Slim::Utils::Log;

sub initPlugin {
	my ($class, %args) = @_;

	my $tag = $args{tag};

	$class->SUPER::initPlugin(
		feed => sub { handleFeed($tag, @_) },
		tag  => "HistoryExtras${tag}",
		extra => {
			title => $args{title},
			#icon  => $args{icon} || 'html/images/playlists.png',
			icon  => 'html/images/playlists.png',
			needsPlayer => 1,
		},
		count => $args{count},
	);
}

sub handleFeed {
	my ($tag, $client, $cb, $args) = @_;

	$args->{params}->{menu} = "home_heroes_${tag}";

	Plugins::History::Plugin::handleFeed($client, $cb, $args);
}

1;


package Plugins::History::HomeExtraLastPlayed;

use base qw(Plugins::History::HomeExtraBase);

sub initPlugin {
	my ($class, %args) = @_;

	$class->SUPER::initPlugin(
		title => 'PLUGIN_HISTORY',
		tag => 'lastplayed',
		count => 20,
	);
}

1;

